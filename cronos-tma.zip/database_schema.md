# Cronos - Database Schema

This document outlines the proposed database schema for the Cronos application. The schema is designed to be relational and uses SQL.

## Tabela: `sheets`

Armazena os dados principais de cada folha de produção.

```sql
CREATE TABLE sheets (
    id VARCHAR(255) PRIMARY KEY,
    line_id VARCHAR(50) NOT NULL,
    production_date DATE NOT NULL,
    product_code VARCHAR(255),
    product_description TEXT,
    sheet_status VARCHAR(50) CHECK(sheet_status IN ('PENDENTE', 'OK')) NOT NULL,
    manual_pre_pointing_pallets INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

---

## Tabela: `zis`

Armazena as Zonas de Inspeção (ZIs) associadas a uma folha de produção.

```sql
CREATE TABLE zis (
    id SERIAL PRIMARY KEY,
    sheet_id VARCHAR(255) NOT NULL,
    sigla VARCHAR(255) NOT NULL,
    problem TEXT,
    start_tag INTEGER NOT NULL,
    end_tag INTEGER NOT NULL,
    status VARCHAR(50) CHECK(status IN ('PENDENTE', 'OK', 'NOK')) NOT NULL,
    pre_pointing_status VARCHAR(50) CHECK(pre_pointing_status IN ('PENDENTE', 'OK')) DEFAULT 'PENDENTE',
    FOREIGN KEY (sheet_id) REFERENCES sheets(id) ON DELETE CASCADE
);
```

---

## Tabela: `reworks`

Armazena os itens de retrabalho associados a uma folha de produção.

```sql
CREATE TABLE reworks (
    id SERIAL PRIMARY KEY,
    sheet_id VARCHAR(255) NOT NULL,
    rework_reason TEXT NOT NULL,
    start_tag INTEGER NOT NULL,
    end_tag INTEGER NOT NULL,
    status VARCHAR(50) CHECK(status IN ('PENDENTE', 'LIBERADO')) NOT NULL,
    FOREIGN KEY (sheet_id) REFERENCES sheets(id) ON DELETE CASCADE
);
```

---

## Tabela: `fractioned_items`

Armazena os itens fracionados de uma folha de produção.

```sql
CREATE TABLE fractioned_items (
    id SERIAL PRIMARY KEY,
    sheet_id VARCHAR(255) NOT NULL,
    location VARCHAR(255),
    layers INTEGER NOT NULL,
    FOREIGN KEY (sheet_id) REFERENCES sheets(id) ON DELETE CASCADE
);
```

---

## Tabela: `forklift_blocks`

Armazena os blocos de estocagem criados pelos operadores de empilhadeira.

```sql
CREATE TABLE forklift_blocks (
    id VARCHAR(255) PRIMARY KEY,
    sheet_id VARCHAR(255) NOT NULL,
    line_id VARCHAR(50) NOT NULL,
    identifier VARCHAR(255) NOT NULL,
    operator_name VARCHAR(255) NOT NULL,
    total_pallets INTEGER NOT NULL,
    status VARCHAR(50) CHECK(status IN ('ABERTO', 'FECHADO')) NOT NULL,
    pre_pointing_status VARCHAR(50) CHECK(pre_pointing_status IN ('PENDENTE', 'OK')) DEFAULT 'PENDENTE',
    date TIMESTAMPTZ NOT NULL,
    absorbed_rework_ids INTEGER[], -- Array of absorbed rework IDs
    FOREIGN KEY (sheet_id) REFERENCES sheets(id) ON DELETE CASCADE
);
```

---

## Tabela: `forklift_block_tags`

Armazena os diferentes tipos de ranges de etiquetas para cada bloco de estocagem.

```sql
CREATE TABLE forklift_block_tags (
    id SERIAL PRIMARY KEY,
    block_id VARCHAR(255) NOT NULL,
    tag_type VARCHAR(50) CHECK(tag_type IN ('STORED', 'ZI', 'REWORK')) NOT NULL,
    start_tag INTEGER NOT NULL,
    end_tag INTEGER NOT NULL,
    -- Columns specific to ZI tags
    zi_sigla VARCHAR(255),
    zi_problem TEXT,
    pnc_status VARCHAR(50) CHECK(pnc_status IN ('PENDENTE', 'ALOCADO')),
    -- Columns specific to Rework tags
    rework_reason TEXT,
    original_id INTEGER, -- To link back to the ZI or Rework that created it
    FOREIGN KEY (block_id) REFERENCES forklift_blocks(id) ON DELETE CASCADE
);
```
*Nota: A tabela `forklift_block_tags` consolida `storedTags`, `ziTags`, e `reworkTags` em uma única tabela com um campo `tag_type` para diferenciação, simplificando o modelo de dados.*

---

## Tabela: `reservations`

Armazena as reservas de lote.

```sql
CREATE TABLE reservations (
    id VARCHAR(255) PRIMARY KEY,
    reservation_number VARCHAR(255) NOT NULL,
    status VARCHAR(50) CHECK(status IN ('PENDENTE', 'OK')) NOT NULL
);
```

---

## Tabela: `observations`

Armazena as observações de turno. Poderia ser uma tabela simples ou um armazenamento NoSQL.

```sql
CREATE TABLE observations (
    turn_id VARCHAR(10) PRIMARY KEY CHECK(turn_id IN ('turnoA', 'turnoB', 'turnoC')),
    content TEXT
);
```