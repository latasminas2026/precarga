-- ############################################################################
-- CRONOS | INTELIGÊNCIA OPERACIONAL - TMA SCHEMA (SUPABASE)
-- SCHEMA DEFINITIVO E OTIMIZADO PARA O MÓDULO DE TMA (MONITORAMENTO DE TEMPOS)
-- ############################################################################

-- Habilita a extensão para geração automática de UUIDs
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ============================================================================
-- 1. TABELAS ESPECÍFICAS DO TMA
-- ============================================================================

-- Tabela: tma_imports (Sessões de importação de arquivos)
CREATE TABLE IF NOT EXISTS tma_imports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    titulo VARCHAR(255) NOT NULL,
    data_ocorrencia DATE NOT NULL,
    tipo_entrada VARCHAR(50) NOT NULL,
    raw_text TEXT,
    bi_raw_text TEXT,
    uid VARCHAR(255), -- ID do usuário (Firebase ou anônimo)
    timestamp TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Tabela: tma_entries (Apontamentos e registros de tempos dos veículos)
CREATE TABLE IF NOT EXISTS tma_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    import_id UUID NOT NULL REFERENCES tma_imports(id) ON DELETE CASCADE,
    
    -- Dados do veículo e motorista
    placa VARCHAR(50) NOT NULL,
    placa_carreta VARCHAR(50),
    transportadora VARCHAR(255),
    motorista VARCHAR(255),
    lacre VARCHAR(100),
    nota_fiscal VARCHAR(255),
    pedido VARCHAR(255),
    origem VARCHAR(255),
    local_doca VARCHAR(100),
    processo VARCHAR(100),
    operacao VARCHAR(100),
    turno CHAR(1),
    
    -- Tempos e timestamps
    hora_checkin TIMESTAMPTZ,
    hora_entrada TIMESTAMPTZ,
    hora_doca TIMESTAMPTZ,
    hora_saida_doca TIMESTAMPTZ,
    hora_saida_fabrica TIMESTAMPTZ,
    
    -- Indicadores calculados (em segundos)
    tmfe INTEGER DEFAULT 0,
    tmfi INTEGER DEFAULT 0,
    tmc INTEGER DEFAULT 0,
    tms INTEGER DEFAULT 0,
    tma INTEGER DEFAULT 0,
    tma_real INTEGER,
    
    -- Telemetria do BI/GPS
    bi_status VARCHAR(100),
    bi_duracao INTEGER,
    bi_gps_last TIMESTAMPTZ,
    bi_lat DECIMAL(10, 8),
    bi_lng DECIMAL(11, 8),
    bi_status_veiculo TEXT,
    bi_ultimo_local_parada TEXT,
    bi_canal VARCHAR(100),
    bi_inicio_parada TIMESTAMPTZ,
    bi_fim_parada TIMESTAMPTZ,
    bi_unidade_dimensionada VARCHAR(255),
    dt_codigo VARCHAR(100),
    tp_codigo VARCHAR(100),
    
    -- Flags analíticas
    is_outlier BOOLEAN DEFAULT FALSE NOT NULL,
    is_manobra BOOLEAN DEFAULT FALSE NOT NULL,
    is_backup BOOLEAN DEFAULT FALSE NOT NULL,
    is_in_radius BOOLEAN DEFAULT FALSE NOT NULL,
    status_raio VARCHAR(50) DEFAULT 'FORA',
    status_sla_drop VARCHAR(50) DEFAULT 'NORMAL',
    alerta_3h BOOLEAN DEFAULT FALSE NOT NULL,
    unidade_divergente BOOLEAN DEFAULT FALSE NOT NULL,
    flag_manobra BOOLEAN DEFAULT FALSE NOT NULL,
    
    -- Não conformidades e observações
    status VARCHAR(50) DEFAULT 'OK',
    item_inspecionado TEXT,
    description TEXT,
    
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

-- Índices para otimização das consultas do TMA
CREATE INDEX IF NOT EXISTS idx_tma_imports_data ON tma_imports(data_ocorrencia);
CREATE INDEX IF NOT EXISTS idx_tma_entries_import_id ON tma_entries(import_id);
CREATE INDEX IF NOT EXISTS idx_tma_entries_placa ON tma_entries(placa);
CREATE INDEX IF NOT EXISTS idx_tma_entries_turno ON tma_entries(turno);

-- ============================================================================
-- 2. POLÍTICAS DE SEGURANÇA E ACESSO (RLS)
-- Permite que o front-end consulte e salve dados usando a anon key do Supabase.
-- ============================================================================

-- Habilita RLS nas tabelas
ALTER TABLE tma_imports ENABLE ROW LEVEL SECURITY;
ALTER TABLE tma_entries ENABLE ROW LEVEL SECURITY;

-- Políticas Públicas de Acesso (Leitura, Escrita e Exclusão para funcionamento sem login Supabase)
CREATE POLICY "Permitir tudo em tma_imports publicamente" ON tma_imports FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Permitir tudo em tma_entries publicamente" ON tma_entries FOR ALL USING (true) WITH CHECK (true);

-- ============================================================================
-- 3. TABELAS DE ESTRATIFICAÇÃO / ANÁLISE DE PI E OFENSORES
-- ============================================================================

-- Tabela de Registros de Indicadores (AnalisePIScreen)
CREATE TABLE IF NOT EXISTS analise_pi_registros (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    indicador VARCHAR(50) NOT NULL,
    data_ocorrencia DATE NOT NULL,
    turno CHAR(1) NOT NULL,
    area VARCHAR(255),
    tipo_ocorrencia VARCHAR(255),
    tempo INTEGER DEFAULT 0,
    responsavel VARCHAR(255),
    observacao TEXT,
    uid VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE analise_pi_registros ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Permitir tudo em analise_pi_registros publicamente" ON analise_pi_registros FOR ALL USING (true) WITH CHECK (true);

-- Tabela de Estratificações de Ofensores (StratificationModal)
CREATE TABLE IF NOT EXISTS tma_offender_stratifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    data DATE NOT NULL,
    turno CHAR(1) NOT NULL,
    placa VARCHAR(50) NOT NULL,
    transportadora VARCHAR(255),
    motivo VARCHAR(255) NOT NULL,
    descricao TEXT,
    responsavel VARCHAR(255),
    guia VARCHAR(255),
    unidade VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP NOT NULL
);

ALTER TABLE tma_offender_stratifications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Permitir tudo em tma_offender_stratifications publicamente" ON tma_offender_stratifications FOR ALL USING (true) WITH CHECK (true);


