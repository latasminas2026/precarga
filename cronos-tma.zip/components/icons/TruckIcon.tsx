
import React from 'react';

const TruckIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M5 18H3c0-1.1.9-2 2-2v4c-1.1 0-2-.9-2-2Z" />
    <path d="M19 18h2c0-1.1-.9-2-2-2v4c1.1 0 2-.9 2-2Z" />
    <path d="M10 18h1" />
    <path d="M13 18h1" />
    <path d="M17 18h-2" />
    <path d="M5 18v-5h14v5" />
    <path d="M19 13H5" />
    <path d="m7 13-1.8-4.2c-.1-.3-.4-.5-.7-.5H3" />
    <path d="m19 13 1.8-4.2c.1-.3.4-.5.7-.5h1.5" />
    <path d="M12 13V8" />
    <path d="M7 8h10" />
  </svg>
);

export default TruckIcon;
