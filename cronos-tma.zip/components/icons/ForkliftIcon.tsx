
import React from 'react';

const ForkliftIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M12 12H5a2 2 0 0 0-2 2v5" />
    <path d="M5 17a2 2 0 1 0 4 0a2 2 0 1 0-4 0" />
    <path d="M15 17a2 2 0 1 0 4 0a2 2 0 1 0-4 0" />
    <path d="M15 17H9" />
    <path d="M18 5h-3v4h3V5Z" />
    <path d="M11 12V5H4v2" />
    <path d="M11 5L6 2" />
    <path d="M18 9l3-3" />
  </svg>
);

export default ForkliftIcon;
