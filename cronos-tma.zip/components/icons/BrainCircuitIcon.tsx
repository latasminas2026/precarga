
import React from 'react';

const BrainCircuitIcon: React.FC<React.SVGProps<SVGSVGElement>> = (props) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M12 5a3 3 0 1 0-5.993.142" />
    <path d="M12 5a3 3 0 1 1 5.993.142" />
    <path d="M12 12a3 3 0 1 0-5.993.142" />
    <path d="M12 12a3 3 0 1 1 5.993.142" />
    <path d="M12 19a3 3 0 1 0-5.993.142" />
    <path d="M12 19a3 3 0 1 1 5.993.142" />
    <path d="M12 5a3 3 0 0 0-3 3v1" />
    <path d="M12 5a3 3 0 0 1 3 3v1" />
    <path d="M12 12a3 3 0 0 0-3 3v1" />
    <path d="M12 12a3 3 0 0 1 3 3v1" />
    <path d="M9 9h6" />
    <path d="M9 16h6" />
  </svg>
);

export default BrainCircuitIcon;
