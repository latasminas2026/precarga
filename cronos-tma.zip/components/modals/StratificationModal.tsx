import React, { useState } from 'react';
import { X, Save, AlertTriangle } from 'lucide-react';
import { AnalisePIRegistro } from '../../types';

interface StratificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Omit<AnalisePIRegistro, 'id'>) => void;
  placa?: string;
  transportadora?: string;
  guia: string;
}

const StratificationModal: React.FC<StratificationModalProps> = ({
  isOpen,
  onClose,
  onSave,
  placa = '',
  transportadora = '',
  guia
}) => {
  const [formData, setFormData] = useState({
    data: new Date().toISOString().split('T')[0],
    turno: 'A' as 'A' | 'B' | 'C',
    placa: placa,
    transportadora: transportadora,
    motivo: '',
    descricao: '',
    responsavel: ''
  });

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({
      ...formData,
      guia
    });
    onClose();
  };

  const motivos = [
    'Atraso na Entrada',
    'Atraso no Carregamento',
    'Atraso na Saída',
    'Problema Sistêmico',
    'Problema com Veículo',
    'Falta de Motorista',
    'Divergência de Carga',
    'Outros'
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-[#2a2a2a] w-full max-w-lg rounded-2xl border border-white/10 shadow-2xl overflow-hidden animate-in fade-in zoom-in duration-200">
        <div className="px-6 py-4 border-b border-white/10 flex items-center justify-between bg-gradient-to-r from-emerald-500/10 to-transparent">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-500/20 rounded-lg">
              <AlertTriangle className="w-5 h-5 text-emerald-500" />
            </div>
            <h2 className="text-xl font-bold text-white">Estratificação - {guia.toUpperCase()}</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/5 rounded-full transition-colors">
            <X className="w-5 h-5 text-gray-400" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Data</label>
              <input
                type="date"
                required
                value={formData.data}
                onChange={e => setFormData({ ...formData, data: e.target.value })}
                className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Turno</label>
              <select
                required
                value={formData.turno}
                onChange={e => setFormData({ ...formData, turno: e.target.value as any })}
                className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
              >
                <option value="A">Turno A</option>
                <option value="B">Turno B</option>
                <option value="C">Turno C</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Placa</label>
              <input
                type="text"
                required
                placeholder="ABC-1234"
                value={formData.placa}
                onChange={e => setFormData({ ...formData, placa: e.target.value.toUpperCase() })}
                className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Transportadora</label>
              <input
                type="text"
                required
                placeholder="Nome da empresa"
                value={formData.transportadora}
                onChange={e => setFormData({ ...formData, transportadora: e.target.value })}
                className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Motivo</label>
            <select
              required
              value={formData.motivo}
              onChange={e => setFormData({ ...formData, motivo: e.target.value })}
              className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
            >
              <option value="">Selecione um motivo</option>
              {motivos.map(m => (
                <option key={m} value={m}>{m}</option>
              ))}
            </select>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Descrição Detalhada</label>
            <textarea
              required
              rows={3}
              placeholder="Descreva o ocorrido..."
              value={formData.descricao}
              onChange={e => setFormData({ ...formData, descricao: e.target.value })}
              className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all resize-none"
            />
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Responsável</label>
            <input
              type="text"
              required
              placeholder="Seu nome"
              value={formData.responsavel}
              onChange={e => setFormData({ ...formData, responsavel: e.target.value })}
              className="w-full bg-[#1a1a1a] border border-white/10 rounded-xl px-4 py-2.5 text-white focus:ring-2 focus:ring-emerald-500/50 outline-none transition-all"
            />
          </div>

          <div className="pt-4 flex gap-3">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-6 py-3 rounded-xl border border-white/10 text-gray-300 font-semibold hover:bg-white/5 transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-6 py-3 rounded-xl bg-emerald-500 text-black font-bold hover:bg-emerald-400 transition-all flex items-center justify-center gap-2 shadow-lg shadow-emerald-500/20"
            >
              <Save className="w-5 h-5" />
              Salvar Estratificação
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default StratificationModal;
