import React, { useState, useEffect } from 'react';

interface CronosMascotProps {
  className?: string;
  variant?: 'logo' | 'badge' | 'avatar';
  size?: number;
}

export const CronosMascot: React.FC<CronosMascotProps> = ({
  className = '',
  variant = 'badge',
  size
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const hours = currentTime.getHours();
  const minutes = currentTime.getMinutes();
  const seconds = currentTime.getSeconds();

  const hourAngle = ((hours % 12) * 30) + (minutes * 0.5);
  const minuteAngle = minutes * 6;
  const secondAngle = seconds * 6;

  // Render a compact avatar-only version
  if (variant === 'avatar') {
    return (
      <div 
        className={`relative flex items-center justify-center rounded-2xl overflow-hidden bg-slate-950 border border-blue-500/30 shadow-lg ${className}`}
        style={{ width: size || 44, height: size || 44 }}
      >
        <svg viewBox="0 0 100 100" className="w-full h-full">
          {/* Background */}
          <circle cx="50" cy="50" r="50" fill="url(#avatar-grad)" />
          
          {/* Mascot Head */}
          <g transform="translate(0, 5)">
            {/* Neck */}
            <path d="M 44,65 L 56,65 L 53,75 L 47,75 Z" fill="#fbcfe8" opacity="0.15" />
            <path d="M 44,65 L 56,65 L 53,75 L 47,75 Z" fill="#fed7aa" />
            
            {/* Hoodie Collar/Neckline */}
            <path d="M 38,72 Q 50,85 62,72 L 58,82 Q 50,92 42,82 Z" fill="#1e293b" />
            
            {/* Head/Face */}
            <path d="M 35,45 Q 35,25 50,25 Q 65,25 65,45 Q 65,65 50,65 Q 35,65 35,45 Z" fill="#ffedd5" />
            <path d="M 35,45 Q 35,25 50,25 Q 65,25 65,45 Q 65,63 50,63 Q 35,63 35,45 Z" fill="#fed7aa" />
            
            {/* Hair - Spiky Dark Mascot Hair */}
            <path d="M 32,45 Q 30,30 38,20 Q 42,10 50,15 Q 58,8 64,22 Q 68,32 65,42 Q 62,25 50,25 Q 38,25 32,45 Z" fill="#1e293b" />
            <path d="M 36,35 L 30,28 L 39,26 L 41,15 L 48,22 L 53,12 L 58,22 L 67,16 L 64,28 L 71,28 L 65,39 L 61,35 Q 50,42 36,35 Z" fill="#0f172a" />
            
            {/* Eyes */}
            <ellipse cx="43" cy="44" rx="3.5" ry="5" fill="#1e293b" />
            <ellipse cx="57" cy="44" rx="3.5" ry="5" fill="#1e293b" />
            <circle cx="44" cy="42" r="1.2" fill="#ffffff" />
            <circle cx="58" cy="42" r="1.2" fill="#ffffff" />
            
            {/* Smile */}
            <path d="M 44,52 Q 50,59 56,52" stroke="#1e293b" strokeWidth="2" strokeLinecap="round" fill="none" />
            {/* Cheeks */}
            <circle cx="40" cy="49" r="2" fill="#fca5a5" opacity="0.5" />
            <circle cx="60" cy="49" r="2" fill="#fca5a5" opacity="0.5" />
          </g>
          
          {/* Small Clock on chest or foreground */}
          <g transform="translate(72, 72) scale(0.24)">
            <circle cx="50" cy="50" r="46" fill="#0f172a" stroke="#3b82f6" strokeWidth="8" />
            <circle cx="50" cy="50" r="38" fill="#ffffff" />
            <line x1="50" y1="50" x2="50" y2="22" stroke="#0f172a" strokeWidth="10" strokeLinecap="round" transform={`rotate(${hourAngle} 50 50)`} />
            <line x1="50" y1="50" x2="74" y2="50" stroke="#0f172a" strokeWidth="7" strokeLinecap="round" transform={`rotate(${minuteAngle} 50 50)`} />
            <circle cx="50" cy="50" r="4" fill="#3b82f6" />
          </g>
          
          <defs>
            <linearGradient id="avatar-grad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#1d4ed8" />
              <stop offset="100%" stopColor="#0284c7" />
            </linearGradient>
          </defs>
        </svg>
      </div>
    );
  }

  // Render a small round header logo version
  if (variant === 'logo') {
    return (
      <div className={`flex items-center gap-2.5 ${className}`}>
        <div 
          className="relative rounded-xl overflow-hidden bg-slate-950 border border-blue-500/40 p-0.5 shadow-md shadow-blue-950/20"
          style={{ width: size || 40, height: size || 40 }}
        >
          <svg viewBox="0 0 100 100" className="w-full h-full">
            {/* Background circular gradient */}
            <circle cx="50" cy="50" r="48" fill="url(#logo-bg-grad)" stroke="#2563eb" strokeWidth="2" />
            
            {/* Chimney silhouette in background */}
            <path d="M 18,70 L 18,50 L 24,50 L 24,70 Z" fill="#1e3a8a" opacity="0.4" />
            <path d="M 26,70 L 26,40 L 32,40 L 32,70 Z" fill="#1e3a8a" opacity="0.4" />
            
            {/* Mascot Bust */}
            <g transform="translate(0, 5)">
              {/* Skin */}
              <path d="M 44,65 L 56,65 L 53,75 L 47,75 Z" fill="#fed7aa" />
              <path d="M 35,45 Q 35,24 50,24 Q 65,24 65,45 Q 65,63 50,63 Q 35,63 35,45 Z" fill="#fed7aa" />
              
              {/* Mascot Hair */}
              <path d="M 36,35 L 30,28 L 39,26 L 41,15 L 48,22 L 53,12 L 58,22 L 67,16 L 64,28 L 71,28 L 65,39 L 61,35 Q 50,42 36,35 Z" fill="#0f172a" />
              
              {/* Hoodie / Clothes */}
              <path d="M 28,78 Q 50,90 72,78 L 68,96 Q 50,105 32,96 Z" fill="#1e293b" stroke="#3b82f6" strokeWidth="2" />
              {/* Hoodie Collar Zipper details */}
              <path d="M 46,75 L 54,75 L 50,92 Z" fill="#0f172a" />
              <line x1="50" y1="75" x2="50" y2="88" stroke="#ffffff" strokeWidth="1.5" />
              <rect x="48.5" y="86" width="3" height="5" rx="1" fill="#cbd5e1" />
              
              {/* Face details */}
              <ellipse cx="44" cy="43" rx="3" ry="4" fill="#0f172a" />
              <ellipse cx="56" cy="43" rx="3" ry="4" fill="#0f172a" />
              <circle cx="45" cy="41.5" r="1" fill="#ffffff" />
              <circle cx="57" cy="41.5" r="1" fill="#ffffff" />
              <path d="M 44,52 Q 50,58 56,52" stroke="#0f172a" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            </g>

            {/* Glowing clock held by mascot on the left of the badge */}
            <g transform="translate(62, 58) scale(0.35)">
              <circle cx="50" cy="50" r="48" fill="#090d16" stroke="#3b82f6" strokeWidth="10" className="drop-shadow-[0_0_8px_rgba(59,130,246,0.6)]" />
              <circle cx="50" cy="50" r="38" fill="#ffffff" />
              <line x1="50" y1="50" x2="50" y2="22" stroke="#0f172a" strokeWidth="9" strokeLinecap="round" transform={`rotate(${hourAngle} 50 50)`} />
              <line x1="50" y1="50" x2="74" y2="50" stroke="#0f172a" strokeWidth="6" strokeLinecap="round" transform={`rotate(${minuteAngle} 50 50)`} />
              <circle cx="50" cy="50" r="4.5" fill="#2563eb" />
            </g>

            <defs>
              <linearGradient id="logo-bg-grad" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#0f172a" />
                <stop offset="100%" stopColor="#0284c7" />
              </linearGradient>
            </defs>
          </svg>
        </div>
        <div className="flex flex-col">
          <span className="font-black text-white tracking-tighter text-sm uppercase font-mono leading-none">
            Cronos
          </span>
          <span className="text-[7px] font-bold text-blue-400 uppercase tracking-widest mt-0.5 leading-none">
            Inteligência Operacional
          </span>
        </div>
      </div>
    );
  }

  // Render full-scale layout ("A cara do app")
  return (
    <div className={`relative flex flex-col items-center ${className}`}>
      
      {/* Outer Glow container replicating the gorgeous dark circular layout */}
      <div 
        className="relative bg-slate-950/80 rounded-full border-[6px] border-blue-500/40 p-1 flex items-center justify-center shadow-[0_0_50px_rgba(37,99,235,0.25)] select-none aspect-square overflow-hidden w-full"
        style={{ maxWidth: size || 360, maxHeight: size || 360 }}
      >
        <svg viewBox="0 0 400 400" className="w-full h-full relative z-10">
          <defs>
            <linearGradient id="circleGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#080e1a" />
              <stop offset="60%" stopColor="#03060c" />
              <stop offset="100%" stopColor="#010306" />
            </linearGradient>
            
            <linearGradient id="neonGlow" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#3b82f6" />
              <stop offset="100%" stopColor="#06b6d4" />
            </linearGradient>
            
            <linearGradient id="mascotSkin" x1="0%" y1="0%" x2="0%" y2="100%">
              <stop offset="0%" stopColor="#ffedd5" />
              <stop offset="100%" stopColor="#fed7aa" />
            </linearGradient>
          </defs>

          {/* Deep Dark Circle Base */}
          <circle cx="200" cy="200" r="190" fill="url(#circleGrad)" stroke="url(#neonGlow)" strokeWidth="4" />

          {/* Background Elements: Industrial Chimneys and factory silhouettes (Left) */}
          <g opacity="0.15" transform="translate(25, 90)">
            {/* Smoke plume from chimneys */}
            <path d="M 40,30 Q 30,15 20,20 Q 10,25 0,15" stroke="#475569" strokeWidth="4" fill="none" strokeLinecap="round" className="animate-pulse" />
            <path d="M 65,20 Q 55,-5 45,5 Q 35,15 25,5" stroke="#475569" strokeWidth="4" fill="none" strokeLinecap="round" className="animate-pulse" style={{ animationDelay: '0.5s' }} />
            
            {/* Factory building outline */}
            <path d="M 10,130 L 10,60 L 40,60 L 40,130 Z" fill="#3b82f6" />
            <path d="M 40,130 L 40,40 L 65,40 L 65,130 Z" fill="#2563eb" />
            <path d="M 65,130 L 65,80 L 110,80 L 110,130 Z" fill="#1d4ed8" />
            <line x1="10" y1="130" x2="140" y2="130" stroke="#475569" strokeWidth="3" />
          </g>

          {/* Background Elements: Bar Chart & Upward Trend Arrow (Right) */}
          <g opacity="0.15" transform="translate(260, 100)">
            {/* Bar chart pillars */}
            <rect x="10" y="80" width="14" height="40" rx="3" fill="#3b82f6" />
            <rect x="32" y="55" width="14" height="65" rx="3" fill="#3b82f6" />
            <rect x="54" y="25" width="14" height="95" rx="3" fill="#06b6d4" />
            
            {/* Upward trend arrow */}
            <path d="M 5,90 L 25,60 L 45,65 L 75,15" fill="none" stroke="#22c55e" strokeWidth="4" strokeLinecap="round" />
            <path d="M 63,17 L 75,15 L 73,27" fill="none" stroke="#22c55e" strokeWidth="4" strokeLinecap="round" />
          </g>

          {/* Background Elements: Warehouse & Truck silhouette (Lower Right) */}
          <g opacity="0.12" transform="translate(230, 190)">
            {/* Warehouse building */}
            <path d="M 10,80 L 10,40 L 70,30 L 120,40 L 120,80 Z" fill="#475569" />
            <rect x="25" y="50" width="30" height="30" fill="#1e293b" />
            {/* Delivery truck */}
            <rect x="65" y="60" width="40" height="20" rx="2" fill="#3b82f6" />
            <rect x="105" y="66" width="10" height="14" rx="1" fill="#3b82f6" />
            <circle cx="75" cy="80" r="5" fill="#000000" />
            <circle cx="100" cy="80" r="5" fill="#000000" />
          </g>

          {/* MASCOT BODY & DETAILS */}
          <g transform="translate(0, -5)">
            
            {/* Thumbs-up Hand (Left side of character, viewer's right) */}
            <g transform="translate(265, 195) scale(0.95)" className="hover:scale-105 transition-all">
              {/* Arm/Sleeve */}
              <path d="M 0,35 Q -30,20 -50,15" stroke="#0f172a" strokeWidth="22" strokeLinecap="round" fill="none" />
              <path d="M 0,35 Q -30,20 -50,15" stroke="#1e293b" strokeWidth="18" strokeLinecap="round" fill="none" />
              {/* Cuff */}
              <path d="M 0,35 Q -3,31 -5,27" stroke="#3b82f6" strokeWidth="2" fill="none" />
              {/* Hand Fist */}
              <circle cx="5" cy="18" r="14" fill="url(#mascotSkin)" />
              {/* Thumbs up finger */}
              <path d="M 5,10 Q 5,-14 12,-12 Q 18,-10 12,8 Z" fill="url(#mascotSkin)" stroke="#ea580c" strokeWidth="1" />
              {/* Other fingers folded */}
              <rect x="-6" y="10" width="12" height="6" rx="2" fill="#fed7aa" />
              <rect x="-4" y="15" width="12" height="6" rx="2" fill="#fdba74" />
              <rect x="-2" y="20" width="12" height="6" rx="2" fill="#fdba74" />
            </g>

            {/* Mascot Torso (Hoodie jacket) */}
            <path d="M 110,340 Q 200,310 290,340 L 260,250 Q 200,240 140,250 Z" fill="#1e293b" stroke="#3b82f6" strokeWidth="2.5" />
            
            {/* Zip detail and neck */}
            <path d="M 185,255 L 215,255 L 200,320 Z" fill="#0f172a" />
            <line x1="200" y1="255" x2="200" y2="305" stroke="#ffffff" strokeWidth="2" strokeLinecap="round" />
            <rect x="197" y="300" width="6" height="10" rx="1.5" fill="#cbd5e1" />

            {/* Big 'C' Cronos logo on the center-right of chest */}
            <g transform="translate(215, 265) scale(0.4)">
              <circle cx="30" cy="30" r="28" fill="#1e293b" stroke="#3b82f6" strokeWidth="4" />
              <path d="M 45,20 A 18,18 0 1,0 45,40" stroke="#ffffff" strokeWidth="7" fill="none" strokeLinecap="round" />
              <circle cx="30" cy="30" r="3" fill="#60a5fa" />
              <line x1="30" y1="30" x2="30" y2="18" stroke="#60a5fa" strokeWidth="3" strokeLinecap="round" />
              <line x1="30" y1="30" x2="42" y2="30" stroke="#60a5fa" strokeWidth="3" strokeLinecap="round" />
            </g>

            {/* Mascot Neck & Head */}
            <path d="M 180,245 L 220,245 L 210,215 L 190,215 Z" fill="url(#mascotSkin)" />
            {/* Shadow under chin */}
            <path d="M 180,215 Q 200,230 220,215 Q 200,250 180,215 Z" fill="#ea580c" opacity="0.15" />

            {/* Mascot Head Face */}
            <path d="M 152,160 Q 152,100 200,100 Q 248,100 248,160 Q 248,210 200,210 Q 152,210 152,160 Z" fill="url(#mascotSkin)" stroke="#ea580c" strokeWidth="0.5" />

            {/* Ears */}
            <circle cx="149" cy="165" r="10" fill="url(#mascotSkin)" />
            <circle cx="251" cy="165" r="10" fill="url(#mascotSkin)" />
            <circle cx="149" cy="165" r="6" fill="#fdba74" opacity="0.6" />
            <circle cx="251" cy="165" r="6" fill="#fdba74" opacity="0.6" />

            {/* Dark Messy Hair */}
            <path d="M 148,150 Q 140,110 165,90 Q 180,60 200,75 Q 220,55 235,90 Q 255,100 252,145 Q 235,105 200,105 Q 165,105 148,150 Z" fill="#1e293b" />
            <path d="M 145,130 L 132,112 L 152,110 L 154,80 L 172,98 L 186,72 L 200,98 L 222,82 L 215,110 L 235,100 L 228,124 L 244,116 L 234,142 L 215,132 Q 200,150 145,130 Z" fill="#0f172a" />

            {/* Expressive Thick Mascot Eyebrows */}
            <path d="M 166,134 Q 178,128 188,135" stroke="#0f172a" strokeWidth="4.5" strokeLinecap="round" fill="none" />
            <path d="M 234,134 Q 222,128 212,135" stroke="#0f172a" strokeWidth="4.5" strokeLinecap="round" fill="none" />

            {/* Friendly Mascot Eyes */}
            <ellipse cx="180" cy="152" rx="7" ry="10" fill="#0f172a" />
            <ellipse cx="220" cy="152" rx="7" ry="10" fill="#0f172a" />
            {/* Eye highlights */}
            <circle cx="182" cy="148" r="3" fill="#ffffff" />
            <circle cx="222" cy="148" r="3" fill="#ffffff" />
            <circle cx="177" cy="156" r="1.2" fill="#ffffff" />
            <circle cx="217" cy="156" r="1.2" fill="#ffffff" />

            {/* Small Cute Nose */}
            <path d="M 197,166 Q 200,172 203,166" stroke="#ea580c" strokeWidth="2.5" strokeLinecap="round" fill="none" />

            {/* Huge Happy Smile */}
            <path d="M 178,180 Q 200,198 222,180" stroke="#0f172a" strokeWidth="4.5" strokeLinecap="round" fill="none" />
            <path d="M 179,181 Q 200,206 221,181 Z" fill="#ffffff" />
            {/* Rosy blush cheeks */}
            <circle cx="165" cy="172" r="6" fill="#fca5a5" opacity="0.6" />
            <circle cx="235" cy="172" r="6" fill="#fca5a5" opacity="0.6" />

            {/* Hand Holding Wall Clock (Viewer's Left, character's right) */}
            <g transform="translate(115, 195) scale(0.95)" className="hover:scale-105 transition-all">
              {/* Arm sleeve */}
              <path d="M 0,35 Q 30,22 55,20" stroke="#0f172a" strokeWidth="22" strokeLinecap="round" fill="none" />
              <path d="M 0,35 Q 30,22 55,20" stroke="#1e293b" strokeWidth="18" strokeLinecap="round" fill="none" />
              {/* Hand supporting clock */}
              <circle cx="58" cy="18" r="14" fill="url(#mascotSkin)" />
              {/* Fingers wrapping */}
              <circle cx="48" cy="8" r="4.5" fill="#fdba74" />
              <circle cx="44" cy="16" r="4.5" fill="#fdba74" />
              <circle cx="46" cy="24" r="4.5" fill="#fdba74" />
            </g>

            {/* WALL CLOCK HELD BY MASCOT (Real time ticking) */}
            <g transform="translate(112, 178) scale(1.05)" className="filter drop-shadow-[0_8px_16px_rgba(0,0,0,0.5)]">
              {/* Black Outer Bezel */}
              <circle cx="0" cy="0" r="46" fill="#111827" stroke="#3b82f6" strokeWidth="6" className="drop-shadow-[0_0_8px_rgba(59,130,246,0.5)]" />
              <circle cx="0" cy="0" r="40" fill="#ffffff" />
              
              {/* Small 'C' inside clock at 12 position */}
              <path d="M 4,-26 A 4,4 0 1,0 4,-18" stroke="#3b82f6" strokeWidth="2.5" fill="none" />
              
              {/* Clock Tick Marks */}
              {[-90, -60, -30, 0, 30, 60, 90, 120, 150, 180, 210, 240].map((deg) => (
                <line 
                  key={deg} 
                  x1="0" y1="-38" x2="0" y2="-34" 
                  stroke={deg % 90 === 0 ? "#1e293b" : "#94a3b8"} 
                  strokeWidth={deg % 90 === 0 ? "3.5" : "1.5"} 
                  transform={`rotate(${deg} 0 0)`} 
                />
              ))}

              {/* Hour Hand (Dynamic) */}
              <line x1="0" y1="0" x2="0" y2="-21" stroke="#1e293b" strokeWidth="5.5" strokeLinecap="round" transform={`rotate(${hourAngle} 0 0)`} />
              {/* Minute Hand (Dynamic) */}
              <line x1="0" y1="0" x2="0" y2="-32" stroke="#1e293b" strokeWidth="3.5" strokeLinecap="round" transform={`rotate(${minuteAngle} 0 0)`} />
              {/* Second Hand (Dynamic Neon Blue ticking) */}
              <line x1="0" y1="8" x2="0" y2="-35" stroke="#00d2ff" strokeWidth="1.5" strokeLinecap="round" transform={`rotate(${secondAngle} 0 0)`} />
              
              {/* Center Cap Pin */}
              <circle cx="0" cy="0" r="3.5" fill="#3b82f6" />
              <circle cx="0" cy="0" r="1.5" fill="#ffffff" />
            </g>

          </g>

          {/* LOWER GRAPHICS: Logo & Slogan inside the circular badge */}
          <g transform="translate(0, 240)">
            
            {/* "CRONOS" logo - customized styled display type */}
            <text 
              x="200" 
              y="60" 
              fill="#ffffff" 
              fontSize="48" 
              fontWeight="900" 
              fontFamily="'Montserrat', sans-serif" 
              letterSpacing="-1.5" 
              textAnchor="middle" 
              fontStyle="italic"
              className="drop-shadow-[0_4px_12px_rgba(59,130,246,0.3)]"
            >
              CRONOS
            </text>
            
            {/* Underline gradient bar */}
            <rect x="110" y="70" width="180" height="2" fill="url(#neonGlow)" rx="1" />

            {/* "INTELIGÊNCIA OPERACIONAL" subtitle */}
            <text 
              x="200" 
              y="88" 
              fill="#60a5fa" 
              fontSize="10" 
              fontWeight="900" 
              fontFamily="'Montserrat', sans-serif" 
              letterSpacing="6" 
              textAnchor="middle"
            >
              INTELIGÊNCIA OPERACIONAL
            </text>
          </g>
        </svg>

        {/* Ambient pulse inside the badge */}
        <div className="absolute inset-0 pointer-events-none rounded-full border border-blue-500/10 animate-ping opacity-25" style={{ animationDuration: '4s' }} />
      </div>

      {/* THREE VALUE PILL BLOCKS (Matching the bottom of the uploaded character card) */}
      <div className="w-full max-w-lg mt-8 grid grid-cols-3 gap-3">
        {/* TEMPO */}
        <div className="flex flex-col items-center p-3 rounded-2xl bg-gray-900/60 border border-white/[0.04] text-center hover:bg-gray-900 hover:border-blue-500/20 transition-all group">
          <div className="w-8 h-8 rounded-full bg-blue-500/10 flex items-center justify-center text-blue-400 mb-1.5 group-hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5">
              <circle cx="12" cy="12" r="10" />
              <polyline points="12 6 12 12 16 14" />
            </svg>
          </div>
          <span className="text-[9px] font-black text-white uppercase tracking-wider">Tempo</span>
          <span className="text-[7.5px] font-bold text-slate-400 uppercase mt-0.5 tracking-tight">Com Propósito</span>
        </div>

        {/* DADOS */}
        <div className="flex flex-col items-center p-3 rounded-2xl bg-gray-900/60 border border-white/[0.04] text-center hover:bg-gray-900 hover:border-cyan-500/20 transition-all group">
          <div className="w-8 h-8 rounded-full bg-cyan-500/10 flex items-center justify-center text-cyan-400 mb-1.5 group-hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5">
              <line x1="18" y1="20" x2="18" y2="10" />
              <line x1="12" y1="20" x2="12" y2="4" />
              <line x1="6" y1="20" x2="6" y2="14" />
            </svg>
          </div>
          <span className="text-[9px] font-black text-white uppercase tracking-wider">Dados</span>
          <span className="text-[7.5px] font-bold text-slate-400 uppercase mt-0.5 tracking-tight">Que Geram Decisões</span>
        </div>

        {/* EFICIÊNCIA */}
        <div className="flex flex-col items-center p-3 rounded-2xl bg-gray-900/60 border border-white/[0.04] text-center hover:bg-gray-900 hover:border-emerald-500/20 transition-all group">
          <div className="w-8 h-8 rounded-full bg-emerald-500/10 flex items-center justify-center text-emerald-400 mb-1.5 group-hover:scale-110 transition-transform">
            <svg viewBox="0 0 24 24" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.1a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z" />
              <circle cx="12" cy="12" r="3" />
            </svg>
          </div>
          <span className="text-[9px] font-black text-white uppercase tracking-wider">Eficiência</span>
          <span className="text-[7.5px] font-bold text-slate-400 uppercase mt-0.5 tracking-tight">Que Move Resultados</span>
        </div>
      </div>

      {/* ELEGANT HANDWRITTEN ITALIC SLOGAN */}
      <p 
        className="mt-6 text-2xl text-blue-400 italic text-center select-none tracking-wide"
        style={{ fontFamily: "'Caveat', cursive" }}
      >
        Cada minuto conta.
      </p>
    </div>
  );
};

export default CronosMascot;
