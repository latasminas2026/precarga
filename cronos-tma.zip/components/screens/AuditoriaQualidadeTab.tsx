import React, { useState, useMemo } from 'react';
import { TMALogEntry, TMAConfig, MetricQualityStats } from '../../types';
import { 
    validateDuration, 
    calculateMetricQualityStats, 
    formatDurationHuman, 
    secondsToTimeStr, 
    secondsToTimeStrShort 
} from '../../tmaEngine';
import ShieldCheckIcon from '../icons/ShieldCheckIcon';
import ClockIcon from '../icons/ClockIcon';
import FilterIcon from '../icons/FilterIcon';
import SearchIcon from '../icons/SearchIcon';
import DownloadIcon from '../icons/DownloadIcon';

interface AuditoriaQualidadeTabProps {
    entries: TMALogEntry[];
    tmaConfig: TMAConfig;
    reportDate: string;
}

export const AuditoriaQualidadeTab: React.FC<AuditoriaQualidadeTabProps> = ({
    entries,
    tmaConfig,
    reportDate
}) => {
    const [searchTerm, setSearchTerm] = useState('');
    const [statusFilter, setStatusFilter] = useState<'ALL' | 'INCOMPLETE_OR_ALERT' | 'OUTLIERS_ONLY' | 'VALID_ONLY'>('ALL');

    // Estatísticas consolidadas por indicador
    const qualityStats = useMemo(() => {
        return {
            tmfi: calculateMetricQualityStats(entries, 'tmfi', 'TMFI (Fila Interna)', tmaConfig.tmfiTarget),
            tmc: calculateMetricQualityStats(entries, 'tmc', 'TMC (Carregamento Doca)', tmaConfig.tmcTarget),
            tmfs: calculateMetricQualityStats(entries, 'tmfs', 'TMFS / TMS (Fila Saída)', tmaConfig.tmsTarget),
            total: calculateMetricQualityStats(entries, 'total', 'Tempo Total Fábrica', tmaConfig.totalTarget),
            tmfe: calculateMetricQualityStats(entries, 'tmfe', 'TMFE (Fila Externa BI)', tmaConfig.tmfeTarget),
            tmpc: calculateMetricQualityStats(entries, 'tmpc', 'TMPC (Pós-Carga BI)', tmaConfig.tmpcTarget),
            totalOperations: entries.length
        };
    }, [entries, tmaConfig]);

    // Filtragem dos registros da tabela de auditoria
    const filteredAuditEntries = useMemo(() => {
        return entries.filter(e => {
            const matchesSearch = !searchTerm || 
                e.placa.toUpperCase().includes(searchTerm.toUpperCase()) || 
                e.transportadora.toUpperCase().includes(searchTerm.toUpperCase());

            if (!matchesSearch) return false;

            const tmfiVal = e.tmfiValidation || validateDuration(e.tmfi);
            const tmcVal = e.tmcValidation || validateDuration(e.tmc);
            const tmfsVal = e.tmfsValidation || e.tmsValidation || validateDuration(e.tms);
            const totalVal = e.totalValidation || validateDuration(e.total);

            const hasOutlier = tmfiVal.outlier || tmcVal.outlier || tmfsVal.outlier || totalVal.outlier || e.isOutlier;
            const hasInvalid = !tmfiVal.includeInTMA || !tmcVal.includeInTMA || !tmfsVal.includeInTMA || !totalVal.includeInTMA;
            const allValid = tmfiVal.includeInTMA && tmcVal.includeInTMA && tmfsVal.includeInTMA && totalVal.includeInTMA && !hasOutlier;

            if (statusFilter === 'OUTLIERS_ONLY') {
                return hasOutlier;
            }
            if (statusFilter === 'INCOMPLETE_OR_ALERT') {
                return hasInvalid || hasOutlier;
            }
            if (statusFilter === 'VALID_ONLY') {
                return allValid;
            }

            return true;
        });
    }, [entries, searchTerm, statusFilter]);

    const handleExportAuditCSV = () => {
        if (filteredAuditEntries.length === 0) {
            alert('Não há registros para exportar.');
            return;
        }

        const headers = [
            'Placa',
            'Transportadora',
            'Operacao',
            'Turno',
            'TMFI_Valor',
            'TMFI_Status',
            'TMFI_Incluido',
            'TMC_Valor',
            'TMC_Status',
            'TMC_Incluido',
            'TMFS_Valor',
            'TMFS_Status',
            'TMFS_Incluido',
            'Total_Valor',
            'Total_Status',
            'Total_Incluido',
            'Outlier_Geral',
            'Motivo_Invalidez'
        ];

        const rows = filteredAuditEntries.map(e => {
            const tmfi = e.tmfiValidation || validateDuration(e.tmfi);
            const tmc = e.tmcValidation || validateDuration(e.tmc);
            const tmfs = e.tmfsValidation || e.tmsValidation || validateDuration(e.tms);
            const total = e.totalValidation || validateDuration(e.total);

            const isOutlier = tmfi.outlier || tmc.outlier || tmfs.outlier || total.outlier || e.isOutlier;

            return [
                `"${e.placa}"`,
                `"${e.transportadora}"`,
                `"${e.operacao || 'CARGA LATAS'}"`,
                e.turno,
                `"${tmfi.formatted}"`,
                `"${tmfi.status}"`,
                tmfi.includeInTMA ? 'SIM' : 'NAO',
                `"${tmc.formatted}"`,
                `"${tmc.status}"`,
                tmc.includeInTMA ? 'SIM' : 'NAO',
                `"${tmfs.formatted}"`,
                `"${tmfs.status}"`,
                tmfs.includeInTMA ? 'SIM' : 'NAO',
                `"${total.formatted}"`,
                `"${total.status}"`,
                total.includeInTMA ? 'SIM' : 'NAO',
                isOutlier ? 'SIM' : 'NAO',
                `"${e.motivoInvalidezGeral || (isOutlier ? 'Outlier >= 23h' : 'OK')}"`
            ];
        });

        const csvContent = "data:text/csv;charset=utf-8,"
            + headers.join(',') + '\n'
            + rows.map(r => r.join(',')).join('\n');

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `auditoria_qualidade_tma_${reportDate.replace(/\//g, '-')}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const renderMetricCard = (stats: MetricQualityStats, colorClass: string, borderClass: string) => {
        const avgDisplay = stats.averageSeconds !== null ? secondsToTimeStr(stats.averageSeconds) : 'N/D';
        const validPercent = stats.total > 0 ? ((stats.valid / stats.total) * 100).toFixed(1) : '0';

        return (
            <div className={`bg-[#0c0f16]/95 border-t-2 ${borderClass} border-x border-b border-white/[0.06] p-5 rounded-3xl shadow-[0_12px_36px_rgba(0,0,0,0.4)] flex flex-col justify-between relative overflow-hidden group hover:border-white/[0.12] transition-all`}>
                <div>
                    <div className="flex items-center justify-between gap-2 mb-2">
                        <h4 className={`text-xs font-black uppercase tracking-wider ${colorClass}`}>{stats.label}</h4>
                        <span className="text-[10px] font-mono font-bold bg-white/[0.05] text-slate-300 px-2 py-0.5 rounded-md">
                            {validPercent}% Válido
                        </span>
                    </div>
                    
                    <div className="flex items-baseline gap-2 mt-2">
                        <span className="text-2xl xl:text-3xl font-black text-white font-mono leading-none">
                            {avgDisplay}
                        </span>
                        <span className="text-[10px] font-bold text-slate-500 uppercase">Média</span>
                    </div>

                    <p className="text-[10px] text-slate-400 font-mono mt-1">
                        {stats.averageSeconds !== null ? formatDurationHuman(stats.averageSeconds) : 'Sem registros válidos'}
                    </p>
                </div>

                <div className="mt-5 pt-4 border-t border-white/[0.06] grid grid-cols-2 gap-2 text-[10px] font-mono">
                    <div className="flex items-center justify-between text-emerald-400 bg-emerald-950/20 px-2 py-1 rounded">
                        <span>✓ Válidos:</span>
                        <span className="font-bold">{stats.valid}</span>
                    </div>
                    <div className="flex items-center justify-between text-slate-400 bg-white/[0.02] px-2 py-1 rounded">
                        <span>⚪ Vazios:</span>
                        <span className="font-bold">{stats.empty}</span>
                    </div>
                    <div className="flex items-center justify-between text-purple-400 bg-purple-950/20 px-2 py-1 rounded">
                        <span>⚡ Outliers:</span>
                        <span className="font-bold">{stats.outlier}</span>
                    </div>
                    <div className="flex items-center justify-between text-rose-400 bg-rose-950/20 px-2 py-1 rounded">
                        <span>✕ Erros/Neg:</span>
                        <span className="font-bold">{stats.error + stats.negative}</span>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className="space-y-6 animate-fade-in w-full pb-10">
            {/* Banner com as Regras de Negócio e Metodologia Rigorosa */}
            <div className="bg-[#0c0f16]/90 border border-emerald-500/20 bg-gradient-to-r from-emerald-950/20 via-transparent to-blue-950/20 p-6 rounded-3xl shadow-lg relative overflow-hidden">
                <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div className="space-y-1">
                        <div className="flex items-center gap-2">
                            <span className="p-1.5 bg-emerald-500/20 text-emerald-400 rounded-lg border border-emerald-500/30">
                                <ShieldCheckIcon className="w-5 h-5" />
                            </span>
                            <h3 className="text-base font-black text-white uppercase tracking-wider">
                                Motor Centralizado de Validação e Qualidade TMA
                            </h3>
                        </div>
                        <p className="text-xs text-slate-400 max-w-3xl leading-relaxed">
                            Cálculos executados estritamente sob as 27 Regras Operacionais. Cada métrica possui validação isolada (<strong className="text-emerald-400">ausência de um tempo não descarta a operação</strong>), tempos em branco não são convertidos em zero e durações anômalas (≥ 23h) são automaticamente expurgadas.
                        </p>
                    </div>

                    <div className="flex items-center gap-3 shrink-0">
                        <button
                            onClick={handleExportAuditCSV}
                            className="px-4 py-2.5 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.08] text-white rounded-xl text-[10px] font-black uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-md"
                        >
                            <DownloadIcon className="w-4 h-4 text-emerald-400" />
                            Exportar Auditoria CSV
                        </button>
                    </div>
                </div>
            </div>

            {/* Painel de Qualidade dos Dados por Métrica */}
            <div>
                <div className="flex items-center justify-between mb-4">
                    <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                        <ClockIcon className="w-4 h-4 text-emerald-400" />
                        Qualidade dos Dados & Médias Independentes ({qualityStats.totalOperations} Operações)
                    </h3>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                    {renderMetricCard(qualityStats.tmfi, 'text-blue-400', 'border-t-blue-500')}
                    {renderMetricCard(qualityStats.tmc, 'text-emerald-400', 'border-t-emerald-500')}
                    {renderMetricCard(qualityStats.tmfs, 'text-yellow-400', 'border-t-yellow-500')}
                    {renderMetricCard(qualityStats.total, 'text-white', 'border-t-white')}
                </div>
            </div>

            {/* Tabela de Auditoria Linha a Linha */}
            <div className="bg-[#0c0f16]/95 border border-white/[0.08] rounded-3xl shadow-[0_15px_45px_rgba(0,0,0,0.6)] overflow-hidden">
                <div className="p-6 bg-black/40 border-b border-white/[0.06] flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                    <div>
                        <h3 className="text-sm font-black text-white uppercase tracking-wider flex items-center gap-2">
                            Auditoria Linha a Linha das Operações
                        </h3>
                        <p className="text-[11px] text-slate-500 font-bold uppercase mt-0.5">
                            Status individual de validação e inclusão de cada tempo no cálculo das médias
                        </p>
                    </div>

                    <div className="flex flex-wrap items-center gap-3 w-full md:w-auto">
                        <div className="relative flex-1 md:w-64">
                            <SearchIcon className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                            <input
                                type="text"
                                value={searchTerm}
                                onChange={e => setSearchTerm(e.target.value)}
                                placeholder="Filtrar por placa ou transp..."
                                className="w-full pl-10 pr-4 py-2 bg-black/50 border border-white/[0.08] rounded-xl text-xs font-bold text-white placeholder-slate-500 outline-none focus:border-emerald-500 transition-colors"
                            />
                        </div>

                        <div className="relative">
                            <FilterIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-emerald-400 pointer-events-none" />
                            <select
                                value={statusFilter}
                                onChange={e => setStatusFilter(e.target.value as any)}
                                className="pl-9 pr-4 py-2 bg-black/50 border border-white/[0.08] rounded-xl text-[10px] font-black uppercase text-emerald-400 outline-none cursor-pointer"
                            >
                                <option value="ALL" className="bg-[#0a0d14]">Todos os Registros ({entries.length})</option>
                                <option value="INCOMPLETE_OR_ALERT" className="bg-[#0a0d14]">Com Incompletos / Alertas</option>
                                <option value="OUTLIERS_ONLY" className="bg-[#0a0d14]">Somente Outliers (≥23h)</option>
                                <option value="VALID_ONLY" className="bg-[#0a0d14]">100% Válidos</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div className="overflow-x-auto custom-scrollbar">
                    <table className="w-full border-collapse text-left">
                        <thead>
                            <tr className="border-b border-white/[0.06] bg-black/20 text-[10px] font-black text-slate-400 uppercase tracking-wider">
                                <th className="px-4 py-3.5">Placa / Transportadora</th>
                                <th className="px-3 py-3.5 text-center">Turno</th>
                                <th className="px-4 py-3.5 text-center">TMFI (Fila Int)</th>
                                <th className="px-4 py-3.5 text-center">TMC (Doca)</th>
                                <th className="px-4 py-3.5 text-center">TMFS (Saída)</th>
                                <th className="px-4 py-3.5 text-center">Tempo Total</th>
                                <th className="px-4 py-3.5 text-center">Outlier Geral</th>
                                <th className="px-4 py-3.5 text-left">Diagnóstico / Motivo</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/[0.04] text-xs">
                            {filteredAuditEntries.length === 0 ? (
                                <tr>
                                    <td colSpan={8} className="text-center py-10 text-slate-500 font-mono text-xs">
                                        Nenhum registro encontrado para os filtros selecionados.
                                    </td>
                                </tr>
                            ) : (
                                filteredAuditEntries.map((e, idx) => {
                                    const tmfi = e.tmfiValidation || validateDuration(e.tmfi);
                                    const tmc = e.tmcValidation || validateDuration(e.tmc);
                                    const tmfs = e.tmfsValidation || e.tmsValidation || validateDuration(e.tms);
                                    const total = e.totalValidation || validateDuration(e.total);

                                    const isOutlier = tmfi.outlier || tmc.outlier || tmfs.outlier || total.outlier || e.isOutlier;

                                    const renderTimeBadge = (val: typeof tmfi) => {
                                        if (val.includeInTMA) {
                                            return (
                                                <div className="flex flex-col items-center">
                                                    <span className="font-mono font-bold text-white text-xs">{val.formatted}</span>
                                                    <span className="text-[8px] font-black text-emerald-400 uppercase tracking-tighter bg-emerald-950/40 px-1.5 py-0.2 rounded border border-emerald-500/20">
                                                        ✓ Entra no cálculo
                                                    </span>
                                                </div>
                                            );
                                        }
                                        if (val.status === 'VAZIO') {
                                            return (
                                                <div className="flex flex-col items-center opacity-60">
                                                    <span className="font-mono text-slate-500 text-xs">--:--:--</span>
                                                    <span className="text-[8px] font-black text-slate-400 uppercase tracking-tighter bg-white/[0.02] px-1.5 py-0.2 rounded border border-white/[0.05]">
                                                        ⚪ Vazio (Excluído)
                                                    </span>
                                                </div>
                                            );
                                        }
                                        if (val.outlier || val.status === 'OUTLIER') {
                                            return (
                                                <div className="flex flex-col items-center">
                                                    <span className="font-mono font-bold text-purple-400 text-xs">{val.formatted}</span>
                                                    <span className="text-[8px] font-black text-purple-300 uppercase tracking-tighter bg-purple-950/40 px-1.5 py-0.2 rounded border border-purple-500/30">
                                                        ⚡ Outlier (Excluído)
                                                    </span>
                                                </div>
                                            );
                                        }
                                        return (
                                            <div className="flex flex-col items-center">
                                                <span className="font-mono font-bold text-rose-400 text-xs">{val.formatted}</span>
                                                <span className="text-[8px] font-black text-rose-300 uppercase tracking-tighter bg-rose-950/40 px-1.5 py-0.2 rounded border border-rose-500/30">
                                                    ✕ {val.status} (Excluído)
                                                </span>
                                            </div>
                                        );
                                    };

                                    return (
                                        <tr key={e.id || idx} className="hover:bg-white/[0.02] transition-colors">
                                            <td className="px-4 py-3">
                                                <div className="flex flex-col">
                                                    <span className="font-mono font-black text-white text-xs">{e.placa}</span>
                                                    <span className="text-[9px] font-bold text-slate-500 uppercase truncate max-w-[140px]">
                                                        {e.transportadora || 'N/A'}
                                                    </span>
                                                </div>
                                            </td>

                                            <td className="px-3 py-3 text-center">
                                                <span className="font-mono text-[10px] font-bold bg-white/[0.04] text-slate-300 px-2 py-0.5 rounded border border-white/[0.06]">
                                                    {e.turno || 'A'}
                                                </span>
                                            </td>

                                            <td className="px-4 py-3 text-center">
                                                {renderTimeBadge(tmfi)}
                                            </td>

                                            <td className="px-4 py-3 text-center">
                                                {renderTimeBadge(tmc)}
                                            </td>

                                            <td className="px-4 py-3 text-center">
                                                {renderTimeBadge(tmfs)}
                                            </td>

                                            <td className="px-4 py-3 text-center">
                                                {renderTimeBadge(total)}
                                            </td>

                                            <td className="px-4 py-3 text-center">
                                                {isOutlier ? (
                                                    <span className="inline-flex items-center gap-1 text-[9px] font-black text-purple-400 bg-purple-950/40 border border-purple-500/30 px-2 py-0.5 rounded-full uppercase">
                                                        ⚡ Sim
                                                    </span>
                                                ) : (
                                                    <span className="inline-flex items-center gap-1 text-[9px] font-black text-slate-500 uppercase">
                                                        Não
                                                    </span>
                                                )}
                                            </td>

                                            <td className="px-4 py-3">
                                                <p className="text-[10px] font-mono text-slate-400">
                                                    {e.motivoInvalidezGeral || (isOutlier ? 'Tempo ≥ 23h expurgado do indicador específico' : 'Operação 100% Válida')}
                                                </p>
                                            </td>
                                        </tr>
                                    );
                                })
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};
