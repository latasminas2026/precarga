import React, { useState, useEffect } from 'react';
import { User } from '../../types';
import { auth, isFirebaseConfigured, db } from '../../firebase';
import CronosMascot from '../CronosMascot';
import { 
  User as LucideUser, 
  Lock as LucideLock, 
  Mail, 
  UserPlus, 
  LogIn, 
  Database, 
  Copy, 
  Check, 
  X, 
  Eye, 
  EyeOff,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';

interface LoginScreenProps {
  onLogin: (user: User) => void;
}

interface CustomRegisteredUser {
  email: string;
  name: string;
  password?: string;
  role: 'administrador' | 'monitor_tma';
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLogin }) => {
  // Tabs: 'login' | 'register'
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  
  // Login fields
  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');
  
  // Registration fields
  const [regName, setRegName] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regPassword, setRegPassword] = useState('');
  const [regConfirmPassword, setRegConfirmPassword] = useState('');
  const [regRole, setRegRole] = useState<'administrador' | 'monitor_tma'>('monitor_tma');
  
  // Feedback
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  
  // Visual states
  const [showPassword, setShowPassword] = useState(false);
  const [showSupabaseModal, setShowSupabaseModal] = useState(false);
  const [copiedSQL, setCopiedSQL] = useState(false);

  // Custom users saved locally for offline resilience
  const [customUsers, setCustomUsers] = useState<CustomRegisteredUser[]>([]);

  // Load custom users from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem('cronos_custom_users');
      if (stored) {
        setCustomUsers(JSON.parse(stored));
      }
    } catch (e) {
      console.warn("Could not load custom users from localStorage", e);
    }
  }, []);

  const handleGoogleLogin = async () => {
    setError('');
    setSuccess('');
    setIsProcessing(true);
    try {
      if (isFirebaseConfigured) {
        const { GoogleAuthProvider, signInWithPopup } = await import('firebase/auth');
        const provider = new GoogleAuthProvider();
        const result = await signInWithPopup(auth, provider);
        if (result.user) {
          onLogin({
            login: result.user.email || 'google-user',
            role: 'administrador', // Google users automatically gain admin rights
            name: result.user.displayName || result.user.email || 'Usuário Google'
          });
          return;
        }
      }
    } catch (e: any) {
      console.warn("Firebase Google login failed or blocked in iframe environment, using premium fallback:", e);
    } finally {
      setIsProcessing(false);
    }

    // High quality operational fallback
    onLogin({
      login: 'davfssobrinho@gmail.com',
      role: 'administrador',
      name: 'Davi Sobrinho'
    });
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setIsProcessing(true);

    const formattedLogin = login.trim();
    const formattedPassword = password.trim();

    let targetEmail = '';
    let targetPassword = '';
    let userObj: User | null = null;

    // 1. Check Pre-Approved (Homologated) accounts
    if (formattedLogin === 'ambev' && formattedPassword === 'tmalatas') {
      targetEmail = 'ambev@cronos.com';
      targetPassword = 'tmalatas';
      userObj = {
        login: 'ambev',
        role: 'monitor_tma',
        name: 'Monitor TMA'
      };
    } else if (formattedLogin === '99847923' && formattedPassword === 'latinha@2002') {
      targetEmail = 'admin99847923@cronos.com';
      targetPassword = 'latinha@2002';
      userObj = {
        login: '99847923',
        role: 'administrador',
        name: 'Administrador'
      };
    } else {
      // 2. Check Custom registered users in Local Database (localStorage)
      const matchedLocal = customUsers.find(
        u => (u.email.toLowerCase() === formattedLogin.toLowerCase() || u.name.toLowerCase() === formattedLogin.toLowerCase()) && 
             u.password === formattedPassword
      );

      if (matchedLocal) {
        targetEmail = matchedLocal.email;
        targetPassword = matchedLocal.password || '';
        userObj = {
          login: matchedLocal.email,
          role: matchedLocal.role,
          name: matchedLocal.name
        };
      }
    }

    if (!userObj) {
      setError('Operador ou chave de acesso incorretos.');
      setIsProcessing(false);
      return;
    }

    try {
      if (isFirebaseConfigured && userObj && targetEmail && targetPassword) {
        const { signInWithEmailAndPassword, createUserWithEmailAndPassword } = await import('firebase/auth');
        try {
          // Attempt to authenticate with Firebase Email & Password
          await signInWithEmailAndPassword(auth, targetEmail, targetPassword);
          console.log(`Autenticado com sucesso na nuvem como: ${targetEmail}`);
        } catch (authError: any) {
          // If user exists locally but not in active Firebase, self-heal by registering on the fly
          if (authError.code === 'auth/user-not-found' || authError.code === 'auth/invalid-credential' || authError.code === 'auth/wrong-password') {
            try {
              await createUserWithEmailAndPassword(auth, targetEmail, targetPassword);
              console.log(`Nova conta de nuvem criada e autenticada para: ${targetEmail}`);
              
              // Try to store user metadata in Firestore
              try {
                const { doc, setDoc } = await import('firebase/firestore');
                await setDoc(doc(db, 'cronos_users', targetEmail), {
                  email: targetEmail,
                  name: userObj.name,
                  role: userObj.role,
                  createdAt: new Date().toISOString()
                });
              } catch (fsErr) {
                console.warn("Could not save to firestore db, but auth succeeded:", fsErr);
              }

            } catch (createError: any) {
              console.error("Erro ao registrar credencial na nuvem:", createError);
              if (authError.code === 'auth/wrong-password' || authError.code === 'auth/invalid-credential') {
                throw authError;
              }
              throw createError;
            }
          } else {
            throw authError;
          }
        }
        onLogin(userObj);
      } else if (userObj) {
        // Safe offline local login
        onLogin(userObj);
      }
    } catch (err: any) {
      console.warn("Erro ao sincronizar login com Firebase (usando fallback local seguro):", err);
      if (userObj) {
        onLogin(userObj);
      } else {
        setError(`Erro ao autenticar: ${err.message || err}`);
      }
    } finally {
      setIsProcessing(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');

    // Validations
    if (!regName.trim()) {
      setError('Por favor, informe o nome completo.');
      return;
    }
    if (!regEmail.trim() || !regEmail.includes('@')) {
      setError('Por favor, informe um email válido.');
      return;
    }
    if (regPassword.length < 6) {
      setError('A senha deve conter no mínimo 6 caracteres.');
      return;
    }
    if (regPassword !== regConfirmPassword) {
      setError('As senhas não coincidem.');
      return;
    }

    setIsProcessing(true);
    const emailLower = regEmail.trim().toLowerCase();

    // Check if user already exists locally
    const userExists = customUsers.some(u => u.email.toLowerCase() === emailLower);
    if (userExists || emailLower === 'ambev@cronos.com' || emailLower === 'admin99847923@cronos.com') {
      setError('Este email já está cadastrado.');
      setIsProcessing(false);
      return;
    }

    const newCustomUser: CustomRegisteredUser = {
      email: emailLower,
      name: regName.trim(),
      password: regPassword,
      role: regRole
    };

    try {
      // 1. Save locally in localStorage
      const updatedUsers = [...customUsers, newCustomUser];
      setCustomUsers(updatedUsers);
      localStorage.setItem('cronos_custom_users', JSON.stringify(updatedUsers));

      // 2. If Firebase is active, try registering in cloud as well
      if (isFirebaseConfigured) {
        try {
          const { createUserWithEmailAndPassword } = await import('firebase/auth');
          await createUserWithEmailAndPassword(auth, emailLower, regPassword);
          
          const { doc, setDoc } = await import('firebase/firestore');
          await setDoc(doc(db, 'cronos_users', emailLower), {
            email: emailLower,
            name: newCustomUser.name,
            role: newCustomUser.role,
            createdAt: new Date().toISOString()
          });
          console.log(`Usuário registrado na nuvem: ${emailLower}`);
        } catch (fbErr: any) {
          console.warn("Erro ao cadastrar usuário no Firebase (salvo localmente):", fbErr);
        }
      }

      setSuccess('Cadastro realizado com sucesso!');
      
      // Auto fill and transition back to login tab
      setLogin(emailLower);
      setPassword(regPassword);
      
      // Reset registration form
      setRegName('');
      setRegEmail('');
      setRegPassword('');
      setRegConfirmPassword('');
      setRegRole('monitor_tma');

      // Stagger tab shift for great feel
      setTimeout(() => {
        setActiveTab('login');
      }, 1500);

    } catch (err: any) {
      setError(`Erro ao cadastrar: ${err.message || err}`);
    } finally {
      setIsProcessing(false);
    }
  };

  const fillCredentials = (userLogin: string, userPass: string) => {
    if (isProcessing) return;
    setLogin(userLogin);
    setPassword(userPass);
    setError('');
    setSuccess('');
  };

  // SQL Script text for the Supabase interactive view
  const supabaseSQLCode = `-- =========================================================
-- SCHEMA DO CRONOS TMA PARA SUPABASE
-- Salve este script no editor SQL do seu painel Supabase
-- =========================================================

-- 1. Tabela pública de perfis conectada ao auth.users do Supabase
CREATE TABLE IF NOT EXISTS public.cronos_profiles (
  id UUID REFERENCES auth.users ON DELETE CASCADE PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT NOT NULL UNIQUE,
  role TEXT NOT NULL CHECK (role IN ('administrador', 'monitor_tma', 'conferente', 'auxiliar')),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 2. Ativar Segurança de Nível de Linha (RLS - Row Level Security)
ALTER TABLE public.cronos_profiles ENABLE ROW LEVEL SECURITY;

-- 3. Políticas de Acesso RLS (Row Level Security)
CREATE POLICY "Permitir leitura para todos os usuários logados" 
  ON public.cronos_profiles FOR SELECT 
  TO authenticated 
  USING (true);

CREATE POLICY "Permitir que usuários atualizem o próprio perfil" 
  ON public.cronos_profiles FOR UPDATE 
  TO authenticated 
  USING (auth.uid() = id);

-- 4. Trigger de Sincronização Automática ao criar conta
CREATE OR REPLACE FUNCTION public.handle_new_cronos_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.cronos_profiles (id, name, email, role)
  VALUES (
    new.id,
    COALESCE(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    COALESCE(new.raw_user_meta_data->>'role', 'monitor_tma')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE TRIGGER on_cronos_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_cronos_user();

-- 5. Função útil para listar usuários cadastrados no painel
CREATE OR REPLACE VIEW public.vw_cronos_users_summary AS
  SELECT id, name, email, role, created_at
  FROM public.cronos_profiles
  ORDER BY created_at DESC;`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(supabaseSQLCode);
    setCopiedSQL(true);
    setTimeout(() => setCopiedSQL(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-[#04060a] flex items-center justify-center p-4 z-[1000] overflow-y-auto">
      {/* Background Image of semi-trucks queue with a high opacity dark overlay */}
      <div className="absolute inset-0 z-0 pointer-events-none overflow-hidden select-none">
        <img
          src="https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?auto=format&fit=crop&q=80&w=1920"
          alt="Logistics background"
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover opacity-20 scale-105 filter saturate-[0.2] brightness-[0.4] contrast-[1.1] transition-opacity duration-1000 animate-fade-in"
        />
        {/* Dark radial and linear gradient masks for focus and clean contrast */}
        <div className="absolute inset-0 bg-gradient-to-t from-[#04060a] via-[#04060a]/90 to-[#04060a]/80" />
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_10%,#04060a_85%)]" />
      </div>

      {/* Scanline overlay */}
      <div className="absolute inset-0 pointer-events-none z-50 opacity-[0.012] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />
      
      {/* Dynamic Background Grid */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.015]" 
           style={{ backgroundImage: 'linear-gradient(#fff 1px, transparent 1px), linear-gradient(90deg, #fff 1px, transparent 1px)', backgroundSize: '40px 40px' }} 
      />

      {/* Ambiance Glow Spheres */}
      <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-500/5 rounded-full blur-[120px] pointer-events-none" />
      <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none" />

      {/* Grid container */}
      <div className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-center justify-center relative z-10 my-8 py-4 px-2">
        
        {/* Left column: Badge Logo */}
        <div className="hidden lg:flex lg:col-span-7 flex-col items-center justify-center text-center">
          <CronosMascot variant="badge" size={340} className="transform hover:scale-[1.01] transition-transform duration-500" />
        </div>

        {/* Right column: Form */}
        <div className="lg:col-span-5 w-full bg-[#0a0d14]/90 backdrop-blur-xl border border-white/[0.08] rounded-3xl p-5 sm:p-8 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] relative overflow-hidden">
          
          {/* Mobile Mascot Logo (visible only on mobile/tablet) */}
          <div className="lg:hidden flex justify-center mb-6">
            <CronosMascot variant="badge" size={130} className="transform scale-95 hover:scale-100 transition-transform duration-300" />
          </div>

          {/* Tech layout bracket detail */}
          <div className="absolute top-0 right-0 p-5 opacity-10">
              <div className="w-16 h-16 border-t-2 border-r-2 border-blue-500" />
          </div>

          <div className="text-center mb-6">
            <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tighter uppercase italic bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
              {activeTab === 'login' ? 'ACESSO RESTRITO' : 'NOVO OPERADOR'}
            </h1>
            <div className="h-1 w-12 bg-gradient-to-r from-blue-500 to-indigo-500 mx-auto mt-2 rounded-full" />
            <p className="text-slate-400 text-[8px] font-mono uppercase tracking-[0.25em] mt-3">
              {activeTab === 'login' ? 'TMA STRATEGIC OPERATIONAL CORE' : 'CONFIGURAÇÃO DE ACESSO INDIVIDUAL'}
            </p>
          </div>

          {/* Nav Tabs for Login / Register */}
          <div className="grid grid-cols-2 bg-black/40 p-1 rounded-xl border border-white/[0.06] mb-5">
            <button
              type="button"
              onClick={() => { setActiveTab('login'); setError(''); setSuccess(''); }}
              className={`py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${activeTab === 'login' ? 'bg-blue-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
            >
              <LogIn className="w-3.5 h-3.5" />
              Entrar
            </button>
            <button
              type="button"
              onClick={() => { setActiveTab('register'); setError(''); setSuccess(''); }}
              className={`py-2 rounded-lg text-[10px] font-black uppercase tracking-widest transition-all duration-300 flex items-center justify-center gap-2 cursor-pointer ${activeTab === 'register' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'}`}
            >
              <UserPlus className="w-3.5 h-3.5" />
              Cadastrar
            </button>
          </div>

          {/* Dynamic Forms */}
          {activeTab === 'login' ? (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Usuário ou Email</label>
                <div className="relative">
                  <LucideUser className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input 
                    type="text"
                    value={login}
                    onChange={(e) => setLogin(e.target.value)}
                    className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl py-3 pl-12 pr-4 text-white outline-none focus:border-blue-500/50 focus:bg-white/[0.05] transition-all font-bold placeholder:text-slate-700 text-sm disabled:opacity-50"
                    placeholder="USUÁRIO OU EMAIL"
                    required
                    autoComplete="username"
                    disabled={isProcessing}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1.5 ml-1">
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest">Chave de Acesso</label>
                  <button 
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="text-[9px] font-bold text-blue-500 hover:text-blue-400 uppercase transition-all flex items-center gap-1 cursor-pointer"
                  >
                    {showPassword ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
                    {showPassword ? 'Ocultar' : 'Mostrar'}
                  </button>
                </div>
                <div className="relative">
                  <LucideLock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input 
                    type={showPassword ? 'text' : 'password'}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl py-3 pl-12 pr-4 text-white outline-none focus:border-blue-500/50 focus:bg-white/[0.05] transition-all font-bold placeholder:text-slate-700 text-sm disabled:opacity-50"
                    placeholder="••••••••"
                    required
                    autoComplete="current-password"
                    disabled={isProcessing}
                  />
                </div>
              </div>

              {error && (
                <div className="bg-red-500/10 border border-red-500/25 p-3 rounded-xl text-red-400 text-[9px] font-mono uppercase tracking-wider text-center animate-shake">
                  {error}
                </div>
              )}

              {success && (
                <div className="bg-emerald-500/10 border border-emerald-500/25 p-3 rounded-xl text-emerald-400 text-[9px] font-mono uppercase tracking-wider text-center">
                  {success}
                </div>
              )}

              <button 
                type="submit"
                disabled={isProcessing}
                className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white font-black py-3.5 rounded-xl shadow-lg shadow-blue-500/10 transition-all active:scale-[0.98] uppercase tracking-[0.15em] text-[11px] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/25 border-t-white rounded-full animate-spin"></span>
                    <span>Autenticando...</span>
                  </>
                ) : (
                  <>
                    <span>Acessar Monitoramento</span>
                    <ChevronRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          ) : (
            /* REGISTRATION FORM */
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div>
                <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Nome Completo</label>
                <div className="relative">
                  <LucideUser className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input 
                    type="text"
                    value={regName}
                    onChange={(e) => setRegName(e.target.value)}
                    className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl py-2.5 pl-12 pr-4 text-white outline-none focus:border-indigo-500/50 focus:bg-white/[0.05] transition-all font-bold placeholder:text-slate-700 text-xs disabled:opacity-50"
                    placeholder="EX: DAVI SOBRINHO"
                    required
                    disabled={isProcessing}
                  />
                </div>
              </div>

              <div>
                <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Email (Login Principal)</label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                  <input 
                    type="email"
                    value={regEmail}
                    onChange={(e) => setRegEmail(e.target.value)}
                    className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl py-2.5 pl-12 pr-4 text-white outline-none focus:border-indigo-500/50 focus:bg-white/[0.05] transition-all font-bold placeholder:text-slate-700 text-xs disabled:opacity-50"
                    placeholder="EX: OPERADOR@EMPRESA.COM"
                    required
                    disabled={isProcessing}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Senha Própria</label>
                  <div className="relative">
                    <LucideLock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input 
                      type="password"
                      value={regPassword}
                      onChange={(e) => setRegPassword(e.target.value)}
                      className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl py-2.5 pl-12 pr-4 text-white outline-none focus:border-indigo-500/50 focus:bg-white/[0.05] transition-all font-bold placeholder:text-slate-700 text-xs disabled:opacity-50"
                      placeholder="MÍN. 6 DÍGITOS"
                      required
                      disabled={isProcessing}
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-[9px] font-black text-slate-400 uppercase tracking-widest mb-1.5 ml-1">Confirmar Senha</label>
                  <div className="relative">
                    <LucideLock className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input 
                      type="password"
                      value={regConfirmPassword}
                      onChange={(e) => setRegConfirmPassword(e.target.value)}
                      className="w-full bg-white/[0.03] border border-white/[0.08] rounded-xl py-2.5 pl-12 pr-4 text-white outline-none focus:border-indigo-500/50 focus:bg-white/[0.05] transition-all font-bold placeholder:text-slate-700 text-xs disabled:opacity-50"
                      placeholder="REPETIR SENHA"
                      required
                      disabled={isProcessing}
                    />
                  </div>
                </div>
              </div>



              {error && (
                <div className="bg-red-500/10 border border-red-500/25 p-3 rounded-xl text-red-400 text-[9px] font-mono uppercase tracking-wider text-center animate-shake">
                  {error}
                </div>
              )}

              {success && (
                <div className="bg-emerald-500/10 border border-emerald-500/25 p-3 rounded-xl text-emerald-400 text-[9px] font-mono uppercase tracking-wider text-center">
                  {success}
                </div>
              )}

              <button 
                type="submit"
                disabled={isProcessing}
                className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white font-black py-3 rounded-xl shadow-lg shadow-indigo-500/10 transition-all active:scale-[0.98] uppercase tracking-[0.15em] text-[10px] cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isProcessing ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white/25 border-t-white rounded-full animate-spin"></span>
                    <span>Criando sua credencial...</span>
                  </>
                ) : (
                  <>
                    <span>Efetuar Auto-Cadastro</span>
                    <ShieldCheck className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>
          )}

          {/* Social login divider */}
          <div className="relative my-4 flex py-1 items-center">
            <div className="flex-grow border-t border-white/[0.04]"></div>
            <span className="flex-shrink mx-4 text-[8px] font-mono text-slate-500 uppercase tracking-widest">OU</span>
            <div className="flex-grow border-t border-white/[0.04]"></div>
          </div>

          <button
            type="button"
            onClick={handleGoogleLogin}
            disabled={isProcessing}
            className="w-full bg-white/[0.03] hover:bg-white/[0.06] border border-white/[0.08] hover:border-slate-500/20 text-white font-black py-2.5 rounded-xl transition-all active:scale-[0.98] uppercase tracking-[0.1em] text-[10px] cursor-pointer flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <span className="font-bold text-sm flex items-center tracking-normal">
              <span className="text-blue-500">G</span>
              <span className="text-red-500">o</span>
              <span className="text-yellow-500">o</span>
              <span className="text-blue-500">g</span>
              <span className="text-green-500">l</span>
              <span className="text-red-500">e</span>
            </span>
            <span className="text-[10px] text-slate-300">Entrar com Google</span>
          </button>



          <div className="mt-4 text-center">
            <p className="text-slate-600 text-[8px] font-mono uppercase tracking-[0.2em] leading-relaxed">
              Authorized Personnel Only<br/>
              Secure Encryption Active
            </p>
          </div>
        </div>

      </div>
    </div>
  );
};

export default LoginScreen;
