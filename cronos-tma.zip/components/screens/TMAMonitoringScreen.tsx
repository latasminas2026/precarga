import React, { useState, useMemo, useEffect } from 'react';
import ScreenWrapper from '../ScreenWrapper';
import { TMALogEntry, TMAConfig, BIEntry, User } from '../../types';
import { 
    validateDuration, 
    calculateAverage, 
    calculateMetricQualityStats, 
    formatDurationHuman, 
    secondsToTimeStr, 
    secondsToTimeStrShort, 
    calculateTimestampDiffInSeconds,
    OUTLIER_THRESHOLD_SECONDS 
} from '../../tmaEngine';
import { ResumoOperacionalTab } from './ResumoOperacionalTab';
import { AuditoriaQualidadeTab } from './AuditoriaQualidadeTab';
import StratificationModal from '../modals/StratificationModal';
import ActivityIcon from '../icons/ActivityIcon';
import ClockIcon from '../icons/ClockIcon';
import AlertTriangleIcon from '../icons/AlertTriangleIcon';
import ChevronLeftIcon from '../icons/ChevronLeftIcon';
import SearchIcon from '../icons/SearchIcon';
import ExternalLinkIcon from '../icons/ExternalLinkIcon';
import FilterIcon from '../icons/FilterIcon';
import DownloadIcon from '../icons/DownloadIcon';
import BoxesIcon from '../icons/BoxesIcon';
import TruckIcon from '../icons/TruckIcon';
import UserIcon from '../icons/UserIcon';
import TrendingUpIcon from '../icons/TrendingUpIcon';
import TrendingDownIcon from '../icons/TrendingDownIcon';
import MapPinIcon from '../icons/MapPinIcon';
import ShieldCheckIcon from '../icons/ShieldCheckIcon';
import LayoutGridIcon from '../icons/LayoutGridIcon';
import ListIcon from '../icons/ListIcon';
import FileClockIcon from '../icons/FileClockIcon';
import ClipboardPasteIcon from '../icons/ClipboardPasteIcon';
import TrashIcon from '../icons/TrashIcon';
import HistoryIcon from '../icons/HistoryIcon';
import { db, auth, isFirebaseConfigured } from '../../firebase';
import { collection, addDoc, getDocs, query, where, orderBy, deleteDoc, doc } from 'firebase/firestore';
import { supabase, isSupabaseConfigured } from '../../supabase';
import { 
    ComposedChart,
    Bar, 
    Line,
    XAxis, 
    YAxis, 
    CartesianGrid, 
    Tooltip, 
    ResponsiveContainer, 
    Cell,
    ReferenceLine
} from 'recharts';
import { Settings as SettingsIcon, LogOut as LogOutIcon, Database, AlertTriangle, Loader2, CheckCircle2, XCircle, BarChart3, ExternalLink, Lock, Shield, Check, RefreshCw, Camera, User as LucideUser, Upload, Sun, Moon } from 'lucide-react';

interface TMAMonitoringScreenProps {
    onBack: () => void;
    tmaConfig: TMAConfig;
    onSaveTmaConfig?: (newConfig: TMAConfig) => void;
    user?: User;
}

// Coordenadas da Fábrica (Exemplo - Polígono simplificado por raio)
const FACTORY_COORDS = { lat: -23.5505, lng: -46.6333 }; 
const FACTORY_RADIUS_KM = 2.0;

const TruckWatermark = () => (
    <div className="absolute right-4 bottom-8 w-80 h-auto opacity-[0.035] pointer-events-none select-none text-emerald-500 fill-current">
        <svg viewBox="0 0 300 100" className="w-full h-full">
            {/* Ground line */}
            <rect x="10" y="82" width="280" height="2" rx="1" />
            {/* Trailer */}
            <rect x="20" y="25" width="170" height="48" rx="3" />
            {/* Trailer decorative stripes */}
            <path d="M 30,35 L 180,35 L 170,45 L 20,45 Z" opacity="0.3" />
            <path d="M 40,53 L 160,53 L 150,61 L 30,61 Z" opacity="0.15" />
            {/* Cabin */}
            <path d="M 195,42 L 225,42 L 235,55 L 255,55 L 262,70 L 262,73 L 195,73 Z" />
            {/* Cabin window */}
            <path d="M 228,45 L 245,45 L 252,56 L 228,56 Z" opacity="0.4" />
            {/* Wheels */}
            <circle cx="50" cy="76" r="10" />
            <circle cx="50" cy="76" r="4" fill="#000" opacity="0.5" />
            <circle cx="72" cy="76" r="10" />
            <circle cx="72" cy="76" r="4" fill="#000" opacity="0.5" />
            
            <circle cx="140" cy="76" r="10" />
            <circle cx="140" cy="76" r="4" fill="#000" opacity="0.5" />
            <circle cx="162" cy="76" r="10" />
            <circle cx="162" cy="76" r="4" fill="#000" opacity="0.5" />
            
            <circle cx="208" cy="76" r="10" />
            <circle cx="208" cy="76" r="4" fill="#000" opacity="0.5" />
            <circle cx="248" cy="76" r="10" />
            <circle cx="248" cy="76" r="4" fill="#000" opacity="0.5" />
        </svg>
    </div>
);

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Raio da Terra em km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = 
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * 
        Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
};

const parseDateTime = (str: string, baseDateStr?: string): Date | null => {
    if (!str || str === '-' || str.trim() === '') return null;
    
    let fullStr = str.trim();
    // Normaliza separadores para '/'
    fullStr = fullStr.replace(/[-.]/g, '/');
    
    // Se não tem barra, assume que é apenas hora e tenta prefixar com a data base
    if (!fullStr.includes('/') && baseDateStr) {
        const normalizedBaseDate = baseDateStr.replace(/[-.]/g, '/');
        fullStr = `${normalizedBaseDate} ${fullStr}`;
    }
    
    // Split por qualquer espaço em branco (espaço, tab, etc)
    const parts = fullStr.split(/\s+/);
    if (parts.length < 2) {
        // Tenta tratar se for apenas data sem hora ou hora sem data
        if (fullStr.includes('/') && fullStr.split('/').length === 3) {
            const dp = fullStr.split('/');
            let d, m, y;
            if (dp[0].length === 4) {
                y = parseInt(dp[0]); m = parseInt(dp[1]) - 1; d = parseInt(dp[2]);
            } else {
                d = parseInt(dp[0]); m = parseInt(dp[1]) - 1; y = parseInt(dp[2]);
            }
            if (y < 100) y += 2000;
            return new Date(y, m, d);
        }
        return null;
    }
    
    const dateParts = parts[0].split('/');
    const timeParts = parts[1].split(':');
    
    // Suporte a formatos DD/MM/YYYY e YYYY/MM/DD
    let day, month, year;
    if (dateParts[0].length === 4) {
        year = parseInt(dateParts[0]);
        month = parseInt(dateParts[1]) - 1;
        day = parseInt(dateParts[2]);
    } else {
        day = parseInt(dateParts[0]);
        month = parseInt(dateParts[1]) - 1;
        year = parseInt(dateParts[2]);
    }

    if (year < 100) year += 2000;
    
    let hours = parseInt(timeParts[0]);
    const minutes = parseInt(timeParts[1]);
    const seconds = timeParts[2] ? parseInt(timeParts[2]) : 0;

    // Tratar AM/PM
    const ampm = parts[2] ? parts[2].toUpperCase() : null;
    if (ampm === 'PM' && hours < 12) hours += 12;
    if (ampm === 'AM' && hours === 12) hours = 0;
    
    const date = new Date(year, month, day, hours, minutes, seconds);
    if (isNaN(date.getTime())) {
        console.log('DEBUG: parseDateTime failed isNaN', str);
        return null;
    }
    return date;
};

const getTodayStr = () => {
    const now = new Date();
    const d = String(now.getDate()).padStart(2, '0');
    const m = String(now.getMonth() + 1).padStart(2, '0');
    const y = now.getFullYear();
    return `${d}/${m}/${y}`;
};

const timeToSeconds = (timeStr: string): number => {
    if (!timeStr || timeStr === '01/01/1970 00:00:00' || timeStr.trim() === '' || timeStr === '-') return 0;
    const timePart = timeStr.includes(' ') ? timeStr.split(' ')[1] : timeStr;
    const parts = timePart.split(':');
    
    if (parts.length === 3) {
        return parseInt(parts[0]) * 3600 + parseInt(parts[1]) * 60 + parseInt(parts[2]);
    } else if (parts.length === 2) {
        // Em contextos de logística e TMA, durações costumam vir em HH:MM
        // Se o formato for XX:YY, assumimos Minutos:Segundos
        return parseInt(parts[0]) * 60 + parseInt(parts[1]);
    }
    console.log('DEBUG: timeToSeconds failed', timeStr);
    return parseInt(timeStr) || 0;
};


const getShift = (timeStr: string): 'A' | 'B' | 'C' | 'N/A' => {
    if (!timeStr) return 'N/A';
    const match = timeStr.match(/(\d{2}):(\d{2})/);
    if (!match) return 'N/A';
    const h = parseInt(match[1], 10);
    const totalMinutes = h * 60 + parseInt(match[2], 10);
    if (totalMinutes >= 7 * 60 && totalMinutes <= (15 * 60 + 20)) return 'B';
    if (totalMinutes >= (15 * 60 + 21) && totalMinutes <= (23 * 60 + 20)) return 'C';
    return 'A';
};

const parseToISODate = (dateStr: string): string => {
    if (!dateStr || dateStr === '--/--/----') return new Date().toISOString().split('T')[0];
    const parts = dateStr.split('/');
    if (parts.length === 3) {
        return `${parts[2]}-${parts[1]}-${parts[0]}`;
    }
    return dateStr;
};

const parseToISOTimestamp = (dateTimeStr: string | null | undefined): string | null => {
    if (!dateTimeStr || dateTimeStr === '-') return null;
    try {
        const parts = dateTimeStr.split(' ');
        if (parts.length >= 2) {
            const dateParts = parts[0].split('/');
            const timeParts = parts[1].split(':');
            if (dateParts.length === 3 && timeParts.length >= 2) {
                const year = parseInt(dateParts[2], 10);
                const month = parseInt(dateParts[1], 10) - 1;
                const day = parseInt(dateParts[0], 10);
                const hour = parseInt(timeParts[0], 10);
                const minute = parseInt(timeParts[1], 10);
                const second = timeParts[2] ? parseInt(timeParts[2], 10) : 0;
                
                const d = new Date(year, month, day, hour, minute, second);
                if (!isNaN(d.getTime())) {
                    return d.toISOString();
                }
            }
        } else {
            const dateParts = dateTimeStr.split('/');
            if (dateParts.length === 3) {
                const year = parseInt(dateParts[2], 10);
                const month = parseInt(dateParts[1], 10) - 1;
                const day = parseInt(dateParts[0], 10);
                const d = new Date(year, month, day);
                if (!isNaN(d.getTime())) {
                    return d.toISOString();
                }
            }
        }
    } catch (e) {
        console.warn('Erro ao converter data para ISO:', dateTimeStr, e);
    }
    return null;
};

const DEFAULT_ENTRIES: TMALogEntry[] = [
    {
        id: 'mock-1',
        placa: 'KAX-4012',
        placa2: 'CAR-1290',
        transportadora: 'LOT LOGISTICA',
        checkin: '06:12:00',
        entrada: '06:34:00',
        saida: '07:45:00',
        tempoFilaExterna: 1320,
        tempoInterno: 4260,
        tmaTotal: 5580,
        source: 'LOGAN',
        turno: 'A',
        status: 'Concluído',
        tmfi: 1320,
        tmc: 3300,
        tms: 960,
        status_raio: 'DENTRO',
        status_sla_drop: 'NORMAL',
        processo: 'Carga Latas',
        isOutlier: false,
        dt: '1092837',
        tp: '2837492',
        horaEntrada: '02/07/2026 06:34:00',
        horaDoca: '02/07/2026 06:45:00',
        horaSaidaDoca: '02/07/2026 07:30:00',
        horaSaidaFabrica: '02/07/2026 07:45:00'
    },
    {
        id: 'mock-2',
        placa: 'MVX-8930',
        placa2: 'CAR-4820',
        transportadora: 'JSL LOGISTICA',
        checkin: '07:15:00',
        entrada: '07:22:00',
        saida: '08:50:00',
        tempoFilaExterna: 420,
        tempoInterno: 5280,
        tmaTotal: 5700,
        source: 'LOGAN',
        turno: 'A',
        status: 'Concluído',
        tmfi: 420,
        tmc: 4100,
        tms: 1180,
        status_raio: 'DENTRO',
        status_sla_drop: 'NORMAL',
        processo: 'Carga Latas',
        isOutlier: false,
        dt: '1092838',
        tp: '2837493',
        horaEntrada: '02/07/2026 07:22:00',
        horaDoca: '02/07/2026 07:35:00',
        horaSaidaDoca: '02/07/2026 08:30:00',
        horaSaidaFabrica: '02/07/2026 08:50:00'
    },
    {
        id: 'mock-3',
        placa: 'EWY-4512',
        placa2: 'CAR-0931',
        transportadora: 'TEGMA',
        checkin: '08:40:00',
        entrada: '09:15:00',
        saida: '10:55:00',
        tempoFilaExterna: 2100,
        tempoInterno: 6000,
        tmaTotal: 8100,
        source: 'LOGAN',
        turno: 'B',
        status: 'Alerta SLA',
        tmfi: 2100,
        tmc: 4800,
        tms: 1200,
        status_raio: 'DENTRO',
        status_sla_drop: 'ALERTA',
        processo: 'Carga Latas',
        isOutlier: true,
        dt: '1092839',
        tp: '2837494',
        horaEntrada: '02/07/2026 09:15:00',
        horaDoca: '02/07/2026 09:30:00',
        horaSaidaDoca: '02/07/2026 10:35:00',
        horaSaidaFabrica: '02/07/2026 10:55:00'
    },
    {
        id: 'mock-4',
        placa: 'PQA-3819',
        placa2: 'CAR-8822',
        transportadora: 'LOT LOGISTICA',
        checkin: '10:10:00',
        entrada: '10:25:00',
        saida: '11:40:00',
        tempoFilaExterna: 900,
        tempoInterno: 4500,
        tmaTotal: 5400,
        source: 'LOGAN',
        turno: 'B',
        status: 'Concluído',
        tmfi: 900,
        tmc: 3200,
        tms: 1300,
        status_raio: 'DENTRO',
        status_sla_drop: 'NORMAL',
        processo: 'Carga Latas',
        isOutlier: false,
        dt: '1092840',
        tp: '2837495',
        horaEntrada: '02/07/2026 10:25:00',
        horaDoca: '02/07/2026 10:40:00',
        horaSaidaDoca: '02/07/2026 11:20:00',
        horaSaidaFabrica: '02/07/2026 11:40:00'
    },
    {
        id: 'mock-5',
        placa: 'OUI-7712',
        placa2: 'CAR-9031',
        transportadora: 'PATRUS',
        checkin: '11:35:00',
        entrada: '11:55:00',
        saida: '13:10:00',
        tempoFilaExterna: 1200,
        tempoInterno: 4500,
        tmaTotal: 5700,
        source: 'LOGAN',
        turno: 'B',
        status: 'Concluído',
        tmfi: 1200,
        tmc: 3400,
        tms: 1100,
        status_raio: 'DENTRO',
        status_sla_drop: 'NORMAL',
        processo: 'Carga Latas',
        isOutlier: false,
        dt: '1092841',
        tp: '2837496',
        horaEntrada: '02/07/2026 11:55:00',
        horaDoca: '02/07/2026 12:10:00',
        horaSaidaDoca: '02/07/2026 12:55:00',
        horaSaidaFabrica: '02/07/2026 13:10:00'
    },
    {
        id: 'mock-6',
        placa: 'GHS-4560',
        placa2: 'CAR-5512',
        transportadora: 'LOT LOGISTICA',
        checkin: '13:20:00',
        entrada: '13:45:00',
        saida: '14:55:00',
        tempoFilaExterna: 1500,
        tempoInterno: 4200,
        tmaTotal: 5700,
        source: 'LOGAN',
        turno: 'C',
        status: 'Concluído',
        tmfi: 1500,
        tmc: 3000,
        tms: 1200,
        status_raio: 'DENTRO',
        status_sla_drop: 'NORMAL',
        processo: 'Carga Latas',
        isOutlier: false,
        dt: '1092842',
        tp: '2837497',
        horaEntrada: '02/07/2026 13:45:00',
        horaDoca: '02/07/2026 14:00:00',
        horaSaidaDoca: '02/07/2026 14:40:00',
        horaSaidaFabrica: '02/07/2026 14:55:00'
    },
    {
        id: 'mock-7',
        placa: 'JOP-9011',
        placa2: 'CAR-2299',
        transportadora: 'JSL LOGISTICA',
        checkin: '14:50:00',
        entrada: '15:10:00',
        saida: '16:40:00',
        tempoFilaExterna: 1200,
        tempoInterno: 5400,
        tmaTotal: 6600,
        source: 'LOGAN',
        turno: 'C',
        status: 'Alerta SLA',
        tmfi: 1200,
        tmc: 4400,
        tms: 1000,
        status_raio: 'DENTRO',
        status_sla_drop: 'NORMAL',
        processo: 'Carga Latas',
        isOutlier: false,
        dt: '1092843',
        tp: '2837498',
        horaEntrada: '02/07/2026 15:10:00',
        horaDoca: '02/07/2026 15:30:00',
        horaSaidaDoca: '02/07/2026 16:20:00',
        horaSaidaFabrica: '02/07/2026 16:40:00'
    }
];

const RealTimeClock: React.FC = () => {
    const [time, setTime] = useState(new Date());
    useEffect(() => {
        const timer = setInterval(() => setTime(new Date()), 1000);
        return () => clearInterval(timer);
    }, []);
    return (
        <div className="flex flex-col items-end">
            <div className="text-3xl font-black text-white font-mono tracking-tighter tabular-nums leading-none">
                {time.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </div>
            <p className="text-[10px] font-black text-blue-400 uppercase tracking-[0.2em] mt-1.5">
                {time.toLocaleDateString('pt-BR', { weekday: 'long', day: '2-digit', month: 'long' })}
            </p>
        </div>
    );
};

const TMAMonitoringScreen: React.FC<TMAMonitoringScreenProps> = ({ onBack, tmaConfig, onSaveTmaConfig, user }) => {
    // States for custom profile
    const [profileName, setProfileName] = useState<string>(() => {
        const saved = localStorage.getItem(`tma_profile_name_${user?.login || 'guest'}`);
        return saved || user?.name || 'Operador';
    });
    
    const [profilePhoto, setProfilePhoto] = useState<string>(() => {
        const saved = localStorage.getItem(`tma_profile_photo_${user?.login || 'guest'}`);
        return saved || '';
    });

    const [showProfileModal, setShowProfileModal] = useState<boolean>(false);
    const [showWelcomeToast, setShowWelcomeToast] = useState<boolean>(true);
    const [theme, setTheme] = useState<'dark' | 'light'>(() => {
        const saved = localStorage.getItem('tma_theme');
        return (saved as 'dark' | 'light') || 'dark';
    });
    const [editName, setEditName] = useState<string>(() => {
        const saved = localStorage.getItem(`tma_profile_name_${user?.login || 'guest'}`);
        return saved || user?.name || 'Operador';
    });
    const [editPhoto, setEditPhoto] = useState<string>(() => {
        const saved = localStorage.getItem(`tma_profile_photo_${user?.login || 'guest'}`);
        return saved || '';
    });

    // Auto-dismiss welcome toast after 5 seconds
    useEffect(() => {
        const timer = setTimeout(() => {
            setShowWelcomeToast(false);
        }, 5000);
        return () => clearTimeout(timer);
    }, []);

    const [rawText, setRawText] = useState(() => localStorage.getItem('tma_current_rawText') || '');
    const [biRawText, setBiRawText] = useState(() => localStorage.getItem('tma_current_biRawText') || '');
    const [perfilRawText, setPerfilRawText] = useState(() => localStorage.getItem('tma_current_perfilRawText') || '');
    const [reportDate, setReportDate] = useState(() => localStorage.getItem('tma_current_reportDate') || getTodayStr());
    const [entries, setEntries] = useState<TMALogEntry[]>(() => {
        const saved = localStorage.getItem('tma_current_entries');
        if (saved) {
            try {
                const parsed = JSON.parse(saved);
                if (parsed && parsed.length > 0) {
                    return parsed;
                }
            } catch (e) {
                // fall through to mock data
            }
        }
        return DEFAULT_ENTRIES;
    });
    const [view, setView] = useState<'input' | 'dashboard' | 'analysis' | 'settings' | 'power_bi'>(() => {
        const saved = localStorage.getItem('tma_current_view');
        if (saved && ['input', 'dashboard', 'analysis', 'settings', 'power_bi'].includes(saved)) {
            return saved as any;
        }
        return 'dashboard';
    });
    const [isSidebarHovered, setIsSidebarHovered] = useState<boolean>(false);
    const [hasAutoLoaded, setHasAutoLoaded] = useState(false);

    // Power BI integration states
    const [pbiAuthenticated, setPbiAuthenticated] = useState<boolean>(() => {
        return localStorage.getItem('pbi_authenticated') === 'true';
    });
    const [authInProgress, setAuthInProgress] = useState<boolean>(false);

    // States for target settings
    const [targetsInMinutes, setTargetsInMinutes] = useState({
        tmfeTarget: Math.round((tmaConfig.tmfeTarget || 0) / 60),
        tmfiTarget: Math.round((tmaConfig.tmfiTarget || 0) / 60),
        tmcTarget: Math.round((tmaConfig.tmcTarget || 0) / 60),
        tmsTarget: Math.round((tmaConfig.tmsTarget || 0) / 60),
        tmpcTarget: Math.round((tmaConfig.tmpcTarget || 0) / 60),
        totalTarget: Math.round((tmaConfig.totalTarget || 0) / 60),
    });

    useEffect(() => {
        setTargetsInMinutes({
            tmfeTarget: Math.round((tmaConfig.tmfeTarget || 0) / 60),
            tmfiTarget: Math.round((tmaConfig.tmfiTarget || 0) / 60),
            tmcTarget: Math.round((tmaConfig.tmcTarget || 0) / 60),
            tmsTarget: Math.round((tmaConfig.tmsTarget || 0) / 60),
            tmpcTarget: Math.round((tmaConfig.tmpcTarget || 0) / 60),
            totalTarget: Math.round((tmaConfig.totalTarget || 0) / 60),
        });
    }, [tmaConfig]);

    useEffect(() => {
        try {
            // Se o texto bruto for muito grande, evitamos salvar para não estourar a cota de 5MB
            if (rawText && rawText.length < 50000) {
                localStorage.setItem('tma_current_rawText', rawText);
            } else if (rawText) {
                localStorage.setItem('tma_current_rawText', '(dados omitidos devido ao tamanho para preservar espaço)');
            } else {
                localStorage.setItem('tma_current_rawText', '');
            }
        } catch (e) {
            console.warn('Erro ao salvar tma_current_rawText no LocalStorage:', e);
        }
    }, [rawText]);

    useEffect(() => {
        try {
            if (biRawText && biRawText.length < 50000) {
                localStorage.setItem('tma_current_biRawText', biRawText);
            } else if (biRawText) {
                localStorage.setItem('tma_current_biRawText', '(dados omitidos devido ao tamanho para preservar espaço)');
            } else {
                localStorage.setItem('tma_current_biRawText', '');
            }
        } catch (e) {
            console.warn('Erro ao salvar tma_current_biRawText no LocalStorage:', e);
        }
    }, [biRawText]);

    useEffect(() => {
        try {
            if (perfilRawText && perfilRawText.length < 50000) {
                localStorage.setItem('tma_current_perfilRawText', perfilRawText);
            } else if (perfilRawText) {
                localStorage.setItem('tma_current_perfilRawText', '(dados omitidos devido ao tamanho para preservar espaço)');
            } else {
                localStorage.setItem('tma_current_perfilRawText', '');
            }
        } catch (e) {
            console.warn('Erro ao salvar tma_current_perfilRawText no LocalStorage:', e);
        }
    }, [perfilRawText]);

    useEffect(() => {
        try {
            localStorage.setItem('tma_current_reportDate', reportDate);
        } catch (e) {
            console.warn('Erro ao salvar tma_current_reportDate no LocalStorage:', e);
        }
    }, [reportDate]);

    useEffect(() => {
        try {
            localStorage.setItem('tma_current_entries', JSON.stringify(entries));
        } catch (e) {
            console.error('Erro de limite de cota de LocalStorage ao salvar tma_current_entries:', e);
            try {
                // Simplificação extrema como último recurso para caber no LocalStorage
                const lightweight = entries.map(item => ({
                    id: item.id,
                    placa: item.placa,
                    placa2: item.placa2,
                    transportadora: item.transportadora,
                    turno: item.turno,
                    horaEntrada: item.horaEntrada,
                    horaDoca: item.horaDoca,
                    horaSaidaDoca: item.horaSaidaDoca,
                    horaSaidaFabrica: item.horaSaidaFabrica,
                    tmfe_calculado: item.tmfe_calculado,
                    tmpc_calculado: item.tmpc_calculado,
                    tmfi: item.tmfi,
                    tmc: item.tmc,
                    tms: item.tms,
                    total: item.total,
                    status_raio: item.status_raio,
                    status_sla_drop: item.status_sla_drop,
                    isOutlier: item.isOutlier,
                    isInRadius: item.isInRadius,
                    flag_manobra: item.flag_manobra
                }));
                localStorage.setItem('tma_current_entries', JSON.stringify(lightweight));
            } catch (err) {
                console.error('Não foi possível salvar nem as entradas simplificadas no LocalStorage:', err);
            }
        }
    }, [entries]);

    useEffect(() => {
        try {
            localStorage.setItem('tma_current_view', view);
        } catch (e) {
            console.warn('Erro ao salvar tma_current_view no LocalStorage:', e);
        }
    }, [view]);

    const [supabaseStatus, setSupabaseStatus] = useState<'idle' | 'checking' | 'success' | 'error'>('idle');
    const [supabaseMessage, setSupabaseMessage] = useState('');
    const [activeTab, setActiveTab] = useState<'analytics' | 'tmfe_tmpc' | 'operacional' | 'auditoria'>('analytics');
    const [selectedPlate, setSelectedPlate] = useState<string | null>(null);
    const [inputMode, setInputMode] = useState<'full' | 'bi_only'>('full');
    const [error, setError] = useState('');
    const [currentTime, setCurrentTime] = useState(new Date());

    // Firebase Saved Imports States
    const [savedImports, setSavedImports] = useState<any[]>([]);
    const [isLoadingImports, setIsLoadingImports] = useState(false);
    const [showSaveModal, setShowSaveModal] = useState(false);
    const [newImportTitle, setNewImportTitle] = useState('');
    const [isSavingImport, setIsSavingImport] = useState(false);
    const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'success' | 'error'>('idle');

    // Stratification Modal States
    const [isStratModalOpen, setIsStratModalOpen] = useState(false);
    const [stratPlaca, setStratPlaca] = useState('');
    const [stratTransportadora, setStratTransportadora] = useState('');
    const [stratGuia, setStratGuia] = useState('');

    const handleSaveStratification = async (data: any) => {
        let fbSuccess = false;
        let sbSuccess = false;
        let errorDetails = '';
        
        // 1. Firebase Save
        if (isFirebaseConfigured && auth.currentUser) {
            try {
                await addDoc(collection(db, 'analise_pi_registros'), {
                    indicador: 'TMA',
                    data_ocorrencia: data.data,
                    turno: data.turno,
                    area: 'Logística / Transportes',
                    tipo_ocorrencia: data.motivo,
                    tempo: 0,
                    responsavel: data.responsavel,
                    observacao: `[PLACA: ${data.placa}] [GUIA: ${data.guia}] ${data.descricao}`,
                    data_registro: new Date().toISOString(),
                    uid: auth.currentUser.uid
                });
                fbSuccess = true;
            } catch (err: any) {
                console.error('Erro ao salvar estratificação no Firebase:', err);
                errorDetails += `Firebase: ${err.message || err}\n`;
            }
        }

        // 2. Supabase Save
        if (isSupabaseConfigured) {
            try {
                const { error } = await supabase
                    .from('tma_offender_stratifications')
                    .insert({
                        data: data.data,
                        turno: data.turno,
                        placa: data.placa,
                        transportadora: data.transportadora,
                        motivo: data.motivo,
                        descricao: data.descricao,
                        responsavel: data.responsavel,
                        guia: data.guia,
                        unidade: data.unidade || 'Ambev'
                    });
                
                if (error) {
                    throw error;
                }
                sbSuccess = true;
            } catch (err: any) {
                console.warn('Erro ao salvar em tma_offender_stratifications, tentando fallback para analise_pi_registros:', err);
                try {
                    const { error: fallbackError } = await supabase
                        .from('analise_pi_registros')
                        .insert({
                            indicador: 'TMA',
                            data_ocorrencia: data.data,
                            turno: data.turno,
                            area: 'Logística / Transportes',
                            tipo_ocorrencia: data.motivo,
                            tempo: 0,
                            responsavel: data.responsavel,
                            observacao: `[PLACA: ${data.placa}] [GUIA: ${data.guia}] ${data.descricao}`,
                            uid: auth.currentUser?.uid || null
                        });
                    if (fallbackError) {
                        throw fallbackError;
                    }
                    sbSuccess = true;
                } catch (fallbackErr: any) {
                    console.error('Erro geral ao salvar no Supabase (incluindo fallback):', fallbackErr);
                    errorDetails += `Supabase: ${fallbackErr.message || fallbackErr}\n`;
                }
            }
        }

        if (fbSuccess || sbSuccess || (!isFirebaseConfigured && !isSupabaseConfigured)) {
            let msg = 'Estratificação de ofensor salva com sucesso ';
            if (fbSuccess && sbSuccess) msg += 'no Firebase e Supabase!';
            else if (fbSuccess) msg += 'no Firebase!';
            else if (sbSuccess) msg += 'no Supabase!';
            else msg += 'localmente (Aguardando configuração de banco de dados)!';

            alert(msg);
            setIsStratModalOpen(false);
        } else {
            alert(`Falha ao salvar estratificação:\n${errorDetails}`);
        }
    };

    // Fetch Saved Imports from Firebase, Supabase, and LocalStorage
    const fetchSavedImports = async () => {
        setIsLoadingImports(true);
        const docsList: any[] = [];
        
        // 1. Buscar do Firebase se configurado e autenticado
        if (isFirebaseConfigured && auth.currentUser) {
            try {
                const q = query(
                    collection(db, 'tma_imports'),
                    where('uid', '==', auth.currentUser.uid),
                    orderBy('timestamp', 'desc')
                );
                const querySnapshot = await getDocs(q);
                querySnapshot.forEach((docSnap) => {
                    docsList.push({ id: docSnap.id, ...docSnap.data(), source: 'firebase' });
                });
            } catch (err) {
                console.error('Erro ao buscar importações do Firebase:', err);
            }
        }

        // 2. Buscar do Supabase se configurado
        if (isSupabaseConfigured) {
            try {
                const { data, error } = await supabase
                    .from('tma_imports')
                    .select('*')
                    .order('timestamp', { ascending: false });
                
                if (error) {
                    console.warn('Erro ao buscar importações do Supabase:', error.message);
                } else if (data) {
                    // Contar quantidade de registros vinculados de cada importação
                    const { data: countData, error: countError } = await supabase
                        .from('tma_entries')
                        .select('import_id');
                    
                    const countsMap: Record<string, number> = {};
                    if (!countError && countData) {
                        countData.forEach((row: any) => {
                            countsMap[row.import_id] = (countsMap[row.import_id] || 0) + 1;
                        });
                    }
                    
                    data.forEach((row: any) => {
                        docsList.push({
                            id: row.id,
                            titulo: row.titulo,
                            data_ocorrencia: row.data_ocorrencia,
                            tipo_entrada: row.tipo_entrada,
                            timestamp: row.timestamp,
                            raw_text: row.raw_text,
                            bi_raw_text: row.bi_raw_text,
                            source: 'supabase',
                            entriesCount: countsMap[row.id] || 0
                        });
                    });
                }
            } catch (err) {
                console.warn('Erro geral ao buscar importações do Supabase:', err);
            }
        }

        // 3. Buscar do LocalStorage (Sempre disponível)
        try {
            const localSaved = localStorage.getItem('tma_local_imports');
            if (localSaved) {
                const parsedLocal = JSON.parse(localSaved);
                parsedLocal.forEach((item: any) => {
                    if (!docsList.some(d => d.id === item.id)) {
                        docsList.push({
                            ...item,
                            source: 'local',
                            entriesCount: item.entries ? item.entries.length : 0
                        });
                    }
                });
            }
        } catch (err) {
            console.error('Erro ao carregar do LocalStorage:', err);
        }
        
        // Ordenar os dados mesclados por data de criação decrescente
        docsList.sort((a, b) => {
            const timeA = a.timestamp ? new Date(a.timestamp).getTime() : 0;
            const timeB = b.timestamp ? new Date(b.timestamp).getTime() : 0;
            return timeB - timeA;
        });

        setSavedImports(docsList);
        setIsLoadingImports(false);
    };

    // Database, LocalStorage and Auth init fetch
    useEffect(() => {
        fetchSavedImports();
        
        if (isFirebaseConfigured) {
            const unsubscribe = auth.onAuthStateChanged((user) => {
                if (user) {
                    fetchSavedImports();
                }
            });
            return () => unsubscribe();
        }
    }, []);

    // Auto-load most recent import on startup
    useEffect(() => {
        if (!hasAutoLoaded && savedImports.length > 0 && entries.length === 0) {
            setHasAutoLoaded(true);
            const latestImport = savedImports[0];
            handleLoadImport(latestImport, false); // load silently
        }
    }, [savedImports, entries, hasAutoLoaded]);

    // Ensure a default company and unit exist (no longer needed for flat schema, kept for compatibility)
    const ensureDefaultCompanyAndUnit = async () => {
        return { empresaId: '', unidadeId: '' };
    };

    // Shared function to save TMA Import and Entries to databases
    const saveImportToDatabases = async (
        title: string,
        dateStr: string,
        mode: 'full' | 'bi_only',
        rawTxt: string,
        biRawTxt: string,
        entriesData: any[]
    ): Promise<{ fbSuccess: boolean; sbSuccess: boolean; localSuccess: boolean; errorDetails: string }> => {
        let fbSuccess = false;
        let sbSuccess = false;
        let localSuccess = false;
        let errorDetails = '';

        // 1. Salvar no Firebase se configurado
        if (isFirebaseConfigured) {
            try {
                // Mesmo que o usuário não esteja logado, permitimos salvar usando um ID padrão/anônimo
                const uid = auth.currentUser?.uid || 'anonymous';
                await addDoc(collection(db, 'tma_imports'), {
                    titulo: title,
                    data_ocorrencia: dateStr,
                    tipo_entrada: mode === 'full' ? 'Totem + BI' : 'Apenas BI',
                    timestamp: new Date().toISOString(),
                    uid: uid,
                    raw_text: rawTxt,
                    bi_raw_text: biRawTxt,
                    entries: entriesData
                });
                fbSuccess = true;
            } catch (err: any) {
                console.warn('Aviso: Não foi possível sincronizar com o Firebase:', err);
                errorDetails += `Firebase: ${err.message || err}\n`;
            }
        }

        // 2. Salvar no Supabase se configurado (Flat schema - no companies/units tables required)
        if (isSupabaseConfigured) {
            try {
                const insertPayload: any = {
                    titulo: title,
                    data_ocorrencia: parseToISODate(dateStr),
                    tipo_entrada: mode === 'full' ? 'Totem + BI' : 'Apenas BI',
                    raw_text: rawTxt,
                    bi_raw_text: biRawTxt,
                    uid: auth.currentUser?.uid || null
                };

                const { data: importData, error: importError } = await supabase
                    .from('tma_imports')
                    .insert(insertPayload)
                    .select()
                    .single();

                if (importError) {
                    throw new Error(`Import header error: ${importError.message}`);
                }

                if (importData) {
                    const entriesToInsert = entriesData.map(e => {
                        return {
                            import_id: importData.id,
                            placa: e.placa,
                            placa_carreta: e.placa2 || null,
                            transportadora: e.transportadora || null,
                            motorista: null,
                            lacre: e.lacre || null,
                            nota_fiscal: e.notaFiscal || null,
                            pedido: e.pedido || null,
                            origem: e.origem || null,
                            local_doca: e.local || null,
                            processo: e.processo || null,
                            operacao: e.operacao || null,
                            turno: (e.turno === 'N/A' || e.turno === 'N') ? 'N' : e.turno,
                            hora_checkin: parseToISOTimestamp(e.checkin),
                            hora_entrada: parseToISOTimestamp(e.horaEntrada || e.entrada),
                            hora_doca: parseToISOTimestamp(e.horaDoca),
                            hora_saida_doca: parseToISOTimestamp(e.horaSaidaDoca),
                            hora_saida_fabrica: parseToISOTimestamp(e.horaSaidaFabrica || e.saida),
                            tmfe: e.tmfe_calculado || 0,
                            tmfi: e.tmfi || 0,
                            tmc: e.tmc || 0,
                            tms: e.tms || 0,
                            tma: e.total || 0,
                            tma_real: e.tmaReal || null,
                            bi_status: e.bi_status || null,
                            bi_duracao: e.bi_duracao || null,
                            bi_gps_last: parseToISOTimestamp(e.bi_gps_last),
                            bi_lat: e.bi_lat || null,
                            bi_lng: e.bi_lng || null,
                            bi_status_veiculo: e.bi_status_veiculo || null,
                            bi_ultimo_local_parada: e.bi_ultimo_local_parada || null,
                            bi_canal: e.bi_canal || null,
                            bi_inicio_parada: parseToISOTimestamp(e.bi_inicio_parada),
                            bi_fim_parada: parseToISOTimestamp(e.bi_fim_parada),
                            bi_unidade_dimensionada: e.bi_unidade_dimensionada || null,
                            dt_codigo: e.dt || null,
                            tp_codigo: e.tp || null,
                            is_outlier: e.isOutlier || false,
                            is_manobra: e.isManobra || false,
                            is_backup: e.isBackup || false,
                            is_in_radius: e.isInRadius || false,
                            status_raio: e.status_raio || 'FORA',
                            status_sla_drop: e.status_sla_drop || 'NORMAL',
                            alerta_3h: e.alerta_3h || false,
                            unidade_divergente: e.unidade_divergente || false,
                            flag_manobra: e.flag_manobra || false,
                            status: (e.status && ['OK', 'NOK', 'ATRAZADO', 'DIVERGENTE'].includes(e.status.toUpperCase())) 
                                ? e.status.toUpperCase() 
                                : 'OK',
                            item_inspecionado: e.item_inspecionado || null,
                            description: e.description || null
                        };
                    });

                    const { error: entriesError } = await supabase
                        .from('tma_entries')
                        .insert(entriesToInsert);

                    if (entriesError) {
                        throw new Error(`Entries insert error: ${entriesError.message}`);
                    }
                    sbSuccess = true;
                }
            } catch (err: any) {
                console.warn('Aviso: Não foi possível sincronizar com o Supabase:', err);
                errorDetails += `Supabase: ${err.message || err}\n`;
            }
        }

        // 3. Sempre salvar localmente no LocalStorage (offline fallback garantido)
        try {
            // Para evitar estouro de limite da cota do LocalStorage (QuotaExceededError),
            // salvamos os dados brutos de planilhas apenas se forem pequenos (< 50KB).
            const localRawText = rawTxt && rawTxt.length < 50000 ? rawTxt : '';
            const localBiRawText = biRawTxt && biRawTxt.length < 50000 ? biRawTxt : '';

            const localImportObj = {
                id: 'local_' + Math.random().toString(36).substr(2, 9),
                titulo: title,
                data_ocorrencia: dateStr,
                tipo_entrada: mode === 'full' ? 'Totem + BI' : 'Apenas BI',
                timestamp: new Date().toISOString(),
                raw_text: localRawText,
                bi_raw_text: localBiRawText,
                entries: entriesData,
                source: 'local'
            };

            const localSaved = localStorage.getItem('tma_local_imports');
            const list = localSaved ? JSON.parse(localSaved) : [];
            list.unshift(localImportObj);
            
            // Mantém apenas os 8 mais recentes no LocalStorage para poupar armazenamento local
            if (list.length > 8) {
                list.pop();
            }
            
            try {
                localStorage.setItem('tma_local_imports', JSON.stringify(list));
                localSuccess = true;
            } catch (quotaError) {
                console.warn('LocalStorage cheio ao salvar histórico. Reduzindo quantidade de itens...');
                // Reduz e tenta salvar apenas os 3 mais recentes
                localStorage.setItem('tma_local_imports', JSON.stringify(list.slice(0, 3)));
                localSuccess = true;
            }
        } catch (err: any) {
            console.warn('Erro ao salvar no LocalStorage:', err);
            errorDetails += `LocalStorage: ${err.message || err}\n`;
        }

        return { fbSuccess, sbSuccess, localSuccess, errorDetails };
    };

    // Save current import to Firebase and/or Supabase manually
    const handleSaveImport = async () => {
        if (!newImportTitle.trim()) {
            alert('Por favor, informe um título para a importação.');
            return;
        }

        setIsSavingImport(true);
        const { fbSuccess, sbSuccess, localSuccess, errorDetails } = await saveImportToDatabases(
            newImportTitle.trim(),
            reportDate,
            inputMode,
            rawText,
            biRawText,
            entries
        );

        if (fbSuccess && sbSuccess) {
            alert('Importação salva com sucesso em ambos os bancos de dados (Firebase e Supabase)!');
        } else if (sbSuccess && isSupabaseConfigured) {
            alert('Importação salva com sucesso no banco de dados Supabase e em cache local!');
        } else if (fbSuccess && isFirebaseConfigured) {
            alert('Importação salva com sucesso no Firebase e em cache local!');
        } else if (localSuccess) {
            if (errorDetails) {
                alert(`Importação salva localmente (offline).\nAviso de sincronização remota:\n${errorDetails}`);
            } else {
                alert('Importação salva localmente com sucesso (LocalStorage)!');
            }
        } else {
            alert(`Falha ao salvar importação:\n${errorDetails}`);
        }

        setShowSaveModal(false);
        setNewImportTitle('');
        fetchSavedImports();
        setIsSavingImport(false);
    };

    // Automatic silent background saving
    const handleAutoSave = async (parsedEntries: any[], dateStr: string, mode: 'full' | 'bi_only', rawTxt: string, biRawTxt: string) => {
        setAutoSaveStatus('saving');
        
        const now = new Date();
        const formattedTime = now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
        const sourceLabel = mode === 'full' ? 'Totem+BI' : 'BI_Only';
        const autoTitle = `Auto_${sourceLabel}_${dateStr.replace(/\//g, '-')}_${formattedTime}`;

        try {
            const { fbSuccess, sbSuccess, localSuccess, errorDetails } = await saveImportToDatabases(
                autoTitle,
                dateStr,
                mode,
                rawTxt,
                biRawTxt,
                parsedEntries
            );

            if (fbSuccess || sbSuccess || localSuccess) {
                setAutoSaveStatus('success');
                if (fbSuccess || sbSuccess) {
                    console.log(`[AutoSave] Importação "${autoTitle}" sincronizada com sucesso.`);
                } else {
                    console.log(`[AutoSave] Importação "${autoTitle}" armazenada em cache local (modo offline/fallback).`);
                }
                fetchSavedImports();
                // Limpar status após 5 segundos
                setTimeout(() => setAutoSaveStatus('idle'), 5000);
            } else {
                setAutoSaveStatus('error');
                console.warn('[AutoSave] Não foi possível salvar:', errorDetails);
                setTimeout(() => setAutoSaveStatus('idle'), 5000);
            }
        } catch (err) {
            console.warn('[AutoSave] Falha tratada:', err);
            setAutoSaveStatus('error');
            setTimeout(() => setAutoSaveStatus('idle'), 5000);
        }
    };

    // Delete saved import from Firebase, Supabase, or LocalStorage
    const handleDeleteImport = async (importId: string, source: 'firebase' | 'supabase' | 'local', e: React.MouseEvent) => {
        e.stopPropagation();
        const dbName = source === 'supabase' ? 'Supabase' : source === 'firebase' ? 'Firebase' : 'LocalStorage';
        if (!window.confirm(`Deseja realmente excluir esta importação? Ela será removida permanentemente do ${dbName}.`)) return;
        
        try {
            if (source === 'supabase') {
                const { error } = await supabase
                    .from('tma_imports')
                    .delete()
                    .eq('id', importId);
                if (error) {
                    alert(`Erro ao excluir do Supabase: ${error.message}`);
                    return;
                }
            } else if (source === 'firebase') {
                await deleteDoc(doc(db, 'tma_imports', importId));
            } else {
                // Local
                const localSaved = localStorage.getItem('tma_local_imports');
                if (localSaved) {
                    let list = JSON.parse(localSaved);
                    list = list.filter((item: any) => item.id !== importId);
                    localStorage.setItem('tma_local_imports', JSON.stringify(list));
                }
            }
            alert(`Importação excluída com sucesso do ${dbName}.`);
            fetchSavedImports();
        } catch (err: any) {
            console.error(`Erro ao excluir importação do ${dbName}:`, err);
            alert(`Erro ao excluir importação do ${dbName}.`);
        }
    };

    // Load saved import state from Firebase, Supabase, or LocalStorage
    const handleLoadImport = async (savedDoc: any, showAlert = true) => {
        if (savedDoc.source === 'supabase') {
            setIsLoadingImports(true);
            try {
                const { data: entriesData, error } = await supabase
                    .from('tma_entries')
                    .select('*')
                    .eq('import_id', savedDoc.id);
                
                if (error) {
                    if (showAlert) alert(`Erro ao carregar detalhes do Supabase: ${error.message}`);
                    return;
                }
                
                const mappedEntries = (entriesData || []).map((e: any) => ({
                    id: e.id,
                    placa: e.placa,
                    placa2: e.placa_carreta || '',
                    transportadora: e.transportadora || 'N/A',
                    lacre: e.lacre || '',
                    notaFiscal: e.nota_fiscal || '',
                    pedido: e.pedido || '',
                    origem: e.origem || '',
                    local: e.local_doca || '',
                    processo: e.processo || '',
                    operacao: e.operacao || '',
                    turno: e.turno === 'N' ? 'N/A' : e.turno,
                    checkin: e.hora_checkin ? new Date(e.hora_checkin).toLocaleString('pt-BR') : '',
                    horaEntrada: e.hora_entrada ? new Date(e.hora_entrada).toLocaleString('pt-BR') : '',
                    entrada: e.hora_entrada ? new Date(e.hora_entrada).toLocaleString('pt-BR') : '',
                    horaDoca: e.hora_doca ? new Date(e.hora_doca).toLocaleString('pt-BR') : '',
                    horaSaidaDoca: e.hora_saida_doca ? new Date(e.hora_saida_doca).toLocaleString('pt-BR') : '',
                    horaSaidaFabrica: e.hora_saida_fabrica ? new Date(e.hora_saida_fabrica).toLocaleString('pt-BR') : '',
                    saida: e.hora_saida_fabrica ? new Date(e.hora_saida_fabrica).toLocaleString('pt-BR') : '',
                    tmfe_calculado: e.tmfe || 0,
                    tmfi: e.tmfi || 0,
                    tmc: e.tmc || 0,
                    tms: e.tms || 0,
                    total: e.tma || 0,
                    tmaReal: e.tma_real || 0,
                    bi_status: e.bi_status || '',
                    bi_duracao: e.bi_duracao || 0,
                    bi_gps_last: e.bi_gps_last ? new Date(e.bi_gps_last).toLocaleString('pt-BR') : '',
                    bi_lat: e.bi_lat || 0,
                    bi_lng: e.bi_lng || 0,
                    bi_status_veiculo: e.bi_status_veiculo || '',
                    bi_ultimo_local_parada: e.bi_ultimo_local_parada || '',
                    bi_canal: e.bi_canal || '',
                    bi_inicio_parada: e.bi_inicio_parada ? new Date(e.bi_inicio_parada).toLocaleString('pt-BR') : '',
                    bi_fim_parada: e.bi_fim_parada ? new Date(e.bi_fim_parada).toLocaleString('pt-BR') : '',
                    bi_unidade_dimensionada: e.bi_unidade_dimensionada || '',
                    dt: e.dt_codigo || '',
                    tp: e.tp_codigo || '',
                    isOutlier: e.is_outlier || false,
                    isManobra: e.is_manobra || false,
                    isBackup: e.is_backup || false,
                    isInRadius: e.is_in_radius || false,
                    status_raio: e.status_raio || 'FORA',
                    status_sla_drop: e.status_sla_drop || 'NORMAL',
                    alerta_3h: e.alerta_3h || false,
                    unidade_divergente: e.unidade_divergente || false,
                    flag_manobra: e.flag_manobra || false,
                    status: e.status || 'OK',
                    item_inspecionado: e.item_inspecionado || '',
                    description: e.description || ''
                }));

                setRawText(savedDoc.raw_text || '');
                setBiRawText(savedDoc.bi_raw_text || '');
                
                let displayDate = savedDoc.data_ocorrencia || '--/--/----';
                if (displayDate.includes('-')) {
                    const parts = displayDate.split('-');
                    if (parts.length === 3 && parts[0].length === 4) {
                        displayDate = `${parts[2]}/${parts[1]}/${parts[0]}`;
                    }
                }
                setReportDate(displayDate);
                setEntries(mappedEntries);
                setView('dashboard');
                if (showAlert) alert(`Importação "${savedDoc.titulo}" carregada com sucesso do Supabase!`);
            } catch (err: any) {
                console.error(err);
                if (showAlert) alert(`Erro ao carregar do Supabase: ${err.message || err}`);
            } finally {
                setIsLoadingImports(false);
            }
        } else {
            // Firebase or Local Document
            setRawText(savedDoc.raw_text || '');
            setBiRawText(savedDoc.bi_raw_text || '');
            setReportDate(savedDoc.data_ocorrencia || '--/--/----');
            setEntries(savedDoc.entries || []);
            setView('dashboard');
            if (showAlert) {
                const sourceLabel = savedDoc.source === 'local' ? 'LocalStorage' : 'Firebase';
                alert(`Importação "${savedDoc.titulo}" carregada com sucesso do ${sourceLabel}!`);
            }
        }
    };

    // Filtros
    const [filterPlaca, setFilterPlaca] = useState('');
    const [filterTransp, setFilterTransp] = useState('ALL');
    const [filterTurno, setFilterTurno] = useState<'ALL' | 'A' | 'B' | 'C'>('ALL');
    const [filterSpecificDate, setFilterSpecificDate] = useState('ALL');
    const [filterSource, setFilterSource] = useState<'TODOS' | 'TOTEM' | 'BI'>('TODOS');
    const [onlyCritical, setOnlyCritical] = useState(false);
    const [last5HoursOnly, setLast5HoursOnly] = useState(false);
    const [timeFilterType, setTimeFilterType] = useState<'NONE' | 'TMFI' | 'TMC' | 'TMS' | 'TMFE' | 'TMPC'>('NONE');
    const [chartIndicator, setChartIndicator] = useState<'total' | 'tmfi' | 'tmc' | 'tms' | 'tmfe_calculado' | 'tmpc_calculado'>('total');
    const [displayMode, setDisplayMode] = useState<'grid' | 'list'>('grid');
    const [showManobra, setShowManobra] = useState(false);
    const [showOutliers, setShowOutliers] = useState(false);
    const [purgeIncomplete, setPurgeIncomplete] = useState(false);
    const [fadelOnly, setFadelOnly] = useState(true);
    const [showMainSeries, setShowMainSeries] = useState(true);
    const [showTrendSeries, setShowTrendSeries] = useState(true);

    // Estado para Simulação de Diluição
    const [showSimulation, setShowSimulation] = useState(false);
    const [simCurrentTma, setSimCurrentTma] = useState('');
    const [simTargetTma, setSimTargetTma] = useState('');
    const [simMinTime, setSimMinTime] = useState('30'); // 30 min padrão
    const [simResult, setSimResult] = useState<{ cycles: number, suggestions: string[] } | null>(null);

    useEffect(() => {
        const timer = setInterval(() => setCurrentTime(new Date()), 15000);
        return () => clearInterval(timer);
    }, []);

    const handleSimulate = () => {
        const currentTmaSec = timeToSeconds(simCurrentTma);
        const targetTmaSec = timeToSeconds(simTargetTma);
        const minTimeSec = parseInt(simMinTime) * 60;
        const currentCount = summaryData.inYardCount || 1;

        if (targetTmaSec >= currentTmaSec) {
            setSimResult({ cycles: 0, suggestions: ['A meta já foi atingida ou é superior ao TMA atual.'] });
            return;
        }

        if (minTimeSec >= targetTmaSec) {
            setSimResult({ cycles: 0, suggestions: ['O tempo mínimo de permanência deve ser menor que a meta de TMA.'] });
            return;
        }

        // NewCycles = (CurrentTotalTMA - TargetTMA * CurrentCount) / (TargetTMA - MinTime)
        const currentTotalTma = currentTmaSec * currentCount;
        const neededCycles = Math.ceil((currentTotalTma - (targetTmaSec * currentCount)) / (targetTmaSec - minTimeSec));
        
        // Sugestões de veículos para retirar do raio (os que estão há mais tempo no raio)
        const candidates = [...filteredEntries]
            .filter(e => e.isInRadius)
            .sort((a, b) => (b.bi_duracao || 0) - (a.bi_duracao || 0))
            .slice(0, 5)
            .map(e => `${e.placa} (${secondsToTimeStr(e.bi_duracao || 0)})`);

        setSimResult({
            cycles: Math.max(0, neededCycles),
            suggestions: candidates.length > 0 
                ? [`Retirar os seguintes veículos do raio para diluição:`, ...candidates]
                : ['Nenhum veículo no raio para retirada imediata.']
        });
    };

    const parseBIData = (text: string): BIEntry[] => {
        if (!text.trim()) return [];
        const biEntries: BIEntry[] = [];
        const biLines = text.trim().split('\n');
        
        let delimiter = '\t';
        if (biLines[0].includes(';')) delimiter = ';';
        else if (biLines[0].includes(',') && !biLines[0].includes('\t')) delimiter = ',';

        const biHeaders = biLines[0].toLowerCase().split(delimiter);
        
        let bIdxPlaca = biHeaders.findIndex(h => h === 'placa' || h.includes('placa') || h.includes('cavalo') || h.includes('veículo') || h.includes('veiculo'));
        let bIdxStatusVeiculo = biHeaders.findIndex(h => h === 'status veículo' || h.includes('status veiculo') || h.includes('status do veiculo') || h.includes('status da placa'));
        let bIdxUltimoLocal = biHeaders.findIndex(h => h === 'último local de parada' || h.includes('último local') || h === 'local' || h.includes('parada'));
        let bIdxInicio = biHeaders.findIndex(h => h === 'início parada' || h.includes('início') || h.includes('inicio') || h.includes('entrada'));
        let bIdxFim = biHeaders.findIndex(h => h === 'fim parada' || h.includes('fim') || h.includes('saída') || h.includes('saida'));
        let bIdxDuracao = biHeaders.findIndex(h => h === 'duração' || h.includes('duracao') || h.includes('tempo'));
        let bIdxStatus = biHeaders.findIndex(h => h === 'status' && !h.includes('veículo') && !h.includes('placa'));
        let bIdxGPS = biHeaders.findIndex(h => h === 'último sinal gps' || h === 'sinal gps' || h.includes('gps'));
        let bIdxDT = biHeaders.findIndex(h => h === 'dt' || h.includes('dt'));
        let bIdxTP = biHeaders.findIndex(h => h === 'tp' || h.includes('tp'));
        let bIdxLat = biHeaders.findIndex(h => h === 'latitude' || h === 'lat');
        let bIdxLng = biHeaders.findIndex(h => h === 'longitude' || h === 'lng' || h === 'long');
        let bIdxUnidade = biHeaders.findIndex(h => h === 'un. dimens.' || h === 'un dimens.' || h.includes('unidade') || h.includes('dimensionada'));
        let bIdxCanal = biHeaders.findIndex(h => h === 'canal' || h.includes('canal'));
        let bIdxTransp = biHeaders.findIndex(h => h === 'transportadora' || h.includes('transportadora') || h.includes('empresa'));
        let bIdxDate = biHeaders.findIndex(h => h === 'date' || h === 'data');

        if (bIdxPlaca === -1 || biHeaders.length >= 14) {
            if (bIdxDate === -1) bIdxDate = 0;
            if (bIdxPlaca === -1) bIdxPlaca = 1;
            if (bIdxUltimoLocal === -1) bIdxUltimoLocal = 2;
            if (bIdxInicio === -1) bIdxInicio = 4;
            if (bIdxFim === -1) bIdxFim = 5;
            if (bIdxDuracao === -1) bIdxDuracao = 6;
            if (bIdxTransp === -1) bIdxTransp = 8;
            if (bIdxUnidade === -1) bIdxUnidade = 9;
            if (bIdxCanal === -1) bIdxCanal = 10;
            if (bIdxLat === -1) bIdxLat = 11;
            if (bIdxLng === -1) bIdxLng = 12;
            if (bIdxStatusVeiculo === -1) bIdxStatusVeiculo = 13;
        }

        for (let i = 0; i < biLines.length; i++) {
            const cols = biLines[i].split(delimiter);
            if (cols.length < 3) continue;
            if (i === 0 && (biLines[0].toLowerCase().includes('placa') || biLines[0].toLowerCase().includes('data'))) continue;

            const transportadora = bIdxTransp !== -1 ? cols[bIdxTransp]?.trim() : '';
            if (fadelOnly && transportadora && !transportadora.toUpperCase().includes('FADEL')) continue;

            let durSeconds = 0;
            if (bIdxDuracao !== -1) {
                const rawDur = (cols[bIdxDuracao] || '0').trim();
                if (rawDur.includes(':')) {
                    durSeconds = timeToSeconds(rawDur);
                } else {
                    const cleanDur = rawDur.replace(/[.\s]/g, '');
                    const val = parseInt(cleanDur) || 0;
                    if (val > 59) { 
                        const hh = Math.floor(val / 10000);
                        const mm = Math.floor((val % 10000) / 100);
                        const ss = val % 100;
                        durSeconds = (hh * 3600) + (mm * 60) + ss;
                    } else {
                        durSeconds = val;
                    }
                }
            }

            const placa = cols[bIdxPlaca]?.trim().toUpperCase() || '';
            if (!placa || placa === 'PLACA') continue;

            biEntries.push({
                placaCavalo: placa,
                inicioParada: cols[bIdxInicio] || '',
                fimParada: cols[bIdxFim] || '',
                duracao: durSeconds,
                status: cols[bIdxStatus]?.includes('Manobra') ? 'Manobra' : 'Ativa',
                ultimoSinalGPS: cols[bIdxGPS] || '',
                lat: parseFloat(cols[bIdxLat]?.replace(',', '.')) || 0,
                lng: parseFloat(cols[bIdxLng]?.replace(',', '.')) || 0,
                trackerLastDate: cols[bIdxGPS] || '',
                unidadeDimensionada: cols[bIdxUnidade] || '',
                statusVeiculo: cols[bIdxStatusVeiculo] || '',
                ultimoLocalParada: cols[bIdxUltimoLocal] || '',
                canal: cols[bIdxCanal] || '',
                dt: bIdxDT !== -1 ? cols[bIdxDT] : '',
                tp: bIdxTP !== -1 ? cols[bIdxTP] : '',
                transportadora: transportadora
            });
        }
        return biEntries;
    };

    const handleProcess = () => {
        setError('');
        if (!rawText.trim() && !biRawText.trim()) {
            setError('Cole os dados do Totem ou do BI para análise.');
            return;
        }

        const parsed: TMALogEntry[] = [];
        const uniqueKeys = new Set();
        let firstDetectedDate = '';

        const biEntries = parseBIData(biRawText);

        const matchedBiPlates = new Set<string>();

        if (rawText.trim()) {
            const lines = rawText.trim().split('\n');
            const headers = lines[0].toLowerCase().split('\t');

            const idxOperacao = headers.findIndex(h => h.includes('operação'));
            const idxPlaca1 = headers.findIndex(h => h.includes('placa 1'));
            const idxPlaca2 = headers.findIndex(h => h.includes('placa 2'));
            const idxTransp = headers.findIndex(h => h.includes('transportadora'));
            const idxEntradaFabrica = headers.findIndex(h => h === 'entrada fábrica' || (h.includes('entrada') && h.includes('fábrica') && !h.includes('-')));
            const idxEntradaDoca = headers.findIndex(h => h === 'entrada doca' || (h.includes('entrada') && h.includes('doca') && !h.includes('-')));
            const idxSaidaDoca = headers.findIndex(h => h === 'saída doca' || (h.includes('saída') && h.includes('doca')));
            const idxSaidaFabrica = headers.findIndex(h => h === 'saída fábrica' || (h.includes('saída') && h.includes('fábrica')));
            const idxTMC = headers.findIndex(h => h.includes('entrada doca - saída doca')); 
            const idxTMFI = headers.findIndex(h => h.includes('entrada fábrica - doca'));    
            const idxTMS = headers.findIndex(h => h.includes('saída doca - saída fábrica')); 
            const idxTotal = headers.findIndex(h => h.includes('total fábrica - saída'));

            if (idxEntradaFabrica !== -1 && idxPlaca1 !== -1) {
                for (let i = 1; i < lines.length; i++) {
                    const cols = lines[i].split('\t');
                    if (cols.length < 5) continue;

                    const operacao = cols[idxOperacao] || '';
                    const placa1 = cols[idxPlaca1]?.trim().toUpperCase() || '';
                    const placa2 = idxPlaca2 !== -1 ? cols[idxPlaca2]?.trim().toUpperCase() || '' : '';
                    
                    const uniqueKey = `${placa1}-${placa2}-${cols[idxEntradaFabrica]}`.replace(/\s/g, '');
                    if (uniqueKeys.has(uniqueKey)) continue;

                    if (!operacao.toUpperCase().includes('CARGA LATAS') || !placa1 || placa1.includes('TOTAL')) continue;

                    const horaFabrica = cols[idxEntradaFabrica] || '';
                    const horaDoca = idxEntradaDoca !== -1 ? (cols[idxEntradaDoca] || '') : '';
                    const horaSaidaDoca = idxSaidaDoca !== -1 ? (cols[idxSaidaDoca] || '') : '';
                    const horaSaidaFabrica = idxSaidaFabrica !== -1 ? (cols[idxSaidaFabrica] || '') : '';
                    const refTime = (horaDoca && horaDoca !== '-') ? horaDoca : horaFabrica;

                    if (!firstDetectedDate && refTime.includes('/') && !refTime.includes('1970') && !refTime.includes('01/01/1970')) {
                        firstDetectedDate = refTime.split(' ')[0];
                    }

                    const matchingBI = biEntries.find(b => b.placaCavalo === placa1);
                    if (matchingBI) matchedBiPlates.add(placa1);
                    
                    const todayStr = getTodayStr();
                    
                    let tmfe = 0;
                    let tmpc = 0;
                    
                    let statusRaio: TMALogEntry['status_raio'] = 'FORA';
                    let statusSlaDrop: TMALogEntry['status_sla_drop'] = 'NORMAL';
                    let alerta_3h = false;
                    let unidadeDivergente = false;
                    let flagManobra = false;
                    let dt_bi = '';
                    let tp_bi = '';
                    let isInRadius = false;

                    if (matchingBI) {
                        flagManobra = matchingBI.status === 'Manobra';
                        dt_bi = matchingBI.dt;
                        tp_bi = matchingBI.tp;
                        
                        if (matchingBI.duracao > 2400) isInRadius = true;
                        
                        const dist = calculateDistance(matchingBI.lat, matchingBI.lng, FACTORY_COORDS.lat, FACTORY_COORDS.lng);
                        const insideRadius = dist <= FACTORY_RADIUS_KM;
                        statusRaio = insideRadius ? 'DENTRO' : 'FORA';

                        if (matchingBI.unidadeDimensionada && !matchingBI.unidadeDimensionada.includes('F. DE LATAS')) {
                            unidadeDivergente = true;
                        }

                        if (!flagManobra) {
                            const dtEntrada = parseDateTime(horaFabrica, firstDetectedDate || todayStr);
                            const dtInicioParada = parseDateTime(matchingBI.inicioParada, firstDetectedDate || todayStr);
                            
                            const hasDT = !!matchingBI.dt && matchingBI.dt !== '-';
                            
                            if (hasDT) {
                                tmpc = matchingBI.duracao;
                                tmfe = 0;
                            } else {
                                if (dtInicioParada) {
                                    const endRef = dtEntrada || new Date(); 
                                    tmfe = Math.max(0, (endRef.getTime() - dtInicioParada.getTime()) / 1000);
                                    if (matchingBI.duracao > tmfe) tmfe = matchingBI.duracao;
                                } else {
                                    tmfe = matchingBI.duracao;
                                }
                                tmpc = 0;
                            }
                        }

                        if (matchingBI.status === 'Ativa' && matchingBI.duracao > 1800) statusSlaDrop = 'ALERTA';
                        if (matchingBI.status === 'Ativa' && matchingBI.duracao > 10800 && insideRadius) alerta_3h = true;
                    }

                    // Validação individual e independente de cada métrica (Regras 1 a 27)
                    const diffTmfi = (horaFabrica && horaDoca && horaDoca !== '-')
                        ? calculateTimestampDiffInSeconds(horaFabrica, horaDoca, firstDetectedDate || todayStr)
                        : null;
                    const rawTmfi = diffTmfi !== null ? diffTmfi : (idxTMFI !== -1 ? cols[idxTMFI] : null);
                    let tmfiValidation = validateDuration(rawTmfi);

                    const diffTmc = (horaDoca && horaSaidaDoca && horaDoca !== '-' && horaSaidaDoca !== '-')
                        ? calculateTimestampDiffInSeconds(horaDoca, horaSaidaDoca, firstDetectedDate || todayStr)
                        : null;
                    const rawTmc = diffTmc !== null ? diffTmc : (idxTMC !== -1 ? cols[idxTMC] : null);
                    let tmcValidation = validateDuration(rawTmc);

                    const diffTmfs = (horaSaidaDoca && horaSaidaFabrica && horaSaidaDoca !== '-' && horaSaidaFabrica !== '-')
                        ? calculateTimestampDiffInSeconds(horaSaidaDoca, horaSaidaFabrica, firstDetectedDate || todayStr)
                        : null;
                    const rawTmfs = diffTmfs !== null ? diffTmfs : (idxTMS !== -1 ? cols[idxTMS] : null);
                    let tmfsValidation = validateDuration(rawTmfs);

                    // Totem em andamento ("Até agora")
                    if (!tmfiValidation.isValid && horaFabrica && horaFabrica !== '-' && (!horaDoca || horaDoca === '-')) {
                        const dtEntrada = parseDateTime(horaFabrica, firstDetectedDate || todayStr);
                        if (dtEntrada) {
                            const ongoing = Math.max(0, (new Date().getTime() - dtEntrada.getTime()) / 1000);
                            tmfiValidation = validateDuration(ongoing);
                        }
                    }
                    if (!tmcValidation.isValid && horaDoca && horaDoca !== '-' && (!horaSaidaDoca || horaSaidaDoca === '-')) {
                        const dtDoca = parseDateTime(horaDoca, firstDetectedDate || todayStr);
                        if (dtDoca) {
                            const ongoing = Math.max(0, (new Date().getTime() - dtDoca.getTime()) / 1000);
                            tmcValidation = validateDuration(ongoing);
                        }
                    }
                    if (!tmfsValidation.isValid && horaSaidaDoca && horaSaidaDoca !== '-' && (!horaSaidaFabrica || horaSaidaFabrica === '-')) {
                        const dtSaidaDoca = parseDateTime(horaSaidaDoca, firstDetectedDate || todayStr);
                        if (dtSaidaDoca) {
                            const ongoing = Math.max(0, (new Date().getTime() - dtSaidaDoca.getTime()) / 1000);
                            tmfsValidation = validateDuration(ongoing);
                        }
                    }

                    const diffTotal = (horaFabrica && horaSaidaFabrica && horaFabrica !== '-' && horaSaidaFabrica !== '-')
                        ? calculateTimestampDiffInSeconds(horaFabrica, horaSaidaFabrica, firstDetectedDate || todayStr)
                        : null;
                    const rawTotal = diffTotal !== null 
                        ? diffTotal 
                        : ((idxTotal !== -1 && cols[idxTotal] && cols[idxTotal] !== '-') 
                            ? cols[idxTotal] 
                            : ((tmfiValidation.value || 0) + (tmcValidation.value || 0) + (tmfsValidation.value || 0)));
                    const totalValidation = validateDuration(rawTotal);

                    const tmfeValidation = validateDuration(tmfe);
                    const tmpcValidation = validateDuration(tmpc);

                    const isOutlier = tmfiValidation.outlier || 
                        tmcValidation.outlier || 
                        tmfsValidation.outlier || 
                        totalValidation.outlier || 
                        tmfeValidation.outlier || 
                        tmpcValidation.outlier || 
                        (matchingBI?.duracao ? matchingBI.duracao >= OUTLIER_THRESHOLD_SECONDS : false) || 
                        flagManobra;

                    const invalidReasons: string[] = [];
                    if (!tmfiValidation.isValid) invalidReasons.push(`TMFI ${tmfiValidation.status}`);
                    if (!tmcValidation.isValid) invalidReasons.push(`TMC ${tmcValidation.status}`);
                    if (!tmfsValidation.isValid) invalidReasons.push(`TMFS ${tmfsValidation.status}`);
                    if (!totalValidation.isValid) invalidReasons.push(`Total ${totalValidation.status}`);

                    const entryDescription = [
                        tmfeValidation.isValid ? `FE: ${tmfeValidation.formatted}` : (matchingBI?.inicioParada && !horaFabrica ? `FILA` : null),
                        tmfiValidation.isValid ? `FI: ${tmfiValidation.formatted}` : null,
                        tmcValidation.isValid ? `DO: ${tmcValidation.formatted}` : null,
                        tmfsValidation.isValid ? `SA: ${tmfsValidation.formatted}` : null,
                        tmpcValidation.isValid ? `PC: ${tmpcValidation.formatted}` : (horaSaidaFabrica && matchingBI?.ultimoSinalGPS ? `TRÂN` : null),
                        totalValidation.isValid ? `TOT: ${totalValidation.formatted}` : null
                    ].filter(Boolean).join(' • ');

                    uniqueKeys.add(uniqueKey);
                    parsed.push({
                        id: `tma-${i}-${Date.now()}`,
                        placa: placa1,
                        placa2: placa2,
                        operacao,
                        transportadora: cols[idxTransp]?.trim() || 'N/A',
                        tmc: tmcValidation.value ?? 0,
                        tmfi: tmfiValidation.value ?? 0,
                        tms: tmfsValidation.value ?? 0,
                        total: totalValidation.value ?? ((tmfiValidation.value || 0) + (tmcValidation.value || 0) + (tmfsValidation.value || 0)),
                        tmcStr: tmcValidation.formatted,
                        tmfiStr: tmfiValidation.formatted,
                        tmsStr: tmfsValidation.formatted,
                        totalStr: totalValidation.formatted,
                        tmfiValidation,
                        tmcValidation,
                        tmfsValidation,
                        tmsValidation: tmfsValidation,
                        totalValidation,
                        tmfeValidation,
                        tmpcValidation,
                        motivoInvalidezGeral: invalidReasons.length > 0 ? invalidReasons.join(' • ') : undefined,
                        horaEntrada: horaFabrica,
                        horaDoca,
                        horaSaidaDoca,
                        horaSaidaFabrica,
                        turno: getShift(refTime),
                        tmfe_calculado: tmfeValidation.value ?? 0,
                        tmpc_calculado: tmpcValidation.value ?? 0,
                        description: entryDescription,
                        status_raio: statusRaio,
                        status_sla_drop: statusSlaDrop,
                        alerta_3h: alerta_3h,
                        unidade_divergente: unidadeDivergente,
                        flag_manobra: flagManobra,
                        bi_status: matchingBI?.status,
                        bi_inicio_parada: matchingBI?.inicioParada,
                        bi_fim_parada: matchingBI?.fimParada,
                        bi_duracao: matchingBI?.duracao,
                        bi_gps_last: matchingBI?.ultimoSinalGPS,
                        bi_lat: matchingBI?.lat,
                        bi_lng: matchingBI?.lng,
                        bi_unidade_dimensionada: matchingBI?.unidadeDimensionada,
                        bi_status_veiculo: matchingBI?.statusVeiculo,
                        bi_ultimo_local_parada: matchingBI?.ultimoLocalParada,
                        bi_canal: matchingBI?.canal,
                        dt: dt_bi,
                        tp: tp_bi,
                        isOutlier,
                        isInRadius
                    });
                }
            } else if (!biRawText.trim()) {
                setError('Estrutura de colunas do Totem não compatível. Verifique os cabeçalhos (Placa 1 e Entrada Fábrica).');
                return;
            }
        }

        // Processar entradas do BI que não foram vinculadas ao Totem (ou todas se não houver Totem)
        biEntries.forEach((b, idx) => {
            if (!matchedBiPlates.has(b.placaCavalo)) {
                const todayStr = getTodayStr();
                if (!firstDetectedDate && b.inicioParada.includes('/') && !b.inicioParada.includes('1970') && !b.inicioParada.includes('01/01/1970')) {
                    firstDetectedDate = b.inicioParada.split(' ')[0];
                }

                const dist = calculateDistance(b.lat, b.lng, FACTORY_COORDS.lat, FACTORY_COORDS.lng);
                const insideRadius = dist <= FACTORY_RADIUS_KM;
                
                const dtInicioParada = parseDateTime(b.inicioParada, firstDetectedDate || todayStr);
                let duration_live = b.duracao;
                if (dtInicioParada) {
                    duration_live = Math.max(b.duracao, (new Date().getTime() - dtInicioParada.getTime()) / 1000);
                }

                const hasDT = !!b.dt && b.dt !== '-';
                const tmfe_live = hasDT ? 0 : duration_live;
                const tmpc_live = hasDT ? duration_live : 0;

                const tmfeValidation = validateDuration(tmfe_live);
                const tmpcValidation = validateDuration(tmpc_live);
                const totalValidation = validateDuration(duration_live);
                const tmfiValidation = validateDuration(null);
                const tmcValidation = validateDuration(null);
                const tmfsValidation = validateDuration(null);
                const isOutlier = duration_live >= OUTLIER_THRESHOLD_SECONDS || b.status === 'Manobra';

                parsed.push({
                    id: `bi-only-${idx}-${Date.now()}`,
                    placa: b.placaCavalo,
                    operacao: 'CARGA LATAS (BI)',
                    transportadora: b.transportadora || 'N/A',
                    tmc: 0,
                    tmfi: 0,
                    tms: 0,
                    total: duration_live,
                    tmcStr: '--:--:--',
                    tmfiStr: '--:--:--',
                    tmsStr: '--:--:--',
                    totalStr: totalValidation.formatted,
                    tmfiValidation,
                    tmcValidation,
                    tmfsValidation,
                    tmsValidation: tmfsValidation,
                    totalValidation,
                    tmfeValidation,
                    tmpcValidation,
                    motivoInvalidezGeral: isOutlier ? 'Outlier BI (≥ 23h ou Manobra)' : undefined,
                    horaEntrada: '-', // FIX: Não mostrar entrada se não houver totem
                    turno: getShift(b.inicioParada),
                    tmfe_calculado: tmfeValidation.value ?? 0, 
                    tmpc_calculado: tmpcValidation.value ?? 0,
                    status_raio: insideRadius ? 'DENTRO' : 'FORA',
                    status_sla_drop: b.duracao > 1800 ? 'ALERTA' : 'NORMAL',
                    alerta_3h: b.duracao > 10800 && insideRadius,
                    unidade_divergente: b.unidadeDimensionada && !b.unidadeDimensionada.includes('F. DE LATAS') ? true : false,
                    flag_manobra: b.status === 'Manobra',
                    bi_status: b.status,
                    bi_inicio_parada: b.inicioParada,
                    bi_fim_parada: b.fimParada,
                    bi_duracao: b.duracao,
                    bi_gps_last: b.ultimoSinalGPS,
                    bi_lat: b.lat,
                    bi_lng: b.lng,
                    bi_unidade_dimensionada: b.unidadeDimensionada,
                    bi_status_veiculo: b.statusVeiculo,
                    bi_ultimo_local_parada: b.ultimoLocalParada,
                    bi_canal: b.canal,
                    dt: b.dt,
                    tp: b.tp,
                    isOutlier,
                    isInRadius: b.duracao > 2400
                });
            }
        });

        if (parsed.length === 0) {
            setError('Nenhum carregamento "CARGA LATAS" identificado nos dados colados.');
            return;
        }

        setReportDate(firstDetectedDate || '--/--/----');
        setEntries(parsed);
        setView('dashboard');
        
        // Trigger silent auto-save to background databases
        handleAutoSave(parsed, firstDetectedDate || '--/--/----', inputMode, rawText, biRawText);
    };

    const handleExportToCSV = () => {
        if (filteredEntries.length === 0) {
            alert('Não há dados para exportar.');
            return;
        }

        const headers = ['Placa', 'Carreta', 'Transportadora', 'Turno', 'Entrada_Fabrica', 'Entrada_Doca', 'TMFI', 'TMC', 'TMS', 'TMA_Total'];
        const rows = filteredEntries.map(e => [
            `"${e.placa}"`,
            `"${e.placa2}"`,
            `"${e.transportadora}"`,
            e.turno,
            `"${e.horaEntrada}"`,
            `"${e.horaDoca}"`,
            e.tmfiStr,
            e.tmcStr,
            e.tmsStr,
            e.totalStr,
        ]);

        let csvContent = "data:text/csv;charset=utf-8,"
            + headers.join(',') + '\n'
            + rows.map(r => r.join(',')).join('\n');

        const encodedUri = encodeURI(csvContent);
        const link = document.createElement("a");
        link.setAttribute("href", encodedUri);
        link.setAttribute("download", `relatorio_tma_${reportDate.replace(/\//g, '-')}.csv`);
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };

    const handleUseMockData = () => {
        const mockData = `Operação	Placa 1	Placa 2	Transportadora	Entrada Fábrica	Entrada Doca	Saída Doca	Saída Fábrica	Entrada Fábrica - Doca	Entrada Doca - Saída Doca	Saída Doca - Saída Fábrica	Total Fábrica - Saída
CARGA LATAS	ABC-1234	XYZ-5678	LOG-MAIS	10/07/2024 08:00:00	10/07/2024 08:25:00	10/07/2024 09:15:00	10/07/2024 09:35:00	00:25:00	00:50:00	00:20:00	01:35:00
CARGA LATAS	DEF-5678	UVW-9012	TRANS-RAPIDO	10/07/2024 09:15:00	10/07/2024 09:30:00	10/07/2024 10:40:00	10/07/2024 10:58:00	00:15:00	01:10:00	00:18:00	01:43:00
CARGA LATAS	GHI-9012	RST-3456	VELOZ-CARGAS	10/07/2024 10:00:00	10/07/2024 11:00:00	10/07/2024 11:55:00	10/07/2024 12:35:00	01:00:00	00:55:00	00:40:00	02:35:00
CARGA LATAS	JKL-3456	MNO-7890	LOG-MAIS	10/07/2024 11:30:00	-	-	-	-	-	-	-
CARGA LATAS	PQR-7890	STU-1234	VELOZ-CARGAS	10/07/2024 12:00:00	10/07/2024 12:15:00	10/07/2024 13:00:00	10/07/2024 13:15:00	00:15:00	00:45:00	00:15:00	01:15:00
CARGA LATAS	VWX-5678	YZA-9012	TRANS-RAPIDO	10/07/2024 12:30:00	10/07/2024 13:10:00	10/07/2024 14:30:00	10/07/2024 14:55:00	00:40:00	01:20:00	00:25:00	02:25:00
`;
        const mockBiData = `PLACA	STATUS VEÍCULO	ÚLTIMO LOCAL DE PARADA	INÍCIO PARADA	FIM PARADA	STATUS ÚLTIMA PARADA	DURAÇÃO	ÚLTIMO SINAL GPS	STATUS	INDISPONÍVEL?	DT	TIPO VEÍCULO	UN. DIMENS.	TRANSPORTADORA	CANAL	latitude	longitude	trackerLastDate
ABC-1234	Parado	F. DE LATAS	10/07/2024 07:30:00		Parada em Aberto	1800	10/07/2024 09:40:00	Ativa	NÃO	6102726541/1	Padrão	F. DE LATAS	FADEL	INSUMOS	-23.5505	-46.6333	10/07/2024 09:40:00
DEF-5678	Parado	F. DE LATAS	10/07/2024 09:00:00		Parada em Aberto	900	10/07/2024 11:10:00	Ativa	NÃO	6102726541/1	Padrão	F. DE LATAS	FADEL	INSUMOS	-23.5510	-46.6340	10/07/2024 11:10:00
GHI-9012	Parado	F. DE LATAS	10/07/2024 09:30:00		Parada em Aberto	1800	10/07/2024 12:45:00	Ativa	NÃO	6102726541/1	Padrão	F. DE LATAS	FADEL	INSUMOS	-23.5500	-46.6330	10/07/2024 12:45:00
JKL-3456	Parado	F. DE LATAS	10/07/2024 11:00:00		Parada em Aberto	3600	10/07/2024 12:00:00	Ativa	NÃO	6102726541/1	Padrão	F. DE LATAS	FADEL	INSUMOS	-23.5505	-46.6333	10/07/2024 12:00:00
PQR-7890	Parado	F. DE LATAS	10/07/2024 11:45:00		Parada em Aberto	900	10/07/2024 13:20:00	Manobra	NÃO	6102726541/1	Padrão	F. DE LATAS	FADEL	INSUMOS	-23.5505	-46.6333	10/07/2024 13:20:00
VWX-5678	Parado	F. DE LATAS	10/07/2024 12:00:00		Parada em Aberto	1800	10/07/2024 15:00:00	Ativa	NÃO	6102726541/1	Padrão	F. DE LATAS	FADEL	INSUMOS	-23.5505	-46.6333	10/07/2024 15:00:00
`;
        setRawText(mockData);
        setBiRawText(mockBiData);
        setError('');
    };

    const filteredEntries = useMemo(() => {
        let res = entries.filter(e => {
            const refTime = (e.horaDoca && e.horaDoca !== '-') ? e.horaDoca : e.horaEntrada;
            const matchesPlaca = e.placa.includes(filterPlaca.toUpperCase()) || e.placa2.includes(filterPlaca.toUpperCase());
            
            const matchesTimeComp = timeFilterType === 'NONE' ? true : 
                                   timeFilterType === 'TMFI' ? e.tmfi > tmaConfig.tmfiTarget :
                                   timeFilterType === 'TMC' ? e.tmc > tmaConfig.tmcTarget :
                                   timeFilterType === 'TMS' ? e.tms > tmaConfig.tmsTarget :
                                   timeFilterType === 'TMFE' ? (e.tmfe_calculado || 0) > 1800 :
                                   timeFilterType === 'TMPC' ? (e.tmpc_calculado || 0) > 3600 : true;

            const matchesSource = filterSource === 'TODOS' ? true :
                                 filterSource === 'TOTEM' ? !e.bi_status :
                                 filterSource === 'BI' ? !!e.bi_status : true;

            const matchesManobra = showManobra ? true : !e.flag_manobra;
            const matchesOutlier = showOutliers ? true : !e.isOutlier;
            const matchesPurge = purgeIncomplete ? (!!e.horaSaidaFabrica && e.horaSaidaFabrica !== '-' && e.tmfi > 0 && e.tmc > 0 && e.tms > 0 && e.total > 0) : true;
            const matchesFadel = fadelOnly ? e.transportadora.toUpperCase().includes('FADEL') : true;

            return matchesPlaca &&
                   matchesSource &&
                   matchesManobra &&
                   matchesOutlier &&
                   matchesPurge &&
                   matchesFadel &&
                   (filterTransp === 'ALL' || e.transportadora === filterTransp) &&
                   (filterTurno === 'ALL' || e.turno === filterTurno) &&
                   (filterSpecificDate === 'ALL' || refTime.startsWith(filterSpecificDate)) &&
                   (!onlyCritical || (e.total > tmaConfig.totalTarget || e.status_sla_drop === 'ALERTA' || e.alerta_3h)) &&
                   matchesTimeComp;
        });

        if (last5HoursOnly && res.length > 0) {
            const latest = [...res].sort((a,b) => (b.horaDoca||b.horaEntrada).localeCompare(a.horaDoca||a.horaEntrada))[0];
            const refT = (latest.horaDoca && latest.horaDoca !== '-') ? latest.horaDoca : latest.horaEntrada;
            const [h, m] = (refT.split(' ')[1] || '00:00').split(':').map(Number);
            const latestS = h * 3600 + m * 60;
            res = res.filter(e => {
                const eRef = (e.horaDoca && e.horaDoca !== '-') ? e.horaDoca : e.horaEntrada;
                const [eh, em] = (eRef.split(' ')[1] || '00:00').split(':').map(Number);
                return (eh * 3600 + em * 60) >= (latestS - 18000);
            });
        }
        return res;
    }, [entries, filterPlaca, filterTransp, filterTurno, filterSpecificDate, onlyCritical, last5HoursOnly, tmaConfig, timeFilterType, showManobra, showOutliers]);

    const chartData = useMemo(() => {
        const buckets: Record<string, { hour: string, total: number, tmfi: number, tmc: number, tms: number, tmfe_calculado: number, tmpc_calculado: number, count: number }> = {};
        
        filteredEntries.filter(e => e.total > 0).forEach(e => {
            const timeStr = (e.horaDoca && e.horaDoca !== '-') ? e.horaDoca : e.horaEntrada;
            const hour = timeStr.split(' ')[1]?.substring(0, 2) + ':00';
            if (!hour || hour.includes('undefined')) return;

            if (!buckets[hour]) {
                buckets[hour] = { hour, total: 0, tmfi: 0, tmc: 0, tms: 0, tmfe_calculado: 0, tmpc_calculado: 0, count: 0 };
            }
            buckets[hour].total += e.total;
            buckets[hour].tmfi += e.tmfi;
            buckets[hour].tmc += e.tmc;
            buckets[hour].tms += e.tms;
            buckets[hour].tmfe_calculado += (e.tmfe_calculado || 0);
            buckets[hour].tmpc_calculado += (e.tmpc_calculado || 0);
            buckets[hour].count++;
        });

        const sortedData = Object.values(buckets)
            .sort((a, b) => a.hour.localeCompare(b.hour))
            .map(b => ({
                hour: b.hour,
                total: b.total / b.count,
                tmfi: b.tmfi / b.count,
                tmc: b.tmc / b.count,
                tms: b.tms / b.count,
                tmfe_calculado: b.tmfe_calculado / b.count,
                tmpc_calculado: b.tmpc_calculado / b.count,
            }));

        if (sortedData.length < 2) return sortedData;

        // Regressão Linear Simples: y = mx + b
        const n = sortedData.length;
        let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        
        sortedData.forEach((d, i) => {
            const val = d[chartIndicator] || 0;
            sumX += i;
            sumY += val;
            sumXY += i * val;
            sumX2 += i * i;
        });

        const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;

        return sortedData.map((d, i) => ({
            ...d,
            tendencia: Math.max(0, slope * i + intercept)
        }));
    }, [filteredEntries, chartIndicator]);

    const chartDataFadel = useMemo(() => {
        const buckets: Record<string, { hour: string, total: number, tmfi: number, tmc: number, tms: number, tmfe_calculado: number, tmpc_calculado: number, count: number }> = {};
        
        filteredEntries.filter(e => e.total > 0 && e.transportadora.toUpperCase().includes('FADEL')).forEach(e => {
            const timeStr = (e.horaDoca && e.horaDoca !== '-') ? e.horaDoca : e.horaEntrada;
            const hour = timeStr.split(' ')[1]?.substring(0, 2) + ':00';
            if (!hour || hour.includes('undefined')) return;

            if (!buckets[hour]) {
                buckets[hour] = { hour, total: 0, tmfi: 0, tmc: 0, tms: 0, tmfe_calculado: 0, tmpc_calculado: 0, count: 0 };
            }
            buckets[hour].total += e.total;
            buckets[hour].tmfi += e.tmfi;
            buckets[hour].tmc += e.tmc;
            buckets[hour].tms += e.tms;
            buckets[hour].tmfe_calculado += (e.tmfe_calculado || 0);
            buckets[hour].tmpc_calculado += (e.tmpc_calculado || 0);
            buckets[hour].count++;
        });

        const sortedData = Object.values(buckets)
            .sort((a, b) => a.hour.localeCompare(b.hour))
            .map(b => ({
                hour: b.hour,
                total: b.total / b.count,
                tmfi: b.tmfi / b.count,
                tmc: b.tmc / b.count,
                tms: b.tms / b.count,
                tmfe_calculado: b.tmfe_calculado / b.count,
                tmpc_calculado: b.tmpc_calculado / b.count,
            }));

        if (sortedData.length < 2) return sortedData;

        const n = sortedData.length;
        let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        
        sortedData.forEach((d, i) => {
            const val = d[chartIndicator] || 0;
            sumX += i;
            sumY += val;
            sumXY += i * val;
            sumX2 += i * i;
        });

        const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;

        return sortedData.map((d, i) => ({
            ...d,
            tendencia: Math.max(0, slope * i + intercept)
        }));
    }, [filteredEntries, chartIndicator]);

    const chartDataOthers = useMemo(() => {
        const buckets: Record<string, { hour: string, total: number, tmfi: number, tmc: number, tms: number, tmfe_calculado: number, tmpc_calculado: number, count: number }> = {};
        
        filteredEntries.filter(e => e.total > 0 && !e.transportadora.toUpperCase().includes('FADEL')).forEach(e => {
            const timeStr = (e.horaDoca && e.horaDoca !== '-') ? e.horaDoca : e.horaEntrada;
            const hour = timeStr.split(' ')[1]?.substring(0, 2) + ':00';
            if (!hour || hour.includes('undefined')) return;

            if (!buckets[hour]) {
                buckets[hour] = { hour, total: 0, tmfi: 0, tmc: 0, tms: 0, tmfe_calculado: 0, tmpc_calculado: 0, count: 0 };
            }
            buckets[hour].total += e.total;
            buckets[hour].tmfi += e.tmfi;
            buckets[hour].tmc += e.tmc;
            buckets[hour].tms += e.tms;
            buckets[hour].tmfe_calculado += (e.tmfe_calculado || 0);
            buckets[hour].tmpc_calculado += (e.tmpc_calculado || 0);
            buckets[hour].count++;
        });

        const sortedData = Object.values(buckets)
            .sort((a, b) => a.hour.localeCompare(b.hour))
            .map(b => ({
                hour: b.hour,
                total: b.total / b.count,
                tmfi: b.tmfi / b.count,
                tmc: b.tmc / b.count,
                tms: b.tms / b.count,
                tmfe_calculado: b.tmfe_calculado / b.count,
                tmpc_calculado: b.tmpc_calculado / b.count,
            }));

        if (sortedData.length < 2) return sortedData;

        const n = sortedData.length;
        let sumX = 0, sumY = 0, sumXY = 0, sumX2 = 0;
        
        sortedData.forEach((d, i) => {
            const val = d[chartIndicator] || 0;
            sumX += i;
            sumY += val;
            sumXY += i * val;
            sumX2 += i * i;
        });

        const slope = (n * sumXY - sumX * sumY) / (n * sumX2 - sumX * sumX);
        const intercept = (sumY - slope * sumX) / n;

        return sortedData.map((d, i) => ({
            ...d,
            tendencia: Math.max(0, slope * i + intercept)
        }));
    }, [filteredEntries, chartIndicator]);
    
    const summaryData = useMemo(() => {
        // Indicadores calculados estritamente com calculateAverage (Regras 1 a 27)
        const tmfiStats = calculateAverage(filteredEntries.map(e => e.tmfiValidation || validateDuration(e.tmfi)));
        const tmcStats = calculateAverage(filteredEntries.map(e => e.tmcValidation || validateDuration(e.tmc)));
        const tmfsStats = calculateAverage(filteredEntries.map(e => e.tmfsValidation || e.tmsValidation || validateDuration(e.tms)));
        const totalStats = calculateAverage(filteredEntries.map(e => e.totalValidation || validateDuration(e.total)));
        const tmfeStats = calculateAverage(filteredEntries.map(e => e.tmfeValidation || validateDuration(e.tmfe_calculado)));
        const tmpcStats = calculateAverage(filteredEntries.map(e => e.tmpcValidation || validateDuration(e.tmpc_calculado)));

        const inYardCount = filteredEntries.filter(e => !e.horaSaidaFabrica || e.horaSaidaFabrica === '-').length;
        const inRadiusCount = filteredEntries.filter(e => e.isInRadius).length;
        const outlierCount = filteredEntries.filter(e => e.isOutlier).length;

        // TMA Válido: Apenas FADEL, Ativa, >= 40 min no raio
        const validTmaEntries = filteredEntries.filter(e => 
            e.transportadora.toUpperCase().includes('FADEL') && 
            !e.flag_manobra && 
            e.bi_status === 'Ativa' && 
            (e.bi_duracao || 0) >= 2400
        );
        const validTmaStats = calculateAverage(validTmaEntries.map(e => e.totalValidation || validateDuration(e.total)));

        // TMA Total Fadel: TMFE + TMPC apenas para FADEL
        const fadelEntries = filteredEntries.filter(e => e.transportadora.toUpperCase().includes('FADEL') && !e.isOutlier);
        const fadelTmfeStats = calculateAverage(fadelEntries.map(e => e.tmfeValidation || validateDuration(e.tmfe_calculado)));
        const fadelTmpcStats = calculateAverage(fadelEntries.map(e => e.tmpcValidation || validateDuration(e.tmpc_calculado)));
        const avgTmaTotalFadel = (fadelTmfeStats.average ?? 0) + (fadelTmpcStats.average ?? 0);

        const totalVehicles = filteredEntries.length;
        const offenderCount = filteredEntries.filter(e => {
            const val = e.totalValidation?.value ?? e.total;
            return val > tmaConfig.totalTarget;
        }).length;

        const avgTmfi = tmfiStats.average ?? 0;
        const avgTmc = tmcStats.average ?? 0;
        const avgTms = tmfsStats.average ?? 0;
        const avgTotal = totalStats.average ?? (avgTmfi + avgTmc + avgTms);

        return {
            avgTma: avgTotal,
            avgTotal,
            avgTmfi,
            avgTmc,
            avgTms,
            avgTmfe: tmfeStats.average ?? 0,
            avgTmpc: tmpcStats.average ?? 0,
            avgTmiTmpc: avgTmfi + (tmpcStats.average ?? 0),
            avgValidTma: validTmaStats.average ?? 0,
            avgTmaTotalFadel,
            validTmaCount: validTmaEntries.length,
            offenderCount,
            offenderPercentage: totalVehicles > 0 ? (offenderCount / totalVehicles) * 100 : 0,
            inYardCount,
            inRadiusCount,
            outlierCount
        };
    }, [filteredEntries, tmaConfig, currentTime]);

    const renderSavedImportsSection = () => (
        <div className="bg-[#0c0f16]/90 backdrop-blur-md p-10 rounded-3xl border border-white/[0.06] shadow-[0_20px_50px_rgba(0,0,0,0.6)] relative overflow-hidden w-full">
            <div className="absolute top-0 right-0 p-4 opacity-5">
                <div className="w-20 h-20 border-t-2 border-r-2 border-blue-500" />
            </div>
            
            <div className="flex items-center gap-4 mb-6 border-b border-white/[0.04] pb-6">
                <div className="p-3 bg-blue-500/10 rounded-xl">
                    <FileClockIcon className="w-6 h-6 text-blue-400" />
                </div>
                <div>
                    <h4 className="text-lg font-black text-white uppercase tracking-tight">Importações Salvas na Nuvem</h4>
                    <p className="text-slate-400 text-xs mt-0.5">Histórico de planilhas de TMA processadas e salvas no Firebase e Supabase</p>
                </div>
            </div>

            {isLoadingImports ? (
                <div className="flex flex-col items-center justify-center py-10 gap-3">
                    <div className="w-8 h-8 border-4 border-t-blue-500 border-gray-700 rounded-full animate-spin"></div>
                    <span className="text-xs text-gray-500 font-mono uppercase tracking-widest">Carregando dados históricos...</span>
                </div>
            ) : savedImports.length === 0 ? (
                <div className="text-center py-10 border border-dashed border-white/[0.06] rounded-2xl bg-white/[0.01]">
                    <p className="text-sm text-gray-500 font-bold uppercase tracking-wide">Nenhuma importação encontrada</p>
                    <p className="text-xs text-gray-600 mt-1">Processe uma nova planilha e clique em "Salvar Importação" no painel.</p>
                </div>
            ) : (
                <div className="overflow-x-auto custom-scrollbar">
                    <table className="w-full text-left border-collapse">
                        <thead>
                            <tr className="border-b border-white/[0.06] text-[10px] font-black text-slate-500 uppercase tracking-widest">
                                <th className="py-3 px-4">Título / Banco</th>
                                <th className="py-3 px-4">Data Ref</th>
                                <th className="py-3 px-4">Tipo</th>
                                <th className="py-3 px-4">Data de Criação</th>
                                <th className="py-3 px-4 text-center">Veículos</th>
                                <th className="py-3 px-4 text-right">Ações</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/[0.03]">
                            {savedImports.map((imp) => (
                                <tr key={imp.id} className="text-xs text-slate-300 hover:bg-white/[0.02] transition-colors group">
                                    <td className="py-3.5 px-4 font-bold text-white max-w-xs truncate">
                                        <div className="flex items-center gap-2">
                                            <span>{imp.titulo}</span>
                                            <span className={`text-[9px] font-mono px-2 py-0.5 rounded-full uppercase tracking-wider ${imp.source === 'supabase' ? 'bg-indigo-500/15 text-indigo-400 border border-indigo-500/30' : 'bg-orange-500/15 text-orange-400 border border-orange-500/30'}`}>
                                                {imp.source}
                                            </span>
                                        </div>
                                    </td>
                                    <td className="py-3.5 px-4">
                                        <span className="bg-blue-900/30 text-blue-400 border border-blue-500/15 px-2.5 py-0.5 rounded-full text-[10px] font-black uppercase">
                                            {imp.data_ocorrencia}
                                        </span>
                                    </td>
                                    <td className="py-3.5 px-4 text-slate-400">{imp.tipo_entrada || 'Totem + BI'}</td>
                                    <td className="py-3.5 px-4 text-slate-400 font-mono text-[10px]">
                                        {imp.timestamp ? new Date(imp.timestamp).toLocaleString('pt-BR') : '-'}
                                    </td>
                                    <td className="py-3.5 px-4 text-center font-mono text-emerald-400 font-black">
                                        {imp.entries?.length || imp.entriesCount || 0}
                                    </td>
                                    <td className="py-3.5 px-4 text-right">
                                        <div className="flex justify-end gap-2 opacity-80 group-hover:opacity-100 transition-opacity">
                                            <button
                                                onClick={() => handleLoadImport(imp)}
                                                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white font-mono font-black rounded-lg text-[9px] uppercase tracking-wider transition-all flex items-center gap-1 shadow-md shadow-emerald-950/40 cursor-pointer"
                                            >
                                                <ClipboardPasteIcon className="w-3 h-3" /> Carregar
                                            </button>
                                            <button
                                                onClick={(e) => handleDeleteImport(imp.id, imp.source, e)}
                                                className="p-1.5 bg-red-950/50 hover:bg-red-900/60 text-red-400 rounded-lg border border-red-500/10 hover:border-red-500/30 transition-all flex items-center justify-center cursor-pointer"
                                                title={`Excluir do ${imp.source === 'supabase' ? 'Supabase' : 'Firebase'}`}
                                            >
                                                <TrashIcon className="w-3.5 h-3.5" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            )}
        </div>
    );

    const renderInput = () => (
        <div className="space-y-12 pb-16 animate-fade-in mt-12 max-w-6xl mx-auto px-4 sm:px-0">
            <div className="bg-[#0c0f16]/90 backdrop-blur-md p-5 sm:p-10 rounded-3xl border border-white/[0.06] shadow-[0_20px_50px_rgba(0,0,0,0.6)] relative overflow-hidden">
                {/* Ambient background glow */}
                <div className="absolute top-0 left-0 w-96 h-96 bg-emerald-500/[0.02] rounded-full blur-3xl pointer-events-none" />
                <div className="absolute bottom-0 right-0 w-96 h-96 bg-blue-500/[0.01] rounded-full blur-3xl pointer-events-none" />

                <div className="flex flex-col md:flex-row md:items-center gap-6 mb-10 relative z-10 border-b border-white/[0.04] pb-8">
                    <div className="p-4 sm:p-5 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg shadow-emerald-500/10 w-fit shrink-0">
                        <ActivityIcon className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                    </div>
                    <div className="flex-1 min-w-0">
                        <h3 className="text-xl sm:text-2xl md:text-3xl font-black text-white uppercase tracking-tight">
                            Colar exportação de dados totem cronos tma
                        </h3>
                        <p className="text-slate-400 text-xs mt-1.5 uppercase font-mono tracking-wider">
                            Insira as planilhas extraídas do Totem ou do sistema BI para processamento e geração de indicadores de TMA
                        </p>
                        <div className="flex flex-col sm:flex-row gap-3 mt-5">
                            <button 
                                onClick={() => setInputMode('full')}
                                className={`px-5 py-3 sm:py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${inputMode === 'full' ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/10' : 'bg-white/[0.02] border border-white/[0.06] text-slate-400 hover:text-white hover:bg-white/[0.04]'}`}
                            >
                                Totem + BI (Completo)
                            </button>
                            <button 
                                onClick={() => setInputMode('bi_only')}
                                className={`px-5 py-3 sm:py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all duration-300 ${inputMode === 'bi_only' ? 'bg-emerald-500 text-black shadow-lg shadow-emerald-500/10' : 'bg-white/[0.02] border border-white/[0.06] text-slate-400 hover:text-white hover:bg-white/[0.04]'}`}
                            >
                                BI Only (TMFE/TMPC)
                            </button>
                        </div>
                    </div>
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8 relative z-10">
                    {inputMode === 'full' ? (
                        <>
                            <div className="space-y-4 group">
                                <label className="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                                    <span className="flex h-2 w-2 relative">
                                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                        <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                                    </span>
                                    Dados Totem (Interno)
                                </label>
                                <div className="relative">
                                    <textarea
                                        value={rawText}
                                        onChange={(e) => setRawText(e.target.value)}
                                        placeholder="Abra a planilha extraída do Totem, copie todas as colunas (Ctrl+A / Ctrl+C) e cole aqui..."
                                        className="w-full h-80 p-6 bg-black/40 text-emerald-300 font-mono text-xs border border-white/[0.08] rounded-2xl focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 focus:bg-black/60 outline-none transition-all duration-300 custom-scrollbar resize-none placeholder-slate-600"
                                    />
                                    <div className="absolute bottom-4 right-4 pointer-events-none text-[9px] font-mono font-black text-slate-600 uppercase tracking-wider bg-white/[0.01] border border-white/[0.02] px-2.5 py-1 rounded-md">
                                        Format: Planilha Totem
                                    </div>
                                </div>
                            </div>
                            <div className="space-y-4 group">
                                <label className="text-xs font-black text-blue-400 uppercase tracking-widest flex items-center gap-2">
                                    <span className="flex h-2 w-2 relative">
                                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-blue-400 opacity-75"></span>
                                        <span className="relative inline-flex rounded-full h-2 w-2 bg-blue-500"></span>
                                    </span>
                                    Dados BI (Externo)
                                </label>
                                <div className="relative">
                                    <textarea
                                        value={biRawText}
                                        onChange={(e) => setBiRawText(e.target.value)}
                                        placeholder="Abra o relatório extraído do BI (GPS, Paradas, Status), copie todas as colunas e cole aqui..."
                                        className="w-full h-80 p-6 bg-black/40 text-blue-300 font-mono text-xs border border-white/[0.08] rounded-2xl focus:border-blue-500 focus:ring-4 focus:ring-blue-500/10 focus:bg-black/60 outline-none transition-all duration-300 custom-scrollbar resize-none placeholder-slate-600"
                                    />
                                    <div className="absolute bottom-4 right-4 pointer-events-none text-[9px] font-mono font-black text-slate-600 uppercase tracking-wider bg-white/[0.01] border border-white/[0.02] px-2.5 py-1 rounded-md">
                                        Format: Planilha BI
                                    </div>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="col-span-2 space-y-4">
                            <label className="text-xs font-black text-emerald-400 uppercase tracking-widest flex items-center gap-2">
                                <span className="flex h-2 w-2 relative">
                                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                                    <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
                                </span>
                                Dados BI para Análise TMFE / TMPC
                            </label>
                            <div className="relative">
                                <textarea
                                    value={biRawText}
                                    onChange={(e) => setBiRawText(e.target.value)}
                                    placeholder="Cole aqui os dados de auditoria externa do BI. O sistema identificará automaticamente as placas e calculará os tempos externos estruturais..."
                                    className="w-full h-96 p-8 bg-black/40 text-emerald-300 font-mono text-sm border border-white/[0.08] rounded-[2rem] focus:border-emerald-500 focus:ring-4 focus:ring-emerald-500/10 focus:bg-black/60 outline-none transition-all duration-300 custom-scrollbar resize-none placeholder-slate-600"
                                />
                                <div className="absolute bottom-6 right-6 pointer-events-none text-[9px] font-mono font-black text-slate-600 uppercase tracking-wider bg-white/[0.01] border border-white/[0.02] px-3 py-1.5 rounded-lg">
                                    Format: BI Telemetria GPS
                                </div>
                            </div>
                            <div className="bg-[#0b0e14] p-6 rounded-2xl border border-white/[0.04]">
                                <h4 className="text-[10px] font-mono font-black text-slate-500 uppercase tracking-widest mb-2 flex items-center gap-2">
                                    <span className="h-1.5 w-1.5 bg-emerald-500 rounded-full" /> Dica de Importação
                                </h4>
                                <p className="text-xs text-slate-400 leading-relaxed">
                                    Ao colar apenas dados do BI, o sistema focará na análise de <span className="text-emerald-400 font-bold">TMFE (Fila Externa)</span> e <span className="text-emerald-400 font-bold">TMPC (Pós-Carga)</span>. 
                                    Certifique-se de que as colunas de <span className="font-mono text-white bg-white/5 px-1 py-0.5 rounded">Placa</span>, <span className="font-mono text-white bg-white/5 px-1 py-0.5 rounded">Início Parada</span> e <span className="font-mono text-white bg-white/5 px-1 py-0.5 rounded">Duração</span> estejam presentes.
                                </p>
                            </div>
                        </div>
                    )}
                </div>

                {error && (
                    <div className="p-4 bg-red-900/10 border border-red-500/30 rounded-xl flex items-center gap-3 text-red-400 text-sm font-bold mb-8 animate-pulse relative z-10">
                        <AlertTriangleIcon className="w-5 h-5 flex-shrink-0" />
                        <span>{error}</span>
                    </div>
                )}
                
                <div className="flex justify-center sm:justify-end items-center gap-4 relative z-10 border-t border-white/[0.04] pt-8 mt-4 w-full">
                    <button 
                        onClick={handleProcess} 
                        className="w-full sm:w-auto px-6 sm:px-12 py-4 bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-black rounded-xl shadow-lg shadow-emerald-500/10 transition-all duration-300 flex items-center justify-center gap-3 transform active:scale-95 text-sm sm:text-base uppercase tracking-widest"
                    >
                        <span>PROCESSAR DADOS</span>
                        <ActivityIcon className="w-5 h-5 shrink-0" />
                    </button>
                </div>
            </div>

            {renderSavedImportsSection()}
        </div>
    );
    
    const indicatorOptions = {
        tmfe_calculado: { label: 'TMFE (BI)', target: 1800, color: 'text-cyan-400' },
        tmfi: { label: 'TMFI', target: tmaConfig.tmfiTarget, color: 'text-blue-400' },
        tmc: { label: 'TMC', target: tmaConfig.tmcTarget, color: 'text-green-400' },
        tms: { label: 'TMS', target: tmaConfig.tmsTarget, color: 'text-yellow-400' },
        tmpc_calculado: { label: 'TMPC (BI)', target: 3600, color: 'text-orange-400' },
        total: { label: 'TMA Total', target: tmaConfig.totalTarget, color: 'text-white' },
    };

    const CustomTooltip = ({ active, payload, label }: any) => {
        if (active && payload && payload.length) {
            const data = payload[0].payload;
            return (
                <div className="bg-gray-900/80 backdrop-blur-sm border border-gray-700 rounded-lg p-4 shadow-lg text-sm">
                    <p className="font-bold text-white mb-2">{`Hora: ${label}`}</p>
                    <div className="space-y-1">
                        {data.tmfe_calculado > 0 && <p className="text-cyan-400">TMFE Médio: <span className="font-mono font-bold">{secondsToTimeStr(data.tmfe_calculado)}</span></p>}
                        <p className="text-blue-400">TMFI Médio: <span className="font-mono font-bold">{secondsToTimeStr(data.tmfi)}</span></p>
                        <p className="text-green-400">TMC Médio: <span className="font-mono font-bold">{secondsToTimeStr(data.tmc)}</span></p>
                        <p className="text-yellow-400">TMS Médio: <span className="font-mono font-bold">{secondsToTimeStr(data.tms)}</span></p>
                        {data.tmpc_calculado > 0 && <p className="text-orange-400">TMPC Médio: <span className="font-mono font-bold">{secondsToTimeStr(data.tmpc_calculado)}</span></p>}
                        <p className="text-white border-t border-gray-600 pt-1 mt-1">Total Médio: <span className="font-mono font-bold text-lg">{secondsToTimeStr(data.total)}</span></p>
                    </div>
                </div>
            );
        }
        return null;
    };

    const handleConnectPBI = () => {
        setAuthInProgress(true);
        const width = 1000;
        const height = 800;
        const left = (window.innerWidth - width) / 2;
        const top = (window.innerHeight - height) / 2;
        const win = window.open(
            "https://app.powerbi.com/?noSignUpCheck=1", 
            "Microsoft Power BI Authentication", 
            `width=${width},height=${height},top=${top},left=${left},resizable=yes,scrollbars=yes`
        );

        const checkClosed = setInterval(() => {
            if (!win || win.closed) {
                clearInterval(checkClosed);
                setAuthInProgress(false);
                setPbiAuthenticated(true);
                localStorage.setItem('pbi_authenticated', 'true');
            }
        }, 1000);
    };

    const handleDisconnectPBI = () => {
        setPbiAuthenticated(false);
        setAuthInProgress(false);
        localStorage.removeItem('pbi_authenticated');
    };

    const renderPowerBI = () => {
        if (!pbiAuthenticated) {
            return (
                <div className="w-full h-full bg-[#04060a] relative flex flex-col items-center justify-center p-8 overflow-y-auto" style={{ minHeight: 'calc(100vh - 4rem)' }}>
                    {/* Glowing background highlights */}
                    <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-yellow-500/5 rounded-full blur-[120px] pointer-events-none" />
                    <div className="absolute bottom-1/4 left-1/3 w-80 h-80 bg-amber-500/5 rounded-full blur-[100px] pointer-events-none" />

                    <div className="w-full max-w-2xl bg-[#080b11] border border-white/[0.06] rounded-[2.5rem] p-8 md:p-12 shadow-2xl relative z-10 text-center space-y-8 animate-fade-in">
                        {/* Header Branding */}
                        <div className="space-y-3">
                            <div className="inline-flex items-center gap-2 px-3 py-1 bg-yellow-500/10 border border-yellow-500/20 rounded-full">
                                <span className="w-1.5 h-1.5 rounded-full bg-yellow-500 animate-pulse" />
                                <span className="text-[10px] font-black font-mono text-yellow-500 uppercase tracking-widest">Sincronização Corporativa</span>
                            </div>
                            <h2 className="text-2xl md:text-3xl font-black text-white uppercase tracking-tight">
                                Portal de Autenticação Microsoft Power BI
                            </h2>
                            <p className="text-slate-400 text-xs max-w-lg mx-auto leading-relaxed">
                                Para visualizar o painel interativo de TMA com segurança, estabeleça uma conexão autenticada com sua conta corporativa da Microsoft.
                            </p>
                        </div>

                        {/* Middle Illustration & Status */}
                        <div className="p-8 bg-white/[0.01] border border-white/[0.03] rounded-3xl relative overflow-hidden flex flex-col items-center justify-center gap-4">
                            {authInProgress ? (
                                <>
                                    <div className="w-16 h-16 rounded-full bg-yellow-500/10 border border-yellow-500/20 flex items-center justify-center animate-spin">
                                        <RefreshCw className="w-6 h-6 text-yellow-500" />
                                    </div>
                                    <div className="space-y-1">
                                        <h4 className="text-sm font-bold text-white uppercase tracking-wider">Aguardando login externo...</h4>
                                        <p className="text-slate-400 text-[11px] max-w-sm leading-relaxed">
                                            Faça o login com as credenciais da sua conta na janela que se abriu. Ao concluir, você será redirecionado automaticamente.
                                        </p>
                                    </div>
                                </>
                            ) : (
                                <>
                                    <div className="w-16 h-16 rounded-full bg-white/[0.02] border border-white/[0.06] flex items-center justify-center relative">
                                        <Shield className="w-7 h-7 text-slate-300" />
                                        <div className="absolute -bottom-1 -right-1 w-6 h-6 rounded-full bg-yellow-500 flex items-center justify-center text-xs shadow-lg shadow-yellow-500/30">
                                            🔑
                                        </div>
                                    </div>
                                    <div className="space-y-1">
                                        <h4 className="text-sm font-bold text-slate-200 uppercase tracking-wider">Status: Conectividade Pendente</h4>
                                        <p className="text-slate-500 text-[11px] max-w-sm leading-relaxed">
                                            Seus dados estão protegidos pelas diretivas de segurança corporativa da Microsoft.
                                        </p>
                                    </div>
                                </>
                            )}
                        </div>

                        {/* Interactive Steps or Actions */}
                        <div className="space-y-4">
                            {authInProgress ? (
                                <div className="space-y-3">
                                    <button 
                                        onClick={() => {
                                            setPbiAuthenticated(true);
                                            setAuthInProgress(false);
                                            localStorage.setItem('pbi_authenticated', 'true');
                                        }}
                                        className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black text-xs uppercase tracking-wider rounded-2xl transition-all shadow-lg shadow-amber-500/15 active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 mx-auto"
                                    >
                                        <Check className="w-4 h-4" />
                                        Já fiz login! Acessar Painel
                                    </button>
                                    <p className="text-[10px] text-slate-400 uppercase tracking-wider font-mono">
                                        Se a página não atualizar após o login, clique no botão acima para forçar.
                                    </p>
                                </div>
                            ) : (
                                <div className="space-y-4">
                                    <button 
                                        onClick={handleConnectPBI}
                                        className="w-full sm:w-auto px-8 py-4 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-black font-black text-xs uppercase tracking-wider rounded-2xl transition-all shadow-lg shadow-yellow-500/10 hover:shadow-yellow-500/20 active:scale-[0.98] cursor-pointer flex items-center justify-center gap-2 mx-auto"
                                    >
                                        <Lock className="w-4 h-4" />
                                        Conectar Conta Microsoft
                                    </button>
                                    <p className="text-[10px] text-slate-500 max-w-xs mx-auto leading-relaxed">
                                        O portal abrirá uma janela externa oficial e segura diretamente no domínio da Microsoft.
                                    </p>
                                </div>
                            )}
                        </div>
                    </div>
                </div>
            );
        }

        return (
            <div className="w-full h-full bg-[#04060a] relative flex flex-col overflow-hidden" style={{ height: 'calc(100vh - 4rem)' }}>
                {/* Barra de Aviso Superior de Conexão Ativa */}
                <div className="h-12 bg-[#080b11] border-b border-white/[0.06] px-6 flex items-center justify-between z-20 flex-shrink-0">
                    <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                        <span className="text-[10px] font-mono font-black text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                            Sessão Integrada Ativa
                        </span>
                    </div>
                    <div className="flex items-center gap-3">
                        <span className="text-[10px] text-slate-400 font-bold uppercase tracking-tight hidden sm:inline-flex items-center gap-1.5">
                            <span className="text-emerald-500">✓</span> Conexão segura estabelecida
                        </span>
                        
                        <button 
                            onClick={() => {
                                const iframe = document.getElementById('powerbi-iframe') as HTMLIFrameElement;
                                if (iframe) iframe.src = iframe.src;
                            }}
                            className="text-[9px] font-black bg-white/[0.02] hover:bg-white/[0.06] border border-white/[0.08] text-slate-200 px-3 py-1.5 rounded-lg uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                            <RefreshCw className="w-3 h-3" />
                            Atualizar
                        </button>

                        <button 
                            onClick={handleDisconnectPBI}
                            className="text-[9px] font-black bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 px-3 py-1.5 rounded-lg uppercase tracking-wider transition-all flex items-center gap-1.5 cursor-pointer"
                        >
                            <LogOutIcon className="w-3 h-3" />
                            Alterar Conta
                        </button>
                    </div>
                </div>

                {/* Container do Iframe ocupando o restante da tela sem margens e sem paddings */}
                <div className="flex-grow w-full h-full relative bg-[#04060a]">
                    <iframe
                        id="powerbi-iframe"
                        src="https://app.powerbi.com/reportEmbed?reportId=42017170-440c-4e9a-965d-a99d1c18ad99"
                        width="100%"
                        height="100%"
                        style={{ border: 'none' }}
                        allowFullScreen
                        className="absolute inset-0 w-full h-full"
                    >
                    </iframe>
                </div>
            </div>
        );
    };

    const renderAnalysis = () => {
        return (
            <div className="space-y-12 animate-fade-in w-full pb-10 max-w-[1700px] mx-auto">
                <div className="flex items-center gap-6 bg-[#0a0d14]/90 backdrop-blur-xl border border-white/[0.08] p-8 rounded-3xl shadow-[0_15px_40px_-10px_rgba(0,0,0,0.6)] relative overflow-hidden">
                    <button onClick={() => setView('dashboard')} className="p-3 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] rounded-xl transition-all text-gray-300 group">
                        <ChevronLeftIcon className="w-6 h-6 group-hover:-translate-x-1 transition-transform" />
                    </button>
                    <h2 className="text-2xl font-black text-white uppercase tracking-tighter">Análise de Indicadores TMA</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <div className="bg-[#0c0f16]/95 backdrop-blur-md p-8 rounded-3xl border border-white/[0.06] shadow-[0_12px_36px_rgba(0,0,0,0.4)] relative overflow-hidden hover:border-blue-500/20 transition-all duration-300">
                        <div className="absolute top-0 left-0 w-24 h-24 bg-blue-500/[0.02] rounded-full blur-2xl pointer-events-none" />
                        <div className="flex items-center gap-4 mb-6">
                            <div className="p-3 bg-blue-600/10 border border-blue-500/20 rounded-xl">
                                <ActivityIcon className="w-6 h-6 text-blue-400 animate-pulse" />
                            </div>
                            <h3 className="text-sm font-black text-white uppercase tracking-widest">Gargalo de Fila</h3>
                        </div>
                        <p className="text-xs text-gray-400 leading-relaxed font-semibold">
                            O maior tempo de espera está concentrado no <span className="text-blue-400 font-bold">TMFI (Fila Interna)</span>, 
                            representando {summaryData.avgTotal > 0 ? ((summaryData.avgTmfi / summaryData.avgTotal) * 100).toFixed(1) : 0}% do processo total. 
                            Recomenda-se revisar o fluxo de triagem no totem.
                        </p>
                    </div>

                    <div className="bg-[#0c0f16]/95 backdrop-blur-md p-8 rounded-3xl border border-white/[0.06] shadow-[0_12px_36px_rgba(0,0,0,0.4)] relative overflow-hidden hover:border-emerald-500/20 transition-all duration-300">
                        <div className="absolute top-0 left-0 w-24 h-24 bg-emerald-500/[0.02] rounded-full blur-2xl pointer-events-none" />
                        <div className="flex items-center gap-4 mb-6">
                            <div className="p-3 bg-emerald-600/10 border border-emerald-500/20 rounded-xl">
                                <TrendingUpIcon className="w-6 h-6 text-emerald-400" />
                            </div>
                            <h3 className="text-sm font-black text-white uppercase tracking-widest">Eficiência de Carga</h3>
                        </div>
                        <p className="text-xs text-gray-400 leading-relaxed font-semibold">
                            O tempo médio de doca (TMC) está em <span className="text-emerald-400 font-bold">{secondsToTimeStr(summaryData.avgTmc)}</span>.
                            {summaryData.avgTmc < tmaConfig.tmcTarget 
                                ? " O desempenho está excelente, abaixo da meta estabelecida." 
                                : " O desempenho está acima da meta, indicando necessidade de otimização no carregamento."}
                        </p>
                    </div>

                    <div className="bg-[#0c0f16]/95 backdrop-blur-md p-8 rounded-3xl border border-white/[0.06] shadow-[0_12px_36px_rgba(0,0,0,0.4)] relative overflow-hidden hover:border-yellow-500/20 transition-all duration-300">
                        <div className="absolute top-0 left-0 w-24 h-24 bg-yellow-500/[0.02] rounded-full blur-2xl pointer-events-none" />
                        <div className="flex items-center gap-4 mb-6">
                            <div className="p-3 bg-yellow-600/10 border border-yellow-500/20 rounded-xl">
                                <ShieldCheckIcon className="w-6 h-6 text-yellow-400" />
                            </div>
                            <h3 className="text-sm font-black text-white uppercase tracking-widest">Recomendação</h3>
                        </div>
                        <p className="text-xs text-gray-400 leading-relaxed font-semibold">
                            Priorizar a liberação de veículos com <span className="text-yellow-400 font-bold">TMS</span> elevado. 
                            A redução do tempo de saída impacta diretamente na diluição do TMA total do turno.
                        </p>
                    </div>
                </div>

                <div className="bg-[#0c0f16]/95 backdrop-blur-md p-8 rounded-3xl border border-white/[0.06] shadow-[0_12px_36px_rgba(0,0,0,0.4)] relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/[0.01] rounded-full blur-3xl pointer-events-none" />
                    <h3 className="text-sm font-black text-white uppercase tracking-widest mb-8">Distribuição de Tempo por Etapa</h3>
                    <div className="space-y-6">
                        {[
                            { label: 'Fila Interna (TMFI)', value: summaryData.avgTmfi, color: 'bg-blue-500' },
                            { label: 'Carregamento (TMC)', value: summaryData.avgTmc, color: 'bg-green-500' },
                            { label: 'Saída (TMS)', value: summaryData.avgTms, color: 'bg-yellow-500' }
                        ].map((item, i) => {
                            const percentage = summaryData.avgTotal > 0 ? (item.value / summaryData.avgTotal) * 100 : 0;
                            return (
                                <div key={i} className="space-y-2">
                                    <div className="flex justify-between text-[10px] font-black uppercase tracking-widest">
                                        <span className="text-gray-400">{item.label}</span>
                                        <span className="text-white font-mono">{percentage.toFixed(1)}% ({secondsToTimeStr(item.value)})</span>
                                    </div>
                                    <div className="h-2 bg-black/40 rounded-full overflow-hidden border border-white/[0.04]">
                                        <div 
                                            className={`h-full ${item.color} transition-all duration-1000`} 
                                            style={{ width: `${percentage}%` }}
                                        ></div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </div>
            </div>
        );
    };

    const renderDashboard = () => {
        if (entries.length === 0) {
            return (
                <div className="space-y-12 animate-fade-in w-full pb-10 max-w-6xl mx-auto mt-6">
                    <div className="flex flex-col items-center justify-center py-16 bg-[#0c0f16]/90 backdrop-blur-md p-10 rounded-3xl border border-white/[0.06] shadow-[0_20px_50px_rgba(0,0,0,0.6)] text-center space-y-6">
                        <div className="p-5 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl shadow-lg shadow-blue-500/10 text-white">
                            <ActivityIcon className="w-12 h-12" />
                        </div>
                        <div>
                            <h3 className="text-xl font-bold text-white uppercase tracking-tight">Nenhum dado de TMA carregado</h3>
                            <p className="text-slate-400 text-sm mt-3 max-w-md mx-auto leading-relaxed">
                                Atualmente não há nenhuma planilha de TMA processada e ativa no sistema. Vá para a <strong className="text-emerald-400 font-black">Aba de Importação</strong> para colar novos dados ou selecione um registro do histórico na nuvem abaixo para carregar.
                            </p>
                        </div>
                        <button
                            onClick={() => setView('input')}
                            className="px-8 py-3.5 bg-emerald-500 hover:bg-emerald-400 text-black font-mono font-black rounded-xl shadow-lg shadow-emerald-500/10 transition-all duration-300 uppercase tracking-wider text-xs cursor-pointer"
                        >
                            Ir para Importação
                        </button>
                    </div>
                    
                    {renderSavedImportsSection()}
                </div>
            );
        }

        return (
            <div className="space-y-6 animate-fade-in w-full pb-10 max-w-[1700px] mx-auto">
                {/* CABEÇALHO COM RELÓGIO */}
                <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 bg-[#0a0d14]/90 backdrop-blur-xl border border-white/[0.08] p-5 sm:p-8 rounded-[2rem] lg:rounded-3xl shadow-[0_15px_40px_-10px_rgba(0,0,0,0.6)] relative overflow-hidden">
                    <div className="flex items-center gap-4 sm:gap-6 w-full lg:w-auto">
                        <button onClick={() => setView('input')} className="p-2.5 sm:p-3 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] rounded-xl transition-all text-gray-300 group shrink-0"><ChevronLeftIcon className="w-5 h-5 sm:w-6 sm:h-6 group-hover:-translate-x-1 transition-transform" /></button>
                        <div className="min-w-0 flex-1">
                            <div className="flex flex-wrap gap-2 sm:gap-3">

                                <span className="text-[10px] font-black bg-[#111625] text-gray-400 px-3 py-0.5 rounded border border-white/[0.06] uppercase tracking-widest">{filteredEntries.length} VEÍCULOS NO MAPA</span>
                                <button
                                    onClick={() => {
                                        setNewImportTitle(`Importação TMA - ${reportDate} ${new Date().toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}`);
                                        setShowSaveModal(true);
                                    }}
                                    className="text-[10px] font-black bg-emerald-600 hover:bg-emerald-500 text-white px-3 py-0.5 rounded border border-emerald-500 uppercase tracking-widest transition-all flex items-center gap-1.5 shadow-md shadow-emerald-950/40 cursor-pointer"
                                    title="Salvar esta importação na Nuvem (Firebase / Supabase)"
                                >
                                    <FileClockIcon className="w-3 h-3" /> Salvar Importação
                                </button>
                                {autoSaveStatus === 'saving' && (
                                    <span className="text-[10px] font-black bg-blue-500/15 text-blue-400 border border-blue-500/30 px-3 py-0.5 rounded uppercase tracking-widest flex items-center gap-1.5 animate-pulse">
                                        <span className="w-1.5 h-1.5 bg-blue-400 rounded-full animate-ping"></span>
                                        Salvando na Nuvem...
                                    </span>
                                )}
                                {autoSaveStatus === 'success' && (
                                    <span className="text-[10px] font-black bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-3 py-0.5 rounded uppercase tracking-widest flex items-center gap-1.5">
                                        ✓ Salvo Automatically
                                    </span>
                                )}
                                {autoSaveStatus === 'error' && (
                                    <span className="text-[10px] font-black bg-rose-500/15 text-rose-400 border border-rose-500/30 px-3 py-0.5 rounded uppercase tracking-widest flex items-center gap-1.5">
                                        ✕ Erro ao Salvar
                                    </span>
                                )}
                            </div>
                        </div>
                    </div>

                    {/* TABS */}
                    <div className="flex flex-row overflow-x-auto max-w-full custom-scrollbar gap-2 p-1.5 bg-black/40 rounded-full border border-white/[0.06] w-full sm:w-auto shrink-0 whitespace-nowrap">
                        <button
                            onClick={() => setActiveTab('analytics')}
                            className={`px-4 sm:px-6 py-2 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider sm:tracking-widest transition-all ${activeTab === 'analytics' ? 'bg-emerald-500 text-gray-955 font-bold animate-fade-in' : 'text-slate-400 hover:text-white'}`}
                        >
                            TMA Total
                        </button>
                        <button
                            onClick={() => setActiveTab('tmfe_tmpc')}
                            className={`px-4 sm:px-6 py-2 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider sm:tracking-widest transition-all ${activeTab === 'tmfe_tmpc' ? 'bg-emerald-500 text-gray-955 font-bold animate-fade-in' : 'text-slate-400 hover:text-white'}`}
                        >
                            Monitoramento BI
                        </button>
                        <button
                            onClick={() => setActiveTab('operacional')}
                            className={`px-4 sm:px-6 py-2 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider sm:tracking-widest transition-all ${activeTab === 'operacional' ? 'bg-emerald-500 text-gray-955 font-bold animate-fade-in' : 'text-slate-400 hover:text-white'}`}
                        >
                            📊 Análise Operacional
                        </button>
                        <button
                            onClick={() => setActiveTab('auditoria')}
                            className={`px-4 sm:px-6 py-2 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-wider sm:tracking-widest transition-all ${activeTab === 'auditoria' ? 'bg-emerald-500 text-gray-955 font-bold animate-fade-in' : 'text-slate-400 hover:text-white'}`}
                        >
                            🔍 Auditoria & Qualidade
                        </button>
                    </div>

                    <div className="flex items-center gap-6">
                        <RealTimeClock />
                    </div>
                </div>

                {activeTab === 'auditoria' ? (
                    <AuditoriaQualidadeTab
                        entries={entries}
                        tmaConfig={tmaConfig}
                        reportDate={reportDate}
                    />
                ) : activeTab === 'operacional' ? (
                    <ResumoOperacionalTab 
                        entries={entries}
                        tmaConfig={tmaConfig}
                        reportDate={reportDate}
                    />
                ) : activeTab === 'analytics' ? (
                    <div className="space-y-6">
                        {/* BARRA DE FILTROS */}
                        <div className="bg-[#0a0d14]/90 backdrop-blur-xl border border-white/[0.08] p-6 rounded-3xl shadow-[0_15px_40px_-10px_rgba(0,0,0,0.6)] relative overflow-hidden no-print">
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-8 gap-4">
                                <div className="relative xl:col-span-1">
                                    <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                                    <input type="text" value={filterPlaca} onChange={(e) => setFilterPlaca(e.target.value)} placeholder="Busca Placa..." className="w-full pl-11 pr-4 py-3.5 bg-black/40 border border-white/[0.08] rounded-2xl text-sm font-bold text-white focus:border-blue-500 outline-none" />
                                </div>
                                
                                <div className="relative xl:col-span-1">
                                    <FilterIcon className="absolute left-4 top-1/2 -translate-y-1/2 h-4 w-4 text-emerald-500" />
                                    <select value={timeFilterType} onChange={(e) => setTimeFilterType(e.target.value as any)} className="w-full pl-11 pr-4 py-3.5 bg-black/40 border border-white/[0.08] rounded-2xl text-[10px] font-black text-emerald-400 uppercase outline-none cursor-pointer">
                                        <option value="NONE" className="bg-[#0a0d14]">TODOS OS TEMPOS</option>
                                        <option value="TMFI" className="bg-[#0a0d14]">OFENSORES TMFI</option>
                                        <option value="TMC" className="bg-[#0a0d14]">OFENSORES TMC</option>
                                        <option value="TMS" className="bg-[#0a0d14]">OFENSORES TMS</option>
                                        <option value="TMFE" className="bg-[#0a0d14]">FILA EXTERNA (BI)</option>
                                        <option value="TMPC" className="bg-[#0a0d14]">PÓS-CARGA (BI)</option>
                                    </select>
                                </div>

                                <div className="relative xl:col-span-1">
                                    <ShieldCheckIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-blue-500" />
                                    <select value={filterSource} onChange={(e) => setFilterSource(e.target.value as any)} className="w-full pl-11 pr-4 py-3.5 bg-black/40 border border-white/[0.08] rounded-2xl text-[10px] font-black text-blue-400 uppercase outline-none cursor-pointer">
                                        <option value="TODOS" className="bg-[#0a0d14]">TODOS OS DADOS</option>
                                        <option value="TOTEM" className="bg-[#0a0d14]">SOMENTE TOTEM</option>
                                        <option value="BI" className="bg-[#0a0d14]">SOMENTE BI</option>
                                    </select>
                                </div>

                                <div className="flex gap-2 xl:col-span-1">
                                    <select value={filterTurno} onChange={(e) => setFilterTurno(e.target.value as any)} className="flex-1 min-w-0 px-4 py-3.5 bg-black/40 border border-white/[0.08] rounded-2xl text-[10px] font-black text-blue-400 uppercase outline-none">
                                        <option value="ALL" className="bg-[#0a0d14]">TURNOS</option>
                                        <option value="A" className="bg-[#0a0d14]">TURNO A</option>
                                        <option value="B" className="bg-[#0a0d14]">TURNO B</option>
                                        <option value="C" className="bg-[#0a0d14]">TURNO C</option>
                                    </select>
                                    <select value={filterSpecificDate} onChange={(e) => setFilterSpecificDate(e.target.value)} className="flex-1 min-w-0 px-4 py-3.5 bg-black/40 border border-white/[0.08] rounded-2xl text-[10px] font-black text-blue-400 uppercase outline-none">
                                        <option value="ALL" className="bg-[#0a0d14]">DATAS</option>
                                        {Array.from(new Set(entries.map(e => {
                                            const val = e.horaDoca || e.horaEntrada;
                                            return val ? val.split(' ')[0] : '';
                                        }))).filter(d => d && d !== '-' && d !== '').sort().map(d => <option key={d} value={d} className="bg-[#0a0d14]">{d}</option>)}
                                    </select>
                                </div>

                                <div className="flex gap-2 xl:col-span-1">
                                    <button onClick={() => setLast5HoursOnly(!last5HoursOnly)} className={`flex-1 min-w-0 py-3.5 rounded-2xl text-[9px] font-black transition-all border ${last5HoursOnly ? 'bg-blue-600 border-blue-500 text-white' : 'bg-black/40 border-white/[0.08] text-gray-500'}`}>ÚLTIMAS 5H</button>
                                    <button onClick={() => setOnlyCritical(!onlyCritical)} className={`flex-1 min-w-0 py-3.5 rounded-2xl text-[9px] font-black transition-all border ${onlyCritical ? 'bg-red-600 border-red-500 text-white shadow-lg shadow-red-950/40' : 'bg-black/40 border-white/[0.08] text-gray-500'}`}>OFENSORES</button>
                                </div>

                                <div className="flex gap-2 xl:col-span-1">
                                    <button 
                                        onClick={() => setShowManobra(!showManobra)} 
                                        className={`flex-1 min-w-0 py-3.5 rounded-2xl text-[9px] font-black transition-all border ${showManobra ? 'bg-orange-600 border-orange-500 text-white shadow-lg' : 'bg-black/40 border-white/[0.08] text-gray-500'}`}
                                    >
                                        MANOBRAS
                                    </button>
                                    <button 
                                        onClick={() => setShowOutliers(!showOutliers)} 
                                        className={`flex-1 min-w-0 py-3.5 rounded-2xl text-[9px] font-black transition-all border ${showOutliers ? 'bg-purple-600 border-purple-500 text-white shadow-lg' : 'bg-black/40 border-white/[0.08] text-gray-500'}`}
                                    >
                                        OUTLIERS
                                    </button>
                                </div>

                                <div className="flex gap-2 xl:col-span-1">
                                    <button 
                                        onClick={() => setPurgeIncomplete(!purgeIncomplete)} 
                                        className={`flex-1 min-w-0 py-3.5 rounded-2xl text-[9px] font-black transition-all border ${purgeIncomplete ? 'bg-green-600 border-green-500 text-white shadow-lg' : 'bg-black/40 border-white/[0.08] text-gray-500'}`}
                                    >
                                        EXPURGAR
                                    </button>
                                    <button 
                                        onClick={() => setFadelOnly(!fadelOnly)} 
                                        className={`flex-1 min-w-0 py-3.5 rounded-2xl text-[9px] font-black transition-all border ${fadelOnly ? 'bg-blue-600 border-blue-500 text-white shadow-lg' : 'bg-black/40 border-white/[0.08] text-gray-500'}`}
                                    >
                                        FADEL
                                    </button>
                                </div>

                                <div className="xl:col-span-1">
                                    <button 
                                        onClick={handleExportToCSV}
                                        className="w-full py-3.5 bg-white/[0.04] hover:bg-white/[0.08] border border-white/[0.06] text-white rounded-2xl text-[10px] font-black uppercase transition-all flex items-center justify-center gap-2"
                                    >
                                        <DownloadIcon className="w-3 h-3" /> CSV
                                    </button>
                                </div>
                            </div>
                        </div>

                        {/* INDICADORES RESUMO */}
                        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-3">
                            <div className="bg-[#0c0f16]/90 border-t-2 border-t-cyan-500 border-x border-b border-white/[0.06] p-4 rounded-2xl flex flex-col justify-between hover:border-white/[0.12] transition-all duration-300 relative overflow-hidden group shadow-md">
                                <h4 className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider">TMFE Médio</h4>
                                <div className="flex justify-between items-end mt-2">
                                    <span className="text-xl xl:text-2xl font-black text-white font-mono leading-none">{secondsToTimeStrShort(summaryData.avgTmfe)}</span>
                                    <MapPinIcon className="w-4 h-4 text-cyan-500 flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity" />
                                </div>
                            </div>
                            <div className="bg-[#0c0f16]/90 border-t-2 border-t-blue-500 border-x border-b border-white/[0.06] p-4 rounded-2xl flex flex-col justify-between hover:border-white/[0.12] transition-all duration-300 relative overflow-hidden group shadow-md">
                                <h4 className="text-[11px] font-bold text-blue-400 uppercase tracking-wider">TMFI Médio</h4>
                                <div className="flex justify-between items-end mt-2">
                                    <span className="text-xl xl:text-2xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTmfi)}</span>
                                    <TrendingUpIcon className="w-4 h-4 text-blue-500 flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity" />
                                </div>
                            </div>
                            <div className="bg-[#0c0f16]/90 border-t-2 border-t-green-500 border-x border-b border-white/[0.06] p-4 rounded-2xl flex flex-col justify-between hover:border-white/[0.12] transition-all duration-300 relative overflow-hidden group shadow-md">
                                <h4 className="text-[11px] font-bold text-green-400 uppercase tracking-wider">TMC Médio</h4>
                                <div className="flex justify-between items-end mt-2">
                                    <span className="text-xl xl:text-2xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTmc)}</span>
                                    <TrendingUpIcon className="w-4 h-4 text-green-500 flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity" />
                                </div>
                            </div>
                            <div className="bg-[#0c0f16]/90 border-t-2 border-t-yellow-500 border-x border-b border-white/[0.06] p-4 rounded-2xl flex flex-col justify-between hover:border-white/[0.12] transition-all duration-300 relative overflow-hidden group shadow-md">
                                <h4 className="text-[11px] font-bold text-yellow-400 uppercase tracking-wider">TMS Médio</h4>
                                <div className="flex justify-between items-end mt-2">
                                    <span className="text-xl xl:text-2xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTms)}</span>
                                    <TrendingUpIcon className="w-4 h-4 text-yellow-500 flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity" />
                                </div>
                            </div>
                            <div className="bg-[#0c0f16]/90 border-t-2 border-t-orange-500 border-x border-b border-white/[0.06] p-4 rounded-2xl flex flex-col justify-between hover:border-white/[0.12] transition-all duration-300 relative overflow-hidden group shadow-md">
                                <h4 className="text-[11px] font-bold text-orange-400 uppercase tracking-wider">TMPC Médio</h4>
                                <div className="flex justify-between items-end mt-2">
                                    <span className="text-xl xl:text-2xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTmpc)}</span>
                                    <TruckIcon className="w-4 h-4 text-orange-500 flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity" />
                                </div>
                            </div>
                            <div className="bg-[#0c0f16]/90 border-t-2 border-t-white border-x border-b border-white/[0.06] p-4 rounded-2xl flex flex-col justify-between hover:border-white/[0.12] transition-all duration-300 relative overflow-hidden group shadow-md">
                                <h4 className="text-[11px] font-bold text-white uppercase tracking-wider">TMA Total</h4>
                                <div className="flex justify-between items-end mt-2">
                                    <span className="text-xl xl:text-2xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTmaTotalFadel)}</span>
                                    <ActivityIcon className="w-4 h-4 text-white flex-shrink-0 opacity-60 group-hover:opacity-100 transition-opacity" />
                                </div>
                            </div>
                        </div>

                        {/* INDICADORES RESUMO ADICIONAIS */}
                        <div className="grid grid-cols-2 sm:grid-cols-2 md:grid-cols-4 gap-3">
                            <div className="bg-blue-900/20 p-3 rounded-2xl border border-blue-500/30 flex flex-col justify-between">
                                <h4 className="text-[11px] font-bold text-blue-400 uppercase tracking-wider">No Pátio</h4>
                                <div className="flex justify-between items-end mt-1">
                                    <span className="text-xl xl:text-2xl font-black text-white leading-none">{summaryData.inYardCount}</span>
                                    <BoxesIcon className="w-4 h-4 text-blue-500 flex-shrink-0" />
                                </div>
                            </div>
                            <div className="bg-yellow-900/40 p-3 rounded-2xl border border-yellow-500/50 flex flex-col justify-between">
                                <h4 className="text-[11px] font-bold text-yellow-400 uppercase tracking-wider">TMA Válido (FADEL)</h4>
                                <div className="flex justify-between items-end mt-1">
                                    <span className="text-xl xl:text-2xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgValidTma)}</span>
                                    <div className="flex flex-col items-end">
                                        <span className="text-[10px] font-black text-yellow-500">{summaryData.validTmaCount} VEÍCS</span>
                                        <ShieldCheckIcon className="w-4 h-4 text-yellow-500" />
                                    </div>
                                </div>
                            </div>
                            <div className="bg-red-900/20 p-3 rounded-2xl border border-red-500/30 flex flex-col justify-between">
                                <h4 className="text-[11px] font-bold text-red-400 uppercase tracking-wider">Ofensores</h4>
                                <div className="flex justify-between items-end mt-1">
                                    <span className="text-xl xl:text-2xl font-black text-white leading-none">{summaryData.offenderCount}</span>
                                    <AlertTriangleIcon className="w-4 h-4 text-red-500 flex-shrink-0" />
                                </div>
                            </div>
                            <div className="bg-orange-900/20 p-3 rounded-2xl border border-orange-500/30 flex flex-col justify-between">
                                <h4 className="text-[11px] font-bold text-orange-400 uppercase tracking-wider">Outliers</h4>
                                <div className="flex justify-between items-end mt-1">
                                    <span className="text-xl xl:text-2xl font-black text-white leading-none">{summaryData.outlierCount}</span>
                                    <ClockIcon className="w-4 h-4 text-orange-500 flex-shrink-0" />
                                </div>
                            </div>
                        </div>
                    </div>
                ) : (
                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                            <div className="bg-[#0c0f16]/95 border-t-2 border-t-cyan-500 border-x border-b border-white/[0.08] p-8 rounded-3xl shadow-[0_12px_36px_rgba(0,0,0,0.5)] relative overflow-hidden flex flex-col justify-between group hover:border-white/[0.12] transition-all">
                                <div>
                                    <h4 className="text-xs font-black text-cyan-400 uppercase tracking-widest mb-2">Média TMFE (Fila)</h4>
                                    <p className="text-[10px] text-gray-500 font-bold uppercase mb-4">Tempo médio de espera externa</p>
                                </div>
                                <span className="text-4xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTmfe)}</span>
                            </div>
                            <div className="bg-[#0c0f16]/95 border-t-2 border-t-orange-500 border-x border-b border-white/[0.08] p-8 rounded-3xl shadow-[0_12px_36px_rgba(0,0,0,0.5)] relative overflow-hidden flex flex-col justify-between group hover:border-white/[0.12] transition-all">
                                <div>
                                    <h4 className="text-xs font-black text-orange-400 uppercase tracking-widest mb-2">Média TMPC (Pós-Carga)</h4>
                                    <p className="text-[10px] text-gray-500 font-bold uppercase mb-4">Tempo médio após saída da fábrica</p>
                                </div>
                                <span className="text-4xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTmpc)}</span>
                            </div>
                            <div className="bg-[#0c0f16]/95 border-t-2 border-t-white border-x border-b border-white/[0.08] p-8 rounded-3xl shadow-[0_12px_36px_rgba(0,0,0,0.5)] relative overflow-hidden flex flex-col justify-between group hover:border-white/[0.12] transition-all">
                                <div>
                                    <h4 className="text-xs font-black text-white uppercase tracking-widest mb-2">Média Soma (TMFE + TMPC)</h4>
                                    <p className="text-[10px] text-gray-500 font-bold uppercase mb-4">Tempo total externo unificado</p>
                                </div>
                                <span className="text-4xl font-black text-white font-mono leading-none">{secondsToTimeStr(summaryData.avgTmaTotalFadel)}</span>
                            </div>
                        </div>

                        <div className="bg-[#0c0f16]/95 border border-white/[0.08] rounded-3xl shadow-[0_15px_45px_rgba(0,0,0,0.6)] overflow-hidden">
                            <div className="p-8 bg-black/30 border-b border-white/[0.06]">
                                <h3 className="text-xl font-black text-white uppercase tracking-tighter">Detalhamento de Tempos Externos (BI)</h3>
                                <p className="text-[10px] text-gray-500 font-bold uppercase mt-1">Listagem de veículos com tempos de fila e pós-carga identificados</p>
                            </div>
                            <div className="p-8">
                                <div className="overflow-x-auto custom-scrollbar">
                                    <table className="w-full border-collapse">
                                        <thead>
                                            <tr className="border-b border-white/[0.06]">
                                                <th className="px-4 py-4 text-left text-[10px] font-black text-gray-500 uppercase tracking-widest">Placa</th>
                                                <th className="px-4 py-4 text-left text-[10px] font-black text-gray-500 uppercase tracking-widest">Data</th>
                                                <th className="px-4 py-4 text-left text-[10px] font-black text-gray-500 uppercase tracking-widest">Transportadora</th>
                                                <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMFE (Fila)</th>
                                                <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMPC (Pós)</th>
                                                <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">Soma Total</th>
                                                <th className="px-4 py-4 text-right text-[10px] font-black text-gray-500 uppercase tracking-widest">Status</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-white/[0.04]">
                                            {filteredEntries.filter(e => (e.tmfe_calculado || 0) > 0 || (e.tmpc_calculado || 0) > 0).map((e) => {
                                                const soma = (e.tmfe_calculado || 0) + (e.tmpc_calculado || 0);
                                                return (
                                                    <tr key={e.id} className="hover:bg-white/[0.02] transition-colors group">
                                                        <td className="px-4 py-4 text-sm font-black text-white">{e.placa}</td>
                                                        <td className="px-4 py-4 text-xs font-bold text-gray-400">{e.dt || e.horaEntrada?.split(' ')[0] || '--/--/----'}</td>
                                                        <td className="px-4 py-4 text-[10px] font-black text-gray-500 uppercase">{e.transportadora}</td>
                                                        <td className="px-4 py-4 text-center font-mono text-xs text-cyan-400">{secondsToTimeStr(e.tmfe_calculado || 0)}</td>
                                                        <td className="px-4 py-4 text-center font-mono text-xs text-orange-400">{secondsToTimeStr(e.tmpc_calculado || 0)}</td>
                                                        <td className="px-4 py-4 text-center font-mono text-sm font-black text-white">{secondsToTimeStr(soma)}</td>
                                                        <td className="px-4 py-4 text-right">
                                                            <span className={`px-2 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${e.isOutlier ? 'bg-orange-500/10 text-orange-500' : 'bg-green-500/10 text-green-500'}`}>
                                                                {e.isOutlier ? 'OUTLIER' : 'NORMAL'}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                );
                                            })}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
                <div className="bg-[#0c0f16]/95 border border-white/[0.08] rounded-3xl shadow-[0_15px_45px_rgba(0,0,0,0.6)] overflow-hidden">
                    <div className="p-4 sm:p-8 bg-black/30 border-b border-white/[0.06] flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-6 w-full lg:w-auto">
                            <div>
                                <h4 className="text-sm font-black text-gray-400 uppercase tracking-[0.3em]">CRONOS Intelligence | Rastreamento Unificado</h4>
                                <p className="text-[10px] text-gray-500 font-bold uppercase mt-1">Cruzamento Totem (Interno) x BI (Externo/GPS)</p>
                            </div>
                            <div className="relative w-full sm:w-64">
                                <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-blue-500" />
                                <input 
                                    type="text" 
                                    value={filterPlaca} 
                                    onChange={(e) => setFilterPlaca(e.target.value)} 
                                    placeholder="PESQUISAR PLACA..." 
                                    className="w-full pl-9 pr-4 py-2 bg-black/40 border border-white/[0.08] rounded-xl text-[10px] font-black text-blue-400 uppercase outline-none focus:border-blue-500 transition-all placeholder:text-gray-600"
                                />
                            </div>
                        </div>
                        <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6 w-full lg:w-auto">
                            <div className="flex items-center bg-black/40 p-1 rounded-xl border border-white/[0.08] w-fit">
                                <button 
                                    onClick={() => setDisplayMode('grid')}
                                    className={`p-2 rounded-lg transition-all ${displayMode === 'grid' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
                                    title="Modo Grade"
                                >
                                    <LayoutGridIcon className="w-4 h-4" />
                                </button>
                                <button 
                                    onClick={() => setDisplayMode('list')}
                                    className={`p-2 rounded-lg transition-all ${displayMode === 'list' ? 'bg-blue-600 text-white shadow-lg' : 'text-gray-500 hover:text-gray-300'}`}
                                    title="Modo Lista"
                                >
                                    <ListIcon className="w-4 h-4" />
                                </button>
                            </div>
                            <div className="flex flex-wrap gap-x-4 gap-y-2">
                                <div className="flex items-center gap-2 text-[10px] font-black text-gray-500"><div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse"></div> EM FILA</div>
                                <div className="flex items-center gap-2 text-[10px] font-black text-gray-500"><div className="w-3 h-3 bg-red-500 rounded-full"></div> OFENSOR</div>
                                <div className="flex items-center gap-2 text-[10px] font-black text-gray-500"><div className="w-3 h-3 bg-purple-500 rounded-full"></div> MANOBRA</div>
                                <div className="flex items-center gap-2 text-[10px] font-black text-gray-500"><div className="w-3 h-3 bg-green-500 rounded-full"></div> CARREGADO</div>
                            </div>
                        </div>
                    </div>

                    <div className="p-4 sm:p-8">
                        {displayMode === 'grid' ? (
                            <div className="grid grid-cols-1 xl:grid-cols-2 gap-8 max-h-[1000px] overflow-y-auto custom-scrollbar pr-4 pb-12">
                                {filteredEntries.map((e, idx) => {
                                    const isOfensor = e.total > tmaConfig.totalTarget;
                                    const isOutlier = e.isOutlier;
                                    const isInRadius = e.isInRadius;
                                    const inYard = !e.horaDoca || e.horaDoca === '-';
                                    
                                    // Cores baseadas no status
                                    let cardBorder = 'border-gray-800';
                                    let statusColor = 'text-gray-400';
                                    let statusBg = 'bg-gray-800/50';
                                    let statusLabel = 'AGUARDANDO';

                                    if (isOutlier) {
                                        cardBorder = 'border-orange-500/50';
                                        statusColor = 'text-orange-500';
                                        statusBg = 'bg-orange-500/10';
                                        statusLabel = 'OUTLIER';
                                    } else if (e.flag_manobra) {
                                        cardBorder = 'border-purple-500/50';
                                        statusColor = 'text-purple-500';
                                        statusBg = 'bg-purple-500/10';
                                        statusLabel = 'MANOBRA';
                                    } else if (isOfensor) {
                                        cardBorder = 'border-red-500/50';
                                        statusColor = 'text-red-500';
                                        statusBg = 'bg-red-500/10';
                                        statusLabel = 'OFENSOR';
                                    } else if (inYard) {
                                        cardBorder = 'border-blue-500/50';
                                        statusColor = 'text-blue-500';
                                        statusBg = 'bg-blue-500/10';
                                        statusLabel = 'NO PÁTIO';
                                    } else {
                                        cardBorder = 'border-green-500/50';
                                        statusColor = 'text-green-500';
                                        statusBg = 'bg-green-500/10';
                                        statusLabel = 'CONCLUÍDO';
                                    }

                                    return (
                                        <div key={e.id} className={`bg-gray-800/20 border-2 ${cardBorder} rounded-[2.5rem] p-8 transition-all hover:bg-gray-800/40 group relative overflow-hidden`}>
                                            {/* BACKGROUND DECORATION */}
                                            <div className={`absolute top-0 right-0 w-32 h-32 ${statusBg} blur-[80px] -z-10 opacity-50`}></div>
                                            
                                            <div className="flex flex-col gap-8">
                                                {/* HEADER DO CARD */}
                                                <div className="flex justify-between items-start">
                                                    <div className="flex items-center gap-6">
                                                        <div className="flex flex-col">
                                                            <div className="flex items-center gap-3">
                                                                <span className="text-4xl font-black text-white tracking-tighter leading-none">{e.placa}</span>
                                                                {e.placa2 && <span className="text-sm text-gray-600 font-bold uppercase tracking-widest">/ {e.placa2}</span>}
                                                            </div>
                                                            <div className="flex items-center gap-3 mt-2">
                                                                <span className="text-[10px] font-black text-gray-500 uppercase tracking-[0.2em] truncate max-w-[200px]">{e.transportadora}</span>
                                                                <div className="w-1 h-1 bg-gray-700 rounded-full"></div>
                                                                <span className="text-[10px] font-black text-blue-400 uppercase tracking-widest">DT: {e.dt || "-"}</span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div className="flex flex-col items-end gap-2">
                                                        <div className={`px-4 py-1.5 ${statusBg} ${statusColor} rounded-full text-[10px] font-black uppercase tracking-[0.2em] border border-current/20`}>
                                                            {statusLabel}
                                                        </div>

                                                    </div>
                                                </div>

                                                {/* INDICADORES PRINCIPAIS */}
                                                <div className="flex flex-wrap gap-2 items-stretch">
                                                    {[
                                                        { label: 'TMFE', value: e.tmfe_calculado, color: 'text-cyan-400', bg: 'bg-cyan-400/5', target: tmaConfig.tmfeTarget },
                                                        { label: 'TMFI', value: e.tmfi, color: 'text-blue-400', bg: 'bg-blue-400/5', target: tmaConfig.tmfiTarget },
                                                        { label: 'TMC', value: e.tmc, color: 'text-green-400', bg: 'bg-green-400/5', target: tmaConfig.tmcTarget },
                                                        { label: 'TMS', value: e.tms, color: 'text-yellow-400', bg: 'bg-yellow-400/5', target: tmaConfig.tmsTarget },
                                                        { label: 'TMPC', value: e.tmpc_calculado, color: 'text-orange-400', bg: 'bg-orange-400/5', target: tmaConfig.tmpcTarget }
                                                    ].map((ind, i) => {
                                                        const exceeded = ind.value > 0 && ind.value > ind.target;
                                                        
                                                        // Active/Exceeded styling - outstandingly highlighted as requested
                                                        const borderStyle = exceeded ? 'border-red-500 shadow-[0_0_20px_rgba(239,68,68,0.75)] animate-pulse' : 'border-white/5';
                                                        const paddingStyle = exceeded ? 'p-3 flex-grow-[2.5] scale-110 min-w-[95px] z-10' : 'p-2 flex-grow min-w-[80px]';
                                                        const backgroundStyle = exceeded ? 'bg-gradient-to-br from-red-600 via-red-700 to-red-800' : ind.bg;
                                                        const labelColor = exceeded ? 'text-white/80 font-black' : 'text-gray-500';
                                                        const valueColor = exceeded ? 'text-white text-sm font-black' : (ind.value > 0 ? ind.color : 'text-gray-700');

                                                        return (
                                                            <div 
                                                                key={i} 
                                                                className={`${backgroundStyle} ${paddingStyle} rounded-2xl border ${borderStyle} flex flex-col items-center justify-center gap-1 transition-all duration-300`}
                                                            >
                                                                <span className={`text-[7px] font-black uppercase tracking-widest truncate w-full text-center ${labelColor}`}>{ind.label}</span>
                                                                <span className={`font-mono truncate w-full text-center ${valueColor}`}>
                                                                    {ind.value > 0 ? secondsToTimeStrShort(ind.value) : '--:--'}
                                                                </span>
                                                                {exceeded ? (
                                                                    <span className="text-[7px] text-white/90 bg-black/30 px-1.5 py-0.5 rounded-md font-black uppercase tracking-tighter whitespace-nowrap animate-bounce">
                                                                        +{secondsToTimeStrShort(ind.value - ind.target)}
                                                                    </span>
                                                                ) : (
                                                                    <span className="text-[6px] text-gray-600 font-bold uppercase tracking-wider">
                                                                        Limite: {Math.round(ind.target / 60)}m
                                                                    </span>
                                                                )}
                                                            </div>
                                                        );
                                                    })}
                                                </div>

                                                {/* TIMELINE DE PROCESSO */}
                                                <div className="space-y-4">
                                                    <div className="flex items-center gap-2">
                                                        <div className="w-1.5 h-1.5 bg-blue-500 rounded-full shadow-[0_0_8px_rgba(59,130,246,0.8)]"></div>
                                                        <span className="text-[9px] font-black text-gray-400 uppercase tracking-[0.3em]">Sequência de Eventos Logísticos</span>
                                                    </div>
                                                    
                                                    <div className="relative pt-2 pb-6 px-2 overflow-x-auto custom-scrollbar">
                                                        <div className="min-w-[450px] relative">
                                                            {/* LINHA DE FUNDO - Alinhada com o centro das bolinhas (8px do topo) */}
                                                            <div className="absolute top-2 left-0 w-full h-0.5 bg-gray-800 rounded-full"></div>
                                                            
                                                            <div className="flex justify-between items-start relative z-10">
                                                                {[
                                                                    { label: 'Início Parada', time: e.bi_inicio_parada, color: 'bg-cyan-500', active: !!e.bi_inicio_parada, interval: e.tmfe_calculado, intervalColor: 'text-cyan-400' },
                                                                    { label: 'Entrada Fáb.', time: e.horaEntrada, color: 'bg-blue-500', active: !!e.horaEntrada && e.horaEntrada !== '-', interval: e.tmfi, intervalColor: 'text-blue-400' },
                                                                    { label: 'Entrada Doca', time: e.horaDoca, color: 'bg-green-500', active: !!e.horaDoca && e.horaDoca !== '-', interval: e.tmc, intervalColor: 'text-green-400' },
                                                                    { label: 'Saída Doca', time: e.horaSaidaDoca, color: 'bg-yellow-500', active: !!e.horaSaidaDoca && e.horaSaidaDoca !== '-', interval: e.tms, intervalColor: 'text-yellow-400' },
                                                                    { label: 'Saída Fáb.', time: e.horaSaidaFabrica, color: 'bg-orange-500', active: !!e.horaSaidaFabrica && e.horaSaidaFabrica !== '-', interval: e.tmpc_calculado, intervalColor: 'text-orange-400' },
                                                                    { label: 'Último GPS', time: e.bi_gps_last, color: 'bg-red-500', active: !!e.bi_gps_last }
                                                                ].map((step, i, arr) => (
                                                                    <React.Fragment key={i}>
                                                                        <div className="flex flex-col items-center group/step relative">
                                                                            <div className={`w-4 h-4 rounded-full border-4 border-gray-900 transition-all duration-500 z-20 ${step.active ? `${step.color} scale-125 shadow-[0_0_15px_rgba(255,255,255,0.2)]` : 'bg-gray-700'}`}></div>
                                                                            <div className="flex flex-col items-center mt-3">
                                                                                <span className={`text-[7px] font-black uppercase tracking-tighter mb-1 transition-colors ${step.active ? 'text-white' : 'text-gray-600'}`}>{step.label}</span>
                                                                                <span className={`text-[9px] font-mono font-bold transition-colors ${step.active ? 'text-gray-300' : 'text-gray-700'}`}>{step.time && step.time !== '-' ? step.time.split(' ')[1] || step.time : '--:--'}</span>
                                                                            </div>
                                                                            
                                                                            {/* TOOLTIP DE DATA */}
                                                                            <div className="absolute -top-10 bg-gray-900 text-[8px] text-white px-3 py-1.5 rounded-lg border border-gray-700 opacity-0 group-hover/step:opacity-100 transition-opacity pointer-events-none whitespace-nowrap z-30 shadow-2xl">
                                                                                {step.label}: {step.time || 'N/A'}
                                                                            </div>
                                                                        </div>
                                                                        {i < arr.length - 1 && (
                                                                            <div className="flex-1 h-4 flex items-center justify-center relative">
                                                                                <div className={`flex flex-col items-center justify-center px-2.5 py-1.5 rounded-lg border border-white/10 z-30 shadow-[0_0_20px_rgba(0,0,0,0.5)] backdrop-blur-xl transition-all duration-300 ${step.interval && step.interval > 0 ? 'bg-gray-800/95 scale-110 ring-1 ring-white/5' : 'bg-gray-900/50 opacity-40'}`}>
                                                                                    <span className={`text-[10px] font-black font-mono tracking-wider ${step.intervalColor}`}>
                                                                                        {step.interval && step.interval > 0 ? secondsToTimeStrShort(step.interval) : '--:--'}
                                                                                    </span>
                                                                                </div>
                                                                            </div>
                                                                        )}
                                                                    </React.Fragment>
                                                                ))}
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                                {/* FOOTER DO CARD */}
                                                <div className="flex justify-between items-center pt-6 border-t border-white/5">
                                                    <div className="flex items-center gap-6">
                                                        <div className="flex flex-col">
                                                            <span className="text-[8px] font-black text-gray-600 uppercase tracking-widest">TMA Unificado</span>
                                                            <span className={`text-2xl xl:text-3xl font-black font-mono leading-none ${isOfensor ? 'text-red-500' : 'text-white'}`}>
                                                                {secondsToTimeStrShort(e.tmfe_calculado + e.tmfi + e.tmc + e.tms + e.tmpc_calculado)}
                                                            </span>
                                                        </div>
                                                        {isOfensor && (
                                                            <div className="flex flex-col">
                                                                <span className="text-[8px] font-black text-red-500/50 uppercase tracking-widest">Excesso</span>
                                                                <span className="text-sm font-black text-red-500 font-mono">
                                                                    +{secondsToTimeStrShort(Math.max(0, (e.tmfe_calculado + e.tmfi + e.tmc + e.tms + e.tmpc_calculado) - tmaConfig.totalTarget))}
                                                                </span>
                                                            </div>
                                                        )}
                                                    </div>

                                                    <div className="flex items-center gap-3">
                                                        {isOfensor && (
                                                            <a 
                                                                href="https://splan.ab-inbev.com/login" 
                                                                target="_blank" 
                                                                rel="noreferrer"
                                                                className="flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-500 text-white rounded-2xl text-[10px] font-black uppercase transition-all shadow-xl shadow-red-900/40 transform active:scale-95"
                                                            >
                                                                <ExternalLinkIcon className="w-3.5 h-3.5" /> ABRIR SPLAN
                                                            </a>
                                                        )}
                                                        <div className="flex flex-col items-end">
                                                            <span className="text-[8px] font-black text-gray-600 uppercase tracking-widest">Canal</span>
                                                            <span className="text-[10px] font-black text-blue-400 uppercase">{e.canal || 'N/A'}</span>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    )
                                })}
                            </div>
                        ) : (
                            <div className="overflow-x-auto custom-scrollbar">
                                <table className="w-full border-collapse">
                                    <thead>
                                        <tr className="border-b border-gray-800">
                                            <th className="px-4 py-4 text-left text-[10px] font-black text-gray-500 uppercase tracking-widest">Placa</th>
                                            <th className="px-4 py-4 text-left text-[10px] font-black text-gray-500 uppercase tracking-widest">Status</th>
                                            <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMFE</th>
                                            <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMFI</th>
                                            <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMC</th>
                                            <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMS</th>
                                            <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMPC</th>
                                            <th className="px-4 py-4 text-center text-[10px] font-black text-gray-500 uppercase tracking-widest">TMA Total</th>
                                            <th className="px-4 py-4 text-right text-[10px] font-black text-gray-500 uppercase tracking-widest">Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody className="divide-y divide-gray-800/50">
                                        {filteredEntries.map((e) => {
                                            const isOfensor = e.total > tmaConfig.totalTarget;
                                            const totalTma = (e.tmfe_calculado || 0) + e.tmfi + e.tmc + e.tms + (e.tmpc_calculado || 0);
                                            return (
                                                <tr key={e.id} className="hover:bg-gray-800/30 transition-colors group">
                                                    <td className="px-4 py-4">
                                                        <div className="flex flex-col">
                                                            <span className="text-sm font-black text-white">{e.placa}</span>
                                                            <span className="text-[8px] font-bold text-gray-600 uppercase truncate max-w-[120px]">{e.transportadora}</span>
                                                        </div>
                                                    </td>
                                                    <td className="px-4 py-4">
                                                        <span className={`px-2 py-1 rounded-full text-[8px] font-black uppercase tracking-widest ${
                                                            e.isOutlier ? 'bg-orange-500/10 text-orange-500' :
                                                            e.flag_manobra ? 'bg-purple-500/10 text-purple-500' :
                                                            isOfensor ? 'bg-red-500/10 text-red-500' :
                                                            'bg-green-500/10 text-green-500'
                                                        }`}>
                                                            {e.isOutlier ? 'OUTLIER' : e.flag_manobra ? 'MANOBRA' : isOfensor ? 'OFENSOR' : 'NORMAL'}
                                                        </span>
                                                    </td>
                                                    <td className="px-4 py-4 text-center">
                                                         {(() => {
                                                             const exceeded = e.tmfe_calculado > 0 && e.tmfe_calculado > tmaConfig.tmfeTarget;
                                                             return (
                                                                 <div className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 ${exceeded ? 'bg-gradient-to-br from-red-600 to-red-800 text-white border border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.6)] scale-110' : 'bg-white/[0.01]'}`}>
                                                                     <span className={`font-mono text-sm font-black ${exceeded ? 'text-white' : 'text-cyan-400'}`}>
                                                                         {secondsToTimeStrShort(e.tmfe_calculado)}
                                                                     </span>
                                                                     {exceeded ? (
                                                                         <span className="text-[7px] text-white/90 bg-black/30 px-1.5 py-0.5 rounded font-black uppercase tracking-wider whitespace-nowrap mt-1 animate-pulse">
                                                                             +{secondsToTimeStrShort(e.tmfe_calculado - tmaConfig.tmfeTarget)}
                                                                         </span>
                                                                     ) : (
                                                                         <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{e.bi_inicio_parada?.split(' ')[1]?.substring(0, 5) || '--:--'}</span>
                                                                     )}
                                                                 </div>
                                                             );
                                                         })()}
                                                     </td>
                                                     <td className="px-4 py-4 text-center">
                                                         {(() => {
                                                             const exceeded = e.tmfi > 0 && e.tmfi > tmaConfig.tmfiTarget;
                                                             return (
                                                                 <div className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 ${exceeded ? 'bg-gradient-to-br from-red-600 to-red-800 text-white border border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.6)] scale-110' : 'bg-white/[0.01]'}`}>
                                                                     <span className={`font-mono text-sm font-black ${exceeded ? 'text-white' : 'text-blue-400'}`}>
                                                                         {secondsToTimeStrShort(e.tmfi)}
                                                                     </span>
                                                                     {exceeded ? (
                                                                         <span className="text-[7px] text-white/90 bg-black/30 px-1.5 py-0.5 rounded font-black uppercase tracking-wider whitespace-nowrap mt-1 animate-pulse">
                                                                             +{secondsToTimeStrShort(e.tmfi - tmaConfig.tmfiTarget)}
                                                                         </span>
                                                                     ) : (
                                                                         <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{e.horaEntrada?.split(' ')[1]?.substring(0, 5) || '--:--'}</span>
                                                                     )}
                                                                 </div>
                                                             );
                                                         })()}
                                                     </td>
                                                     <td className="px-4 py-4 text-center">
                                                         {(() => {
                                                             const exceeded = e.tmc > 0 && e.tmc > tmaConfig.tmcTarget;
                                                             return (
                                                                 <div className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 ${exceeded ? 'bg-gradient-to-br from-red-600 to-red-800 text-white border border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.6)] scale-110' : 'bg-white/[0.01]'}`}>
                                                                     <span className={`font-mono text-sm font-black ${exceeded ? 'text-white' : 'text-green-400'}`}>
                                                                         {secondsToTimeStrShort(e.tmc)}
                                                                     </span>
                                                                     {exceeded ? (
                                                                         <span className="text-[7px] text-white/90 bg-black/30 px-1.5 py-0.5 rounded font-black uppercase tracking-wider whitespace-nowrap mt-1 animate-pulse">
                                                                             +{secondsToTimeStrShort(e.tmc - tmaConfig.tmcTarget)}
                                                                         </span>
                                                                     ) : (
                                                                         <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{e.horaDoca?.split(' ')[1]?.substring(0, 5) || '--:--'}</span>
                                                                     )}
                                                                 </div>
                                                             );
                                                         })()}
                                                     </td>
                                                     <td className="px-4 py-4 text-center">
                                                         {(() => {
                                                             const exceeded = e.tms > 0 && e.tms > tmaConfig.tmsTarget;
                                                             return (
                                                                 <div className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 ${exceeded ? 'bg-gradient-to-br from-red-600 to-red-800 text-white border border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.6)] scale-110' : 'bg-white/[0.01]'}`}>
                                                                     <span className={`font-mono text-sm font-black ${exceeded ? 'text-white' : 'text-yellow-400'}`}>
                                                                         {secondsToTimeStrShort(e.tms)}
                                                                     </span>
                                                                     {exceeded ? (
                                                                         <span className="text-[7px] text-white/90 bg-black/30 px-1.5 py-0.5 rounded font-black uppercase tracking-wider whitespace-nowrap mt-1 animate-pulse">
                                                                             +{secondsToTimeStrShort(e.tms - tmaConfig.tmsTarget)}
                                                                         </span>
                                                                     ) : (
                                                                         <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{e.horaSaidaDoca?.split(' ')[1]?.substring(0, 5) || '--:--'}</span>
                                                                     )}
                                                                 </div>
                                                             );
                                                         })()}
                                                     </td>
                                                     <td className="px-4 py-4 text-center">
                                                         {(() => {
                                                             const exceeded = e.tmpc_calculado > 0 && e.tmpc_calculado > tmaConfig.tmpcTarget;
                                                             return (
                                                                 <div className={`flex flex-col items-center justify-center p-3 rounded-2xl transition-all duration-300 ${exceeded ? 'bg-gradient-to-br from-red-600 to-red-800 text-white border border-red-400 shadow-[0_0_15px_rgba(239,68,68,0.6)] scale-110' : 'bg-white/[0.01]'}`}>
                                                                     <span className={`font-mono text-sm font-black ${exceeded ? 'text-white' : 'text-orange-400'}`}>
                                                                         {secondsToTimeStrShort(e.tmpc_calculado)}
                                                                     </span>
                                                                     {exceeded ? (
                                                                         <span className="text-[7px] text-white/90 bg-black/30 px-1.5 py-0.5 rounded font-black uppercase tracking-wider whitespace-nowrap mt-1 animate-pulse">
                                                                             +{secondsToTimeStrShort(e.tmpc_calculado - tmaConfig.tmpcTarget)}
                                                                         </span>
                                                                     ) : (
                                                                         <span className="text-[9px] text-slate-500 font-bold uppercase tracking-wider">{e.horaSaidaFabrica?.split(' ')[1]?.substring(0, 5) || '--:--'}</span>
                                                                     )}
                                                                 </div>
                                                             );
                                                         })()}
                                                     </td>
                                                    <td className={`px-4 py-4 text-center font-mono text-sm font-black ${isOfensor ? 'text-red-500' : 'text-white'}`}>
                                                        {secondsToTimeStrShort(totalTma)}
                                                    </td>
                                                    <td className="px-4 py-4 text-right">
                                                        <div className="flex items-center justify-end gap-2">
                                                            {isOfensor && (
                                                                <>
                                                                    <button
                                                                        onClick={() => {
                                                                            setStratPlaca(e.placa);
                                                                            setStratTransportadora(e.transportadora || '');
                                                                            setStratGuia(e.pedido || e.notaFiscal || 'TMA-' + e.placa);
                                                                            setIsStratModalOpen(true);
                                                                        }}
                                                                        className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-yellow-500/10 text-yellow-500 rounded-lg hover:bg-yellow-500 hover:text-black font-black uppercase text-[10px] tracking-wider transition-all cursor-pointer border border-yellow-500/20"
                                                                    >
                                                                        <AlertTriangle className="w-3.5 h-3.5" />
                                                                        <span>Estratificar</span>
                                                                    </button>
                                                                    <a 
                                                                        href="https://splan.ab-inbev.com/login" 
                                                                        target="_blank" 
                                                                        rel="noreferrer"
                                                                        className="inline-flex p-2 bg-red-600/10 text-red-500 rounded-lg hover:bg-red-600 hover:text-white transition-all"
                                                                        title="SPLAN Login"
                                                                    >
                                                                        <ExternalLink className="w-3.5 h-3.5" />
                                                                    </a>
                                                                </>
                                                            )}
                                                        </div>
                                                    </td>
                                                </tr>
                                            );
                                        })}
                                    </tbody>
                                </table>
                            </div>
                        )}
                    </div>
                </div>

                {activeTab !== 'operacional' && (
                    <>
                        {/* GRÁFICO REESTILIZADO COM TENDÊNCIA */}
                        <div className="relative bg-[#0d121f] p-8 rounded-3xl border border-white/[0.06] shadow-[0_4px_32px_rgba(0,0,0,0.5)] overflow-hidden hover:border-emerald-500/10 transition-all duration-300 group">
                    <TruckWatermark />
                    <div className="relative z-10 flex flex-wrap justify-between items-center gap-4 mb-4">
                        <h4 className="text-sm font-black text-white uppercase tracking-[0.2em] flex items-center gap-3">
                            <span className="p-2.5 bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 rounded-xl">
                                <ActivityIcon className="w-5 h-5" />
                            </span>
                            Comportamento Temporal das Cargas (Média por Hora)
                        </h4>
                        <div className="flex items-center gap-1.5 p-1 bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-x-auto max-w-full custom-scrollbar shrink-0 whitespace-nowrap">
                            {Object.entries(indicatorOptions).map(([key, value]) => (
                                <button
                                    key={key}
                                    onClick={() => setChartIndicator(key as any)}
                                    className={`px-3 py-2 text-[10px] font-mono font-black uppercase tracking-wider rounded-lg transition-all duration-200 ${
                                        chartIndicator === key 
                                            ? 'bg-emerald-500 text-black shadow-md shadow-emerald-500/10' 
                                            : 'text-slate-400 hover:text-white hover:bg-white/[0.02]'
                                    }`}
                                >
                                    {value.label}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="relative z-10 flex flex-wrap justify-start sm:justify-end gap-3 sm:gap-6 text-[10px] font-mono font-black text-slate-500 uppercase mb-4 select-none">
                        <button 
                            onClick={() => setShowMainSeries(!showMainSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showMainSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização das cargas"
                        >
                            <span className="w-3 h-3 rounded bg-gradient-to-br from-[#f43f5e] to-[#be123c]" />
                            <span>Ofensor (&gt; Meta)</span>
                        </button>
                        <button 
                            onClick={() => setShowMainSeries(!showMainSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showMainSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização das cargas"
                        >
                            <span className="w-3 h-3 rounded bg-gradient-to-br from-[#10b981] to-[#059669]" />
                            <span>Dentro da Meta</span>
                        </button>
                        <button 
                            onClick={() => setShowTrendSeries(!showTrendSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showTrendSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização da linha de tendência"
                        >
                            <span className="w-4 h-0.5 border-t-2 border-dashed border-blue-500" />
                            <span>Tendência</span>
                        </button>
                    </div>
                    <div className="h-[250px] sm:h-[350px] md:h-[400px] w-full relative z-10">
                        <ResponsiveContainer width="100%" height="100%">
                            <ComposedChart data={chartData} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
                                <defs>
                                    <linearGradient id="gradCompliant1" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#10b981" stopOpacity={0.85} />
                                        <stop offset="100%" stopColor="#059669" stopOpacity={0.35} />
                                    </linearGradient>
                                    <linearGradient id="gradOffender1" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.85} />
                                        <stop offset="100%" stopColor="#be123c" stopOpacity={0.35} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" vertical={false} opacity={0.03} />
                                <XAxis dataKey="hour" stroke="#94a3b8" opacity={0.4} fontSize={9} tickLine={false} axisLine={false} />
                                <YAxis stroke="#94a3b8" opacity={0.4} fontSize={9} tickLine={false} axisLine={false} tickFormatter={(v) => secondsToTimeStr(v)} />
                                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#ffffff05' }}/>
                                <ReferenceLine 
                                    y={indicatorOptions[chartIndicator].target} 
                                    stroke="#f43f5e" 
                                    strokeWidth={1.5} 
                                    strokeDasharray="6 4"
                                    label={{ 
                                        value: `SLA: ${secondsToTimeStr(indicatorOptions[chartIndicator].target)}`, 
                                        fill: '#f43f5e', 
                                        fontSize: 9, 
                                        fontWeight: 'bold', 
                                        position: 'top',
                                        offset: 8
                                    }} 
                                />
                                {showMainSeries && (
                                    <Bar dataKey={chartIndicator} name={indicatorOptions[chartIndicator].label} radius={[4, 4, 0, 0]} barSize={28}>
                                        {chartData.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry[chartIndicator] > indicatorOptions[chartIndicator].target ? 'url(#gradOffender1)' : 'url(#gradCompliant1)'} />
                                        ))}
                                    </Bar>
                                )}
                                {showTrendSeries && (
                                    <Line 
                                        type="monotone" 
                                        dataKey="tendencia" 
                                        stroke="#3b82f6" 
                                        strokeWidth={2} 
                                        dot={false} 
                                        strokeDasharray="4 4"
                                        name="Tendência"
                                    />
                                )}
                            </ComposedChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* GRÁFICO - FROTA FIXA (FADEL) */}
                <div className="relative bg-[#0d121f] p-8 rounded-3xl border border-white/[0.06] shadow-[0_4px_32px_rgba(0,0,0,0.5)] overflow-hidden hover:border-emerald-500/10 transition-all duration-300 group">
                    <TruckWatermark />
                    <div className="relative z-10 flex flex-wrap justify-between items-center gap-4 mb-4">
                        <h4 className="text-sm font-black text-white uppercase tracking-[0.2em] flex items-center gap-3">
                            <span className="p-2.5 bg-blue-500/10 border border-blue-500/20 text-blue-400 rounded-xl">
                                <ActivityIcon className="w-5 h-5" />
                            </span>
                            Frota Fixa (Fadel) - Performance por Hora
                        </h4>
                        <div className="flex items-center gap-1.5 p-1 bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-x-auto max-w-full custom-scrollbar shrink-0 whitespace-nowrap">
                            {Object.entries(indicatorOptions).map(([key, value]) => (
                                <button
                                    key={key}
                                    onClick={() => setChartIndicator(key as any)}
                                    className={`px-3 py-2 text-[10px] font-mono font-black uppercase tracking-wider rounded-lg transition-all duration-200 ${
                                        chartIndicator === key 
                                            ? 'bg-emerald-500 text-black shadow-md shadow-emerald-500/10' 
                                            : 'text-slate-400 hover:text-white hover:bg-white/[0.02]'
                                    }`}
                                >
                                    {value.label}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="relative z-10 flex flex-wrap justify-start sm:justify-end gap-3 sm:gap-6 text-[10px] font-mono font-black text-slate-500 uppercase mb-4 select-none">
                        <button 
                            onClick={() => setShowMainSeries(!showMainSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showMainSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização das cargas"
                        >
                            <span className="w-3 h-3 rounded bg-gradient-to-br from-[#f43f5e] to-[#be123c]" />
                            <span>Ofensor (&gt; Meta)</span>
                        </button>
                        <button 
                            onClick={() => setShowMainSeries(!showMainSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showMainSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização das cargas"
                        >
                            <span className="w-3 h-3 rounded bg-gradient-to-br from-[#10b981] to-[#059669]" />
                            <span>Dentro da Meta</span>
                        </button>
                        <button 
                            onClick={() => setShowTrendSeries(!showTrendSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showTrendSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização da linha de tendência"
                        >
                            <span className="w-4 h-0.5 border-t-2 border-dashed border-blue-500" />
                            <span>Tendência</span>
                        </button>
                    </div>
                    <div className="h-[250px] sm:h-[350px] md:h-[400px] w-full relative z-10">
                        <ResponsiveContainer width="100%" height="100%">
                            <ComposedChart data={chartDataFadel} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
                                <defs>
                                    <linearGradient id="gradCompliant2" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#10b981" stopOpacity={0.85} />
                                        <stop offset="100%" stopColor="#059669" stopOpacity={0.35} />
                                    </linearGradient>
                                    <linearGradient id="gradOffender2" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.85} />
                                        <stop offset="100%" stopColor="#be123c" stopOpacity={0.35} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" vertical={false} opacity={0.03} />
                                <XAxis dataKey="hour" stroke="#94a3b8" opacity={0.4} fontSize={9} tickLine={false} axisLine={false} />
                                <YAxis stroke="#94a3b8" opacity={0.4} fontSize={9} tickLine={false} axisLine={false} tickFormatter={(v) => secondsToTimeStr(v)} />
                                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#ffffff05' }}/>
                                <ReferenceLine 
                                    y={indicatorOptions[chartIndicator].target} 
                                    stroke="#f43f5e" 
                                    strokeWidth={1.5} 
                                    strokeDasharray="6 4"
                                    label={{ 
                                        value: `SLA: ${secondsToTimeStr(indicatorOptions[chartIndicator].target)}`, 
                                        fill: '#f43f5e', 
                                        fontSize: 9, 
                                        fontWeight: 'bold', 
                                        position: 'top',
                                        offset: 8
                                    }} 
                                />
                                {showMainSeries && (
                                    <Bar dataKey={chartIndicator} name={indicatorOptions[chartIndicator].label} radius={[4, 4, 0, 0]} barSize={28}>
                                        {chartDataFadel.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry[chartIndicator] > indicatorOptions[chartIndicator].target ? 'url(#gradOffender2)' : 'url(#gradCompliant2)'} />
                                        ))}
                                    </Bar>
                                )}
                                {showTrendSeries && (
                                    <Line 
                                        type="monotone" 
                                        dataKey="tendencia" 
                                        stroke="#3b82f6" 
                                        strokeWidth={2} 
                                        dot={false} 
                                        strokeDasharray="4 4"
                                        name="Tendência"
                                    />
                                )}
                            </ComposedChart>
                        </ResponsiveContainer>
                    </div>
                </div>

                {/* GRÁFICO - SPOT / OUTRAS */}
                <div className="relative bg-[#0d121f] p-8 rounded-3xl border border-white/[0.06] shadow-[0_4px_32px_rgba(0,0,0,0.5)] overflow-hidden hover:border-emerald-500/10 transition-all duration-300 group">
                    <TruckWatermark />
                    <div className="relative z-10 flex flex-wrap justify-between items-center gap-4 mb-4">
                        <h4 className="text-sm font-black text-white uppercase tracking-[0.2em] flex items-center gap-3">
                            <span className="p-2.5 bg-orange-500/10 border border-orange-500/20 text-orange-400 rounded-xl">
                                <ActivityIcon className="w-5 h-5" />
                            </span>
                            Spot / Outras Transportadoras - Performance por Hora
                        </h4>
                        <div className="flex items-center gap-1.5 p-1 bg-white/[0.02] border border-white/[0.06] rounded-xl overflow-x-auto max-w-full custom-scrollbar shrink-0 whitespace-nowrap">
                            {Object.entries(indicatorOptions).map(([key, value]) => (
                                <button
                                    key={key}
                                    onClick={() => setChartIndicator(key as any)}
                                    className={`px-3 py-2 text-[10px] font-mono font-black uppercase tracking-wider rounded-lg transition-all duration-200 ${
                                        chartIndicator === key 
                                            ? 'bg-emerald-500 text-black shadow-md shadow-emerald-500/10' 
                                            : 'text-slate-400 hover:text-white hover:bg-white/[0.02]'
                                    }`}
                                >
                                    {value.label}
                                </button>
                            ))}
                        </div>
                    </div>
                    <div className="relative z-10 flex flex-wrap justify-start sm:justify-end gap-3 sm:gap-6 text-[10px] font-mono font-black text-slate-500 uppercase mb-4 select-none">
                        <button 
                            onClick={() => setShowMainSeries(!showMainSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showMainSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização das cargas"
                        >
                            <span className="w-3 h-3 rounded bg-gradient-to-br from-[#f43f5e] to-[#be123c]" />
                            <span>Ofensor (&gt; Meta)</span>
                        </button>
                        <button 
                            onClick={() => setShowMainSeries(!showMainSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showMainSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização das cargas"
                        >
                            <span className="w-3 h-3 rounded bg-gradient-to-br from-[#10b981] to-[#059669]" />
                            <span>Dentro da Meta</span>
                        </button>
                        <button 
                            onClick={() => setShowTrendSeries(!showTrendSeries)} 
                            className={`flex items-center gap-2 hover:text-slate-300 transition-all duration-200 cursor-pointer ${!showTrendSeries ? 'opacity-35 line-through decoration-slate-600' : ''}`}
                            title="Clique para alternar visualização da linha de tendência"
                        >
                            <span className="w-4 h-0.5 border-t-2 border-dashed border-blue-500" />
                            <span>Tendência</span>
                        </button>
                    </div>
                    <div className="h-[250px] sm:h-[350px] md:h-[400px] w-full relative z-10">
                        <ResponsiveContainer width="100%" height="100%">
                            <ComposedChart data={chartDataOthers} margin={{ top: 15, right: 20, left: -10, bottom: 5 }}>
                                <defs>
                                    <linearGradient id="gradCompliant3" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#10b981" stopOpacity={0.85} />
                                        <stop offset="100%" stopColor="#059669" stopOpacity={0.35} />
                                    </linearGradient>
                                    <linearGradient id="gradOffender3" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stopColor="#f43f5e" stopOpacity={0.85} />
                                        <stop offset="100%" stopColor="#be123c" stopOpacity={0.35} />
                                    </linearGradient>
                                </defs>
                                <CartesianGrid strokeDasharray="3 3" stroke="#ffffff" vertical={false} opacity={0.03} />
                                <XAxis dataKey="hour" stroke="#94a3b8" opacity={0.4} fontSize={9} tickLine={false} axisLine={false} />
                                <YAxis stroke="#94a3b8" opacity={0.4} fontSize={9} tickLine={false} axisLine={false} tickFormatter={(v) => secondsToTimeStr(v)} />
                                <Tooltip content={<CustomTooltip />} cursor={{ fill: '#ffffff05' }}/>
                                <ReferenceLine 
                                    y={indicatorOptions[chartIndicator].target} 
                                    stroke="#f43f5e" 
                                    strokeWidth={1.5} 
                                    strokeDasharray="6 4"
                                    label={{ 
                                        value: `SLA: ${secondsToTimeStr(indicatorOptions[chartIndicator].target)}`, 
                                        fill: '#f43f5e', 
                                        fontSize: 9, 
                                        fontWeight: 'bold', 
                                        position: 'top',
                                        offset: 8
                                    }} 
                                />
                                {showMainSeries && (
                                    <Bar dataKey={chartIndicator} name={indicatorOptions[chartIndicator].label} radius={[4, 4, 0, 0]} barSize={28}>
                                        {chartDataOthers.map((entry, index) => (
                                            <Cell key={`cell-${index}`} fill={entry[chartIndicator] > indicatorOptions[chartIndicator].target ? 'url(#gradOffender3)' : 'url(#gradCompliant3)'} />
                                        ))}
                                    </Bar>
                                )}
                                {showTrendSeries && (
                                    <Line 
                                        type="monotone" 
                                        dataKey="tendencia" 
                                        stroke="#3b82f6" 
                                        strokeWidth={2} 
                                        dot={false} 
                                        strokeDasharray="4 4"
                                        name="Tendência"
                                    />
                                )}
                            </ComposedChart>
                        </ResponsiveContainer>
                    </div>
                </div>
                    </>
                )}

                {/* MODAL DE SIMULAÇÃO */}
                {showSimulation && (
                    <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-50 flex items-center justify-center p-6">
                        <div className="bg-gray-900 border border-gray-700 rounded-[3rem] w-full max-w-2xl overflow-hidden shadow-2xl animate-fade-in">
                            <div className="p-8 border-b border-gray-800 flex justify-between items-center bg-gray-800/50">
                                <div className="flex items-center gap-4">
                                    <div className="p-3 bg-purple-600 rounded-2xl">
                                        <ActivityIcon className="w-6 h-6 text-white" />
                                    </div>
                                    <div>
                                        <h3 className="text-xl font-black text-white uppercase tracking-tighter">Simular Diluição de TMA</h3>
                                        <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Cálculo de ciclos necessários para atingir meta</p>
                                    </div>
                                </div>
                                <button onClick={() => { setShowSimulation(false); setSimResult(null); }} className="text-gray-500 hover:text-white transition-colors">
                                    <ChevronLeftIcon className="w-8 h-8 rotate-180" />
                                </button>
                            </div>
                            
                            <div className="p-8 space-y-8">
                                <div className="grid grid-cols-3 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">TMA Atual (HH:MM:SS)</label>
                                        <input 
                                            type="text" 
                                            value={simCurrentTma} 
                                            onChange={(e) => setSimCurrentTma(e.target.value)}
                                            placeholder="00:00:00"
                                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white font-mono focus:border-purple-500 outline-none transition-all"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Meta TMA (HH:MM:SS)</label>
                                        <input 
                                            type="text" 
                                            value={simTargetTma} 
                                            onChange={(e) => setSimTargetTma(e.target.value)}
                                            placeholder="00:00:00"
                                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white font-mono focus:border-purple-500 outline-none transition-all"
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Tempo Mín. Raio (Min)</label>
                                        <input 
                                            type="number" 
                                            value={simMinTime} 
                                            onChange={(e) => setSimMinTime(e.target.value)}
                                            className="w-full px-4 py-3 bg-gray-800 border border-gray-700 rounded-xl text-white font-mono focus:border-purple-500 outline-none transition-all"
                                        />
                                    </div>
                                </div>

                                <button 
                                    onClick={handleSimulate}
                                    className="w-full py-4 bg-purple-600 hover:bg-purple-500 text-white font-black rounded-2xl shadow-xl shadow-purple-900/30 transition-all uppercase tracking-widest"
                                >
                                    CALCULAR DILUIÇÃO
                                </button>

                                {simResult && (
                                    <div className="p-6 bg-gray-800/50 border border-purple-500/30 rounded-3xl space-y-4 animate-fade-in">
                                        <div className="flex items-center justify-between">
                                            <span className="text-xs font-black text-gray-400 uppercase tracking-widest">Ciclos de Diluição Necessários:</span>
                                            <span className="text-4xl font-black text-purple-400 font-mono">{simResult.cycles}</span>
                                        </div>
                                        <div className="space-y-2">
                                            <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest">Sugestões Operacionais:</span>
                                            <div className="space-y-1">
                                                {simResult.suggestions.map((s, i) => (
                                                    <p key={i} className={`text-xs font-bold ${i === 0 ? 'text-white' : 'text-purple-300/70'} flex items-center gap-2`}>
                                                        {i > 0 && <div className="w-1 h-1 bg-purple-500 rounded-full"></div>}
                                                        {s}
                                                    </p>
                                                ))}
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {/* HISTÓRICO DE IMPORTAÇÕES SALVAS (Bottom of Dashboard) */}
                <div className="mt-12 max-w-6xl mx-auto">
                    {renderSavedImportsSection()}
                </div>

                <style>{`
                    .custom-scrollbar::-webkit-scrollbar { width: 8px; }
                    .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
                    .custom-scrollbar::-webkit-scrollbar-thumb { background: #334155; border-radius: 20px; border: 3px solid transparent; background-clip: content-box; }
                    .custom-scrollbar::-webkit-scrollbar-thumb:hover { background: #4b5563; }
                `}</style>
            </div>
        );
    }

    const testSupabaseConnection = async () => {
        if (!isSupabaseConfigured) {
            setSupabaseStatus('error');
            setSupabaseMessage('Configuração ausente: As chaves de ambiente VITE_SUPABASE_URL e VITE_SUPABASE_ANON_KEY não foram preenchidas no painel do AI Studio.');
            return;
        }
        setSupabaseStatus('checking');
        setSupabaseMessage('Estabelecendo conexão e validando tabelas de TMA no Supabase...');
        try {
            const { data, error } = await supabase.from('tma_imports').select('id').limit(1);
            if (error) {
                setSupabaseStatus('error');
                setSupabaseMessage(`Erro de comunicação: ${error.message} (Código SQL: ${error.code})`);
            } else {
                setSupabaseStatus('success');
                setSupabaseMessage('Parabéns! Conexão ativa e estrutura de tabelas do TMA verificada com sucesso no Supabase.');
            }
        } catch (err: any) {
            setSupabaseStatus('error');
            setSupabaseMessage(`Falha de exceção: ${err.message || err}`);
        }
    };

    const handleSaveTargets = () => {
        const configInSeconds: TMAConfig = {
            tmfeTarget: targetsInMinutes.tmfeTarget * 60,
            tmfiTarget: targetsInMinutes.tmfiTarget * 60,
            tmcTarget: targetsInMinutes.tmcTarget * 60,
            tmsTarget: targetsInMinutes.tmsTarget * 60,
            tmpcTarget: targetsInMinutes.tmpcTarget * 60,
            totalTarget: targetsInMinutes.totalTarget * 60,
        };
        if (onSaveTmaConfig) {
            onSaveTmaConfig(configInSeconds);
            alert('Metas de TMA atualizadas com sucesso no nível de aplicação!');
        } else {
            localStorage.setItem('tmaConfig', JSON.stringify(configInSeconds));
            alert('Metas salvas localmente!');
        }
    };

    const renderSettings = () => {
        const originalTmfe = Math.round((tmaConfig.tmfeTarget || 0) / 60);
        const originalTmfi = Math.round((tmaConfig.tmfiTarget || 0) / 60);
        const originalTmc = Math.round((tmaConfig.tmcTarget || 0) / 60);
        const originalTms = Math.round((tmaConfig.tmsTarget || 0) / 60);
        const originalTmpc = Math.round((tmaConfig.tmpcTarget || 0) / 60);
        const originalTotal = Math.round((tmaConfig.totalTarget || 0) / 60);

        const hasChanges =
            targetsInMinutes.tmfeTarget !== originalTmfe ||
            targetsInMinutes.tmfiTarget !== originalTmfi ||
            targetsInMinutes.tmcTarget !== originalTmc ||
            targetsInMinutes.tmsTarget !== originalTms ||
            targetsInMinutes.tmpcTarget !== originalTmpc ||
            targetsInMinutes.totalTarget !== originalTotal;

        const handleInputChange = (field: keyof typeof targetsInMinutes, value: string) => {
            setTargetsInMinutes(prev => ({
                ...prev,
                [field]: Number(value) || 0,
            }));
        };

        return (
            <div className="space-y-8 animate-fade-in w-full pb-10 max-w-4xl mx-auto mt-4 px-4 sm:px-0">
                <div className="bg-[#0c0f16]/90 backdrop-blur-md p-5 sm:p-10 rounded-3xl border border-white/[0.06] shadow-[0_20px_50px_rgba(0,0,0,0.6)] relative overflow-hidden">
                    <div className="absolute top-0 right-0 p-4 opacity-5">
                        <div className="w-20 h-20 border-t-2 border-r-2 border-blue-500" />
                    </div>
                    
                    <div className="flex items-center gap-4 mb-8 border-b border-white/[0.04] pb-6">
                        <div className="p-3 bg-blue-500/10 rounded-xl">
                            <SettingsIcon className="w-6 h-6 text-blue-400" />
                        </div>
                        <div>
                            <h3 className="text-xl font-black text-white uppercase tracking-tight">Metas de Tempo de Atendimento (TMA)</h3>
                            <p className="text-xs text-slate-400 mt-1 uppercase tracking-wider font-bold">Defina as metas operacionais em minutos para calibrar os KPIs do dashboard</p>
                        </div>
                    </div>

                    {hasChanges && (
                        <div className="mb-6 p-4 bg-blue-500/10 border border-blue-500/20 rounded-2xl flex items-center gap-3 animate-pulse">
                            <AlertTriangle className="w-5 h-5 text-blue-400 flex-shrink-0" />
                            <div>
                                <p className="text-[10px] font-black uppercase tracking-wider text-blue-400">Alterações Detectadas</p>
                                <p className="text-[10px] text-slate-400 font-bold uppercase mt-0.5">Existem metas modificadas. Salve para aplicar os novos parâmetros ao sistema.</p>
                            </div>
                        </div>
                    )}

                    <div className="space-y-6">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">TMFE (Fila Externa)</label>
                                <input
                                    type="number"
                                    value={targetsInMinutes.tmfeTarget}
                                    onChange={(e) => handleInputChange('tmfeTarget', e.target.value)}
                                    className="w-full px-4 py-3 text-white bg-white/[0.02] border border-white/[0.08] rounded-xl font-mono focus:border-blue-500 outline-none transition-all"
                                />
                            </div>
                            <span className="text-slate-500 text-[10px] font-bold uppercase font-mono">Fila externa BI. (Atual: {originalTmfe} min)</span>
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">TMFI (Fila Interna)</label>
                                <input
                                    type="number"
                                    value={targetsInMinutes.tmfiTarget}
                                    onChange={(e) => handleInputChange('tmfiTarget', e.target.value)}
                                    className="w-full px-4 py-3 text-white bg-white/[0.02] border border-white/[0.08] rounded-xl font-mono focus:border-blue-500 outline-none transition-all"
                                />
                            </div>
                            <span className="text-slate-500 text-[10px] font-bold uppercase font-mono">Espera no pátio interno. (Atual: {originalTmfi} min)</span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">TMC (Doca - Carregamento)</label>
                                <input
                                    type="number"
                                    value={targetsInMinutes.tmcTarget}
                                    onChange={(e) => handleInputChange('tmcTarget', e.target.value)}
                                    className="w-full px-4 py-3 text-white bg-white/[0.02] border border-white/[0.08] rounded-xl font-mono focus:border-blue-500 outline-none transition-all"
                                />
                            </div>
                            <span className="text-slate-500 text-[10px] font-bold uppercase font-mono">Carregamento na doca. (Atual: {originalTmc} min)</span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">TMS (Saída Fábrica)</label>
                                <input
                                    type="number"
                                    value={targetsInMinutes.tmsTarget}
                                    onChange={(e) => handleInputChange('tmsTarget', e.target.value)}
                                    className="w-full px-4 py-3 text-white bg-white/[0.02] border border-white/[0.08] rounded-xl font-mono focus:border-blue-500 outline-none transition-all"
                                />
                            </div>
                            <span className="text-slate-500 text-[10px] font-bold uppercase font-mono">Tempo de faturamento e saída. (Atual: {originalTms} min)</span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                            <div>
                                <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">TMPC (Pós-Carregamento)</label>
                                <input
                                    type="number"
                                    value={targetsInMinutes.tmpcTarget}
                                    onChange={(e) => handleInputChange('tmpcTarget', e.target.value)}
                                    className="w-full px-4 py-3 text-white bg-white/[0.02] border border-white/[0.08] rounded-xl font-mono focus:border-blue-500 outline-none transition-all"
                                />
                            </div>
                            <span className="text-slate-500 text-[10px] font-bold uppercase font-mono">Pós-carregamento BI. (Atual: {originalTmpc} min)</span>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center pt-6 border-t border-white/[0.04]">
                            <div>
                                <label className="block text-xs font-bold text-white uppercase tracking-widest mb-2">TMA Total (Permanência Geral)</label>
                                <input
                                    type="number"
                                    value={targetsInMinutes.totalTarget}
                                    onChange={(e) => handleInputChange('totalTarget', e.target.value)}
                                    className="w-full px-4 py-3 text-white bg-white/[0.02] border border-white/[0.08] rounded-xl font-mono focus:border-blue-500 outline-none transition-all font-bold text-emerald-400"
                                />
                            </div>
                            <span className="text-slate-500 text-[10px] font-bold uppercase font-mono">Tempo total estipulado na planta. (Atual: {originalTotal} min)</span>
                        </div>
                    </div>

                    {/* Supabase Status Check Card */}
                    <div className="bg-white/[0.01] border border-white/[0.04] p-6 rounded-2xl mt-8">
                        <div className="flex items-center justify-between mb-4">
                            <div className="flex items-center gap-3">
                                <div className="p-2 bg-blue-500/10 text-blue-400 rounded-lg">
                                    <Database className="w-5 h-5" />
                                </div>
                                <div>
                                    <h4 className="text-xs font-black text-white uppercase tracking-wider">Integração com Supabase</h4>
                                    <p className="text-[10px] text-slate-500 font-bold uppercase">Estado da conexão relacional do TMA</p>
                                </div>
                            </div>
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${isSupabaseConfigured ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/15' : 'bg-red-500/10 text-red-400 border border-red-500/15'}`}>
                                {isSupabaseConfigured ? 'Ativo' : 'Não Configurado'}
                            </span>
                        </div>

                        {supabaseStatus !== 'idle' && (
                            <div className={`p-4 rounded-xl text-xs flex gap-3 items-start border mb-4 ${
                                supabaseStatus === 'checking' ? 'bg-blue-500/5 border-blue-500/10 text-blue-300' :
                                supabaseStatus === 'success' ? 'bg-emerald-500/5 border-emerald-500/10 text-emerald-300' :
                                'bg-red-500/5 border-red-500/10 text-red-300'
                            }`}>
                                <div className="flex-1">
                                    <p className="font-black uppercase text-[10px] tracking-wider mb-0.5">Resultado do Diagnóstico</p>
                                    <p className="font-semibold text-gray-300 leading-normal text-[9px] uppercase">{supabaseMessage}</p>
                                </div>
                            </div>
                        )}

                        <button
                            type="button"
                            onClick={testSupabaseConnection}
                            className="px-4 py-2 bg-white/[0.02] hover:bg-white/[0.05] border border-white/[0.08] hover:border-blue-500/30 text-white font-mono text-[9px] uppercase tracking-wider rounded-lg transition-all"
                        >
                            Diagnosticar Conexão Supabase
                        </button>
                    </div>

                    <div className="mt-8 flex justify-end gap-3">
                        <button
                            onClick={handleSaveTargets}
                            disabled={!hasChanges}
                            className={`px-8 py-3.5 font-mono font-black rounded-xl text-xs uppercase tracking-wider transition-all shadow-md cursor-pointer ${hasChanges ? 'bg-blue-600 hover:bg-blue-500 text-white shadow-blue-950/40' : 'bg-white/5 text-slate-500 border border-white/5 cursor-not-allowed'}`}
                        >
                            Gravar Novas Metas
                        </button>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <div className={`flex min-h-screen ${theme === 'light' ? 'theme-light bg-slate-50 text-slate-800' : 'bg-[#04060a] text-slate-100'} overflow-hidden font-sans relative transition-all duration-300`}>
            {/* BACKGROUND DECOR */}
            <div className="absolute top-1/4 left-1/4 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-blue-500/5 rounded-full blur-[120px] pointer-events-none" />
            <div className="absolute bottom-1/4 right-1/4 translate-x-1/2 translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/5 rounded-full blur-[120px] pointer-events-none" />

            {/* SIDEBAR - ABA DE LADO (COLLAPSIBLE ON HOVER) */}
            <div 
                onMouseEnter={() => setIsSidebarHovered(true)}
                onMouseLeave={() => setIsSidebarHovered(false)}
                className={`hidden md:flex bg-[#080b11]/95 border-r border-white/[0.06] flex-col justify-between items-center py-6 flex-shrink-0 relative z-40 transition-all duration-300 ease-in-out cursor-pointer select-none ${
                    isSidebarHovered ? 'w-20' : 'w-4'
                }`}
            >
                <div className={`flex flex-col items-center w-full transition-all duration-300 ${isSidebarHovered ? 'opacity-100 scale-100' : 'opacity-0 scale-75 pointer-events-none'}`}>
                    {/* LOGOTIPO */}
                    <div className="mb-6 relative group cursor-pointer" title="CRONOS MONITOR">
                        <div className="w-12 h-12 bg-gradient-to-br from-blue-500/10 to-indigo-500/10 rounded-xl flex items-center justify-center border border-blue-500/20 shadow-inner group-hover:border-blue-500/40 transition-all duration-300">
                            <ActivityIcon className="w-6 h-6 text-blue-400 animate-pulse" />
                        </div>
                        {/* Custom floating tooltip */}
                        <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-slate-950 text-white text-[10px] font-black uppercase tracking-widest px-3 py-2 rounded-lg border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-x-2 group-hover:translate-x-0 whitespace-nowrap shadow-xl z-50">
                            CRONOS MONITOR
                        </div>
                    </div>

                    {/* MENU DE ABAS LATERAL - "ABA DE LADO" */}
                    <div className="w-full flex flex-col items-center gap-4">
                        <button
                            onClick={() => setView('dashboard')}
                            className={`w-12 h-12 rounded-xl flex items-center justify-center relative group transition-all duration-300 cursor-pointer ${view === 'dashboard' ? 'bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-lg shadow-blue-500/15' : 'text-slate-400 hover:text-white hover:bg-white/[0.03] border border-transparent hover:border-white/[0.04]'}`}
                        >
                            <ActivityIcon className="w-5 h-5 flex-shrink-0" />
                            {entries.length > 0 && (
                                <span className="absolute -top-1 -right-1 bg-blue-500 text-white text-[8px] font-mono px-1 rounded-full font-black min-w-[16px] text-center shadow-lg shadow-blue-950/50">
                                    {entries.length}
                                </span>
                            )}
                            {/* Custom floating tooltip */}
                            <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-slate-950 text-white text-[10px] font-black uppercase tracking-wider px-3 py-2 rounded-lg border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-x-2 group-hover:translate-x-0 whitespace-nowrap shadow-xl z-50">
                                Monitor de TMA
                            </div>
                        </button>

                        <button
                            onClick={() => setView('power_bi')}
                            className={`w-12 h-12 rounded-xl flex items-center justify-center relative group transition-all duration-300 cursor-pointer ${view === 'power_bi' ? 'bg-gradient-to-r from-amber-500 to-yellow-500 text-white shadow-lg shadow-amber-500/15' : 'text-slate-400 hover:text-white hover:bg-white/[0.03] border border-transparent hover:border-white/[0.04]'}`}
                        >
                            <BarChart3 className="w-5 h-5 flex-shrink-0" />
                            {/* Custom floating tooltip */}
                            <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-slate-950 text-white text-[10px] font-black uppercase tracking-wider px-3 py-2 rounded-lg border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-x-2 group-hover:translate-x-0 whitespace-nowrap shadow-xl z-50">
                                Power BI
                            </div>
                        </button>

                        <button
                            onClick={() => setView('input')}
                            className={`w-12 h-12 rounded-xl flex items-center justify-center relative group transition-all duration-300 cursor-pointer ${view === 'input' ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-500/15' : 'text-slate-400 hover:text-white hover:bg-white/[0.03] border border-transparent hover:border-white/[0.04]'}`}
                        >
                            <FileClockIcon className="w-5 h-5 flex-shrink-0" />
                            {/* Custom floating tooltip */}
                            <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-slate-950 text-white text-[10px] font-black uppercase tracking-wider px-3 py-2 rounded-lg border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-x-2 group-hover:translate-x-0 whitespace-nowrap shadow-xl z-50">
                                Importar Planilha
                            </div>
                        </button>

                        <button
                            onClick={() => setView('settings')}
                            className={`w-12 h-12 rounded-xl flex items-center justify-center relative group transition-all duration-300 cursor-pointer ${view === 'settings' ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/15' : 'text-slate-400 hover:text-white hover:bg-white/[0.03] border border-transparent hover:border-white/[0.04]'}`}
                        >
                            <SettingsIcon className="w-5 h-5 flex-shrink-0" />
                            {/* Custom floating tooltip */}
                            <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-slate-950 text-white text-[10px] font-black uppercase tracking-wider px-3 py-2 rounded-lg border border-white/10 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-x-2 group-hover:translate-x-0 whitespace-nowrap shadow-xl z-50">
                                Ajustar Metas
                            </div>
                        </button>

                        {/* BOTÃO DE LOGOUT / SAIR - MOVIDO PARA CIMA */}
                        <button
                            onClick={onBack}
                            className="w-12 h-12 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded-xl flex items-center justify-center relative group transition-all duration-300 cursor-pointer shadow-md mt-2"
                        >
                            <LogOutIcon className="w-5 h-5" />
                            {/* Custom floating tooltip */}
                            <div className="absolute left-16 top-1/2 -translate-y-1/2 bg-slate-950 text-red-400 text-[10px] font-black uppercase tracking-wider px-3 py-2 rounded-lg border border-red-900/40 opacity-0 group-hover:opacity-100 pointer-events-none transition-all duration-300 translate-x-2 group-hover:translate-x-0 whitespace-nowrap shadow-xl z-50">
                                Sair do Sistema
                            </div>
                        </button>
                    </div>
                </div>

                {/* VISUAL HANDLE WHEN COLLAPSED */}
                {!isSidebarHovered && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none gap-2">
                        <div className="w-1 h-32 bg-gradient-to-b from-transparent via-blue-500/50 to-transparent rounded-full animate-pulse shadow-[0_0_8px_rgba(59,130,246,0.3)]" />
                        <span className="text-[7px] font-black text-slate-500 rotate-90 whitespace-nowrap tracking-widest uppercase">MENU</span>
                    </div>
                )}
            </div>

            {/* CONTEÚDO PRINCIPAL (DASHBOARD OU IMPORTAÇÃO OU CONFIGURAÇÕES) */}
            <div className={`flex-1 relative z-10 ${view === 'power_bi' ? 'p-0 overflow-hidden h-screen' : 'overflow-y-auto custom-scrollbar p-4 sm:p-6 md:p-8 pb-24 md:pb-8'}`}>
                {view !== 'power_bi' && (
                    /* STATUS BAR DO SISTEMA */
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8 pb-4 border-b border-white/[0.04]">
                        <div>
                            <h1 className="text-xl font-black text-white uppercase tracking-tight">
                                {view === 'dashboard' ? 'Monitoramento em Tempo Real' : view === 'input' ? 'Processar Nova Planilha' : 'Calibração de Metas'}
                            </h1>
                            <p className="text-xs text-slate-400 mt-0.5">Painel operacional integrado para controle logístico de TMA</p>
                        </div>
                        
                        <div className="flex flex-wrap items-center justify-between sm:justify-end gap-3 w-full sm:w-auto">
                            {/* Botão de Modo Dia / Modo Noite */}
                            <button
                                onClick={() => {
                                    const nextTheme = theme === 'dark' ? 'light' : 'dark';
                                    setTheme(nextTheme);
                                    localStorage.setItem('tma_theme', nextTheme);
                                }}
                                className="w-10 h-10 flex items-center justify-center bg-[#0a0d14]/80 hover:bg-[#111622] border border-white/[0.06] hover:border-amber-500/30 rounded-2xl transition-all cursor-pointer shadow-md group text-slate-400 hover:text-amber-400"
                                title={theme === 'dark' ? "Ativar Modo Dia (Luz)" : "Ativar Modo Noite (Escuro)"}
                            >
                                {theme === 'dark' ? (
                                    <Sun className="w-4 h-4 text-amber-400 animate-pulse" />
                                ) : (
                                    <Moon className="w-4 h-4 text-indigo-400" />
                                )}
                            </button>

                            {/* Widget do Perfil de Usuário com click para editar */}
                            <div 
                                onClick={() => {
                                    setEditName(profileName);
                                    setEditPhoto(profilePhoto);
                                    setShowProfileModal(true);
                                }}
                                className="flex items-center gap-3 bg-[#0a0d14]/80 hover:bg-[#111622] border border-white/[0.06] hover:border-blue-500/30 p-2 pl-3 pr-4 rounded-2xl transition-all cursor-pointer shadow-md group select-none"
                                title="Editar Perfil do Operador"
                            >
                                <div className="text-right">
                                    <p className="text-[9px] text-slate-500 font-black uppercase tracking-wider leading-none mb-1">Operador Ativo</p>
                                    <p className="text-xs font-black text-white group-hover:text-blue-400 transition-colors">@{profileName}</p>
                                </div>
                                <div className="relative w-9 h-9 rounded-xl overflow-hidden bg-gradient-to-br from-blue-600/20 to-indigo-600/20 border border-white/10 group-hover:border-blue-500/40 flex items-center justify-center shrink-0 shadow-inner">
                                    {profilePhoto ? (
                                        <img 
                                            src={profilePhoto} 
                                            alt={profileName} 
                                            className="w-full h-full object-cover"
                                            referrerPolicy="no-referrer"
                                        />
                                    ) : (
                                        <div className="text-blue-400 font-black font-mono text-xs uppercase">
                                            {profileName.substring(0, 2)}
                                        </div>
                                    )}
                                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center transition-all">
                                        <Camera className="w-3.5 h-3.5 text-white" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* CONTEÚDO RENDERIZADO DINAMICAMENTE */}
                <div className={view === 'power_bi' ? 'w-full h-full' : 'w-full'}>
                    {view === 'input' ? renderInput() : view === 'dashboard' ? renderDashboard() : view === 'settings' ? renderSettings() : view === 'power_bi' ? renderPowerBI() : renderAnalysis()}
                </div>
            </div>

            {/* MODAL DE CONFIRMAÇÃO DE SALVAMENTO NO FIREBASE */}
            {showSaveModal && (
                <div className="fixed inset-0 bg-black/80 backdrop-blur-md flex items-center justify-center p-4 z-[2000] animate-fade-in">
                    <div className="w-full max-w-md bg-[#0c0f16] border border-white/10 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
                        {/* Header decor */}
                        <div className="absolute top-0 right-0 p-4 opacity-5">
                            <div className="w-20 h-20 border-t-2 border-r-2 border-emerald-500" />
                        </div>
                        
                        <div className="flex items-center gap-4 mb-6 border-b border-white/[0.04] pb-4">
                            <div className="p-3 bg-emerald-500/10 rounded-xl">
                                <FileClockIcon className="w-6 h-6 text-emerald-400" />
                            </div>
                            <div>
                                <h3 className="text-lg font-black text-white uppercase tracking-tight">Salvar Importação</h3>
                                <p className="text-slate-400 text-xs mt-0.5">Grave esses dados na nuvem integrada (Firebase / Supabase)</p>
                            </div>
                        </div>

                        <div className="flex gap-2 mb-6">
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${isFirebaseConfigured ? 'bg-orange-500/10 text-orange-400 border border-orange-500/15' : 'bg-white/5 text-slate-500 border border-white/5'}`}>
                                Firebase: {isFirebaseConfigured ? 'Conectado' : 'Ausente'}
                            </span>
                            <span className={`text-[9px] font-black px-2 py-0.5 rounded uppercase tracking-wider ${isSupabaseConfigured ? 'bg-indigo-500/10 text-indigo-400 border border-indigo-500/15' : 'bg-white/5 text-slate-500 border border-white/5'}`}>
                                Supabase: {isSupabaseConfigured ? 'Conectado' : 'Ausente'}
                            </span>
                        </div>

                        <div className="space-y-4">
                            <div>
                                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Título da Importação</label>
                                <input 
                                    type="text"
                                    value={newImportTitle}
                                    onChange={(e) => setNewImportTitle(e.target.value)}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white outline-none focus:border-emerald-500 transition-all font-bold placeholder:text-gray-600 text-sm"
                                    placeholder="Ex: TMA Latas - Turno A - 01/07"
                                    required
                                />
                            </div>

                            <div className="bg-white/[0.02] border border-white/[0.04] p-4 rounded-xl space-y-2">
                                <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Informações do Registro</p>
                                <div className="grid grid-cols-2 gap-4 text-xs">
                                    <div>
                                        <span className="text-slate-500">Data Ref:</span>
                                        <p className="text-white font-bold">{reportDate}</p>
                                    </div>
                                    <div>
                                        <span className="text-slate-500">Total de Linhas:</span>
                                        <p className="text-emerald-400 font-mono font-black">{entries.length}</p>
                                    </div>
                                    <div>
                                        <span className="text-slate-500">Tipo de Entrada:</span>
                                        <p className="text-white font-bold">{inputMode === 'full' ? 'Totem + BI' : 'Apenas BI'}</p>
                                    </div>
                                    <div>
                                        <span className="text-slate-500">Operador:</span>
                                        <p className="text-white font-bold">Monitor TMA</p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="flex justify-end gap-3 mt-8 border-t border-white/[0.04] pt-6">
                            <button 
                                onClick={() => setShowSaveModal(false)}
                                className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl text-xs font-black uppercase tracking-widest transition-all"
                                disabled={isSavingImport}
                            >
                                Cancelar
                            </button>
                            <button 
                                onClick={handleSaveImport}
                                className="px-6 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-black rounded-xl text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2 shadow-lg shadow-emerald-500/10"
                                disabled={isSavingImport}
                            >
                                {isSavingImport ? 'Salvando...' : 'Confirmar'}
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {isStratModalOpen && (
                <StratificationModal
                    isOpen={isStratModalOpen}
                    onClose={() => setIsStratModalOpen(false)}
                    onSave={handleSaveStratification}
                    placa={stratPlaca}
                    transportadora={stratTransportadora}
                    guia={stratGuia}
                />
            )}

            {/* WELCOME BANNER/TOAST */}
            {showWelcomeToast && (
                <div className="fixed top-6 right-6 z-[3000] max-w-sm w-full bg-[#070a0f]/95 backdrop-blur-xl border-l-4 border-l-emerald-500 border border-white/10 rounded-2xl p-4 shadow-[0_20px_50px_rgba(0,0,0,0.5)] animate-slide-in flex items-center gap-4">
                    <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-600/20 to-teal-600/20 flex items-center justify-center text-emerald-400 shrink-0 shadow-md overflow-hidden border border-emerald-500/20">
                        {profilePhoto ? (
                            <img src={profilePhoto} alt={profileName} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : (
                            <div className="text-sm font-black font-mono uppercase">{profileName.substring(0, 2)}</div>
                        )}
                    </div>
                    <div className="flex-1 min-w-0">
                        <p className="text-[10px] text-emerald-400 font-black uppercase tracking-wider mb-0.5">CRONOS AI • SISTEMA ATIVO</p>
                        <h4 className="text-xs font-black text-white truncate uppercase">Bem-vindo, @{profileName}!</h4>
                        <p className="text-[9px] text-slate-400 font-semibold uppercase tracking-wide mt-0.5">Assistente conectado e pronto.</p>
                    </div>
                    <button 
                        onClick={() => setShowWelcomeToast(false)} 
                        className="text-slate-500 hover:text-white p-1 rounded-lg hover:bg-white/5 transition-all cursor-pointer"
                    >
                        <XCircle className="w-4 h-4" />
                    </button>
                </div>
            )}

            {/* MODAL DE PERFIL DO OPERADOR */}
            {showProfileModal && (
                <div className="fixed inset-0 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 z-[3000] animate-fade-in select-none">
                    <div className="w-full max-w-md bg-[#0c0f16] border border-white/10 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-5">
                            <LucideUser className="w-24 h-24 text-blue-500" />
                        </div>

                        <div className="flex items-center gap-4 mb-6 border-b border-white/[0.04] pb-4">
                            <div className="p-3 bg-blue-500/10 rounded-xl">
                                <LucideUser className="w-6 h-6 text-blue-400" />
                            </div>
                            <div>
                                <h3 className="text-lg font-black text-white uppercase tracking-tight">Perfil do Operador</h3>
                                <p className="text-slate-400 text-xs mt-0.5">Customize sua assinatura visual no CRONOS AI</p>
                            </div>
                        </div>

                        <div className="space-y-6">
                            {/* Previsualização / Avatar */}
                            <div className="flex flex-col items-center justify-center space-y-3 bg-white/[0.02] border border-white/[0.04] p-6 rounded-2xl">
                                <div className="relative w-24 h-24 rounded-2xl overflow-hidden bg-gradient-to-br from-blue-600/20 to-indigo-600/20 border border-white/10 flex items-center justify-center shadow-xl">
                                    {editPhoto ? (
                                        <img src={editPhoto} alt="Prévia" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                    ) : (
                                        <div className="text-blue-400 font-black font-mono text-3xl uppercase">
                                            {editName ? editName.substring(0, 2) : 'OP'}
                                        </div>
                                    )}
                                    <button 
                                        type="button"
                                        onClick={() => {
                                            const fileInput = document.getElementById('modal-profile-file-input-2');
                                            if (fileInput) fileInput.click();
                                        }}
                                        className="absolute bottom-1 right-1 p-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl shadow-lg transition-all border border-blue-400/20 cursor-pointer flex items-center justify-center"
                                        title="Carregar Foto"
                                    >
                                        <Camera className="w-3.5 h-3.5" />
                                    </button>
                                </div>
                                <div className="flex gap-2">
                                    <button
                                        type="button"
                                        onClick={() => {
                                            const fileInput = document.getElementById('modal-profile-file-input-2');
                                            if (fileInput) fileInput.click();
                                        }}
                                        className="text-[9px] font-black bg-blue-500/10 hover:bg-blue-500/20 text-blue-400 border border-blue-500/15 px-3 py-1.5 rounded-lg uppercase tracking-wider transition-all cursor-pointer"
                                    >
                                        Fazer Upload
                                    </button>
                                    {editPhoto && (
                                        <button
                                            type="button"
                                            onClick={() => setEditPhoto('')}
                                            className="text-[9px] font-black bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/15 px-3 py-1.5 rounded-lg uppercase tracking-wider transition-all cursor-pointer"
                                        >
                                            Remover Foto
                                        </button>
                                    )}
                                </div>
                                <input 
                                    id="modal-profile-file-input-2"
                                    type="file" 
                                    accept="image/*"
                                    onChange={(e) => {
                                        const file = e.target.files?.[0];
                                        if (file) {
                                            if (file.size > 1.5 * 1024 * 1024) {
                                                alert("A imagem selecionada é muito grande! Escolha um arquivo com menos de 1.5MB.");
                                                return;
                                            }
                                            const reader = new FileReader();
                                            reader.onloadend = () => {
                                                if (typeof reader.result === 'string') {
                                                    setEditPhoto(reader.result);
                                                }
                                            };
                                            reader.readAsDataURL(file);
                                        }
                                    }}
                                    className="hidden"
                                />
                            </div>

                            {/* Campo do Nome */}
                            <div>
                                <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2 ml-1">Nome do Operador</label>
                                <input 
                                    type="text"
                                    value={editName}
                                    onChange={(e) => setEditName(e.target.value)}
                                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white outline-none focus:border-blue-500 transition-all font-bold placeholder:text-gray-600 text-sm"
                                    placeholder="Digite seu nome..."
                                    required
                                    maxLength={30}
                                />
                            </div>
                        </div>

                        {/* Botões do Modal */}
                        <div className="flex justify-end gap-3 border-t border-white/[0.04] pt-6 mt-8">
                            <button 
                                type="button"
                                onClick={() => setShowProfileModal(false)}
                                className="px-5 py-2.5 bg-white/5 hover:bg-white/10 text-slate-400 hover:text-white rounded-xl text-xs font-black uppercase tracking-widest transition-all cursor-pointer"
                            >
                                Cancelar
                            </button>
                            <button 
                                type="button"
                                onClick={() => {
                                    const trimmed = editName.trim();
                                    if (trimmed) {
                                        setProfileName(trimmed);
                                        setProfilePhoto(editPhoto);
                                        localStorage.setItem(`tma_profile_name_${user?.login || 'guest'}`, trimmed);
                                        localStorage.setItem(`tma_profile_photo_${user?.login || 'guest'}`, editPhoto);
                                        setShowProfileModal(false);
                                    }
                                }}
                                className="px-6 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-black uppercase tracking-widest transition-all shadow-lg shadow-blue-500/10 cursor-pointer"
                            >
                                Salvar Perfil
                            </button>
                        </div>
                    </div>
                </div>
            )}

            {/* BOTTOM BAR PARA MOBILE */}
            <div className="md:hidden fixed bottom-0 left-0 right-0 bg-[#080b11]/95 backdrop-blur-md border-t border-white/[0.06] py-2 px-3 flex justify-around items-center z-50 shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
                <button
                    onClick={() => setView('dashboard')}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-300 cursor-pointer ${view === 'dashboard' ? 'text-blue-500' : 'text-slate-400'}`}
                >
                    <ActivityIcon className="w-5 h-5" />
                    <span className="text-[9px] font-black uppercase tracking-wider mt-1">Monitor</span>
                </button>

                <button
                    onClick={() => setView('power_bi')}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-300 cursor-pointer ${view === 'power_bi' ? 'text-amber-500' : 'text-slate-400'}`}
                >
                    <BarChart3 className="w-5 h-5" />
                    <span className="text-[9px] font-black uppercase tracking-wider mt-1">Power BI</span>
                </button>

                <button
                    onClick={() => setView('input')}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-300 cursor-pointer ${view === 'input' ? 'text-emerald-500' : 'text-slate-400'}`}
                >
                    <FileClockIcon className="w-5 h-5" />
                    <span className="text-[9px] font-black uppercase tracking-wider mt-1">Planilha</span>
                </button>

                <button
                    onClick={() => setView('settings')}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl transition-all duration-300 cursor-pointer ${view === 'settings' ? 'text-indigo-500' : 'text-slate-400'}`}
                >
                    <SettingsIcon className="w-5 h-5" />
                    <span className="text-[9px] font-black uppercase tracking-wider mt-1">Metas</span>
                </button>

                <button
                    onClick={onBack}
                    className="flex flex-col items-center justify-center p-2 rounded-xl text-red-400 cursor-pointer"
                >
                    <LogOutIcon className="w-5 h-5" />
                    <span className="text-[9px] font-black uppercase tracking-wider mt-1">Sair</span>
                </button>
            </div>

            <style>{`
                @keyframes fade-in { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
                .animate-fade-in { animation: fade-in 0.35s cubic-bezier(0.215, 0.610, 0.355, 1) forwards; }
                @keyframes slide-in { from { opacity: 0; transform: translateX(20px); } to { opacity: 1; transform: translateX(0); } }
                .animate-slide-in { animation: slide-in 0.4s cubic-bezier(0.215, 0.610, 0.355, 1) forwards; }

                /* REGRAS DO MODO DIA (LIGHT THEME) OVERRIDES */
                .theme-light {
                    background-color: #f8fafc !important;
                    background-image: radial-gradient(circle at top left, #f1f5f9 0%, #f8fafc 100%) !important;
                    color: #1e293b !important;
                }
                /* Mapeamento de backgrounds escuros para brancos/claros */
                .theme-light .bg-\[\#04060a\] { background-color: #f8fafc !important; }
                .theme-light .bg-\[\#0a0d14\] { background-color: #ffffff !important; }
                .theme-light .bg-\[\#0c0f16\] { background-color: #ffffff !important; }
                .theme-light .bg-\[\#080b11\] { background-color: #ffffff !important; }
                .theme-light .bg-\[\#070a0f\] { background-color: #ffffff !important; }
                .theme-light .bg-\[\#0d121f\] { background-color: #ffffff !important; }
                .theme-light .bg-\[\#0c0f16\]\/95 { background-color: #ffffff !important; }
                .theme-light .bg-\[\#0a0d14\]\/80 { background-color: rgba(255, 255, 255, 0.9) !important; }
                .theme-light .bg-\[\#0a0d14\]\/90 { background-color: #ffffff !important; }
                .theme-light .bg-\[\#0c0f16\]\/90 { background-color: #ffffff !important; }
                .theme-light .bg-\[\#080b11\]\/95 { background-color: #ffffff !important; border-right: 1px solid rgba(15, 23, 42, 0.08) !important; }
                .theme-light .bg-black\/40 { background-color: #f8fafc !important; }
                .theme-light .bg-black\/30 { background-color: #f8fafc !important; }
                .theme-light .bg-white\/\[0\.02\] { background-color: #f8fafc !important; }
                .theme-light .bg-white\/5 { background-color: #f1f5f9 !important; }
                .theme-light .bg-white\/\[0\.03\] { background-color: #f1f5f9 !important; }

                /* Botões e elementos interativos */
                .theme-light .bg-\[\#0a0d14\]\/80.hover\:bg-\[\#111622\]:hover { background-color: #f1f5f9 !important; }
                .theme-light .hover\:bg-white\/\[0\.03\]:hover { background-color: #f1f5f9 !important; }
                .theme-light .hover\:bg-white\/5:hover { background-color: #e2e8f0 !important; }
                .theme-light .hover\:bg-white\/10:hover { background-color: #cbd5e1 !important; }
                .theme-light .hover\:bg-white\/\[0\.02\]:hover { background-color: #f8fafc !important; }

                /* Sombras e Bordas */
                .theme-light [class*="shadow-"] {
                    box-shadow: 0 10px 30px -10px rgba(15, 23, 42, 0.05), 0 1px 3px rgba(15, 23, 42, 0.02) !important;
                }
                .theme-light [class*="shadow-\[0_20px_50px_"] {
                    box-shadow: 0 20px 40px -15px rgba(15, 23, 42, 0.1), 0 4px 10px rgba(15, 23, 42, 0.03) !important;
                }
                .theme-light [class*="border-white"] {
                    border-color: rgba(15, 23, 42, 0.08) !important;
                }
                .theme-light .border-white\/10 { border-color: rgba(15, 23, 42, 0.1) !important; }
                .theme-light .divide-white\/\[0\.04\] > * + * { border-color: rgba(15, 23, 42, 0.06) !important; }

                /* Cores de textos principais */
                .theme-light .text-slate-100 { color: #1e293b !important; }
                .theme-light .text-slate-200 { color: #334155 !important; }
                .theme-light .text-slate-300 { color: #475569 !important; }
                .theme-light .text-slate-400 { color: #64748b !important; }
                .theme-light .text-slate-500 { color: #64748b !important; }
                .theme-light .text-white { color: #0f172a !important; }
                .theme-light h1, .theme-light h2, .theme-light h3, .theme-light h4, .theme-light h5, .theme-light h6 { color: #0f172a !important; }

                /* Correção de contraste para textos coloridos */
                .theme-light .text-cyan-400 { color: #0891b2 !important; }
                .theme-light .text-blue-400 { color: #2563eb !important; }
                .theme-light .text-green-400 { color: #059669 !important; }
                .theme-light .text-emerald-400 { color: #059669 !important; }
                .theme-light .text-yellow-400 { color: #ca8a04 !important; }
                .theme-light .text-orange-400 { color: #ea580c !important; }
                .theme-light .text-red-400 { color: #dc2626 !important; }
                .theme-light .text-amber-400 { color: #d97706 !important; }
                .theme-light .text-purple-400 { color: #7c3aed !important; }

                /* Grids do Gráfico Recharts */
                .theme-light .recharts-cartesian-grid line {
                    stroke: #cbd5e1 !important;
                    stroke-opacity: 0.5 !important;
                }

                /* Inputs e Dropdowns */
                .theme-light input[type="text"],
                .theme-light input[type="number"],
                .theme-light select,
                .theme-light textarea {
                    background-color: #ffffff !important;
                    color: #0f172a !important;
                    border: 1px solid rgba(15, 23, 42, 0.15) !important;
                }
                .theme-light input[type="text"]:focus,
                .theme-light input[type="number"]:focus,
                .theme-light select:focus,
                .theme-light textarea:focus {
                    border-color: #2563eb !important;
                    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.15) !important;
                }
                .theme-light input::placeholder {
                    color: #94a3b8 !important;
                }
                .theme-light option {
                    background-color: #ffffff !important;
                    color: #0f172a !important;
                }

                /* Cards adicionais coloridos (Ofensores, Outliers, Pátio, etc) */
                .theme-light .bg-blue-900\/20 {
                    background-color: rgba(37, 99, 235, 0.05) !important;
                    border-color: rgba(37, 99, 235, 0.15) !important;
                }
                .theme-light .bg-yellow-900\/40 {
                    background-color: rgba(234, 179, 8, 0.05) !important;
                    border-color: rgba(234, 179, 8, 0.15) !important;
                }
                .theme-light .bg-red-900\/20 {
                    background-color: rgba(239, 68, 68, 0.05) !important;
                    border-color: rgba(239, 68, 68, 0.15) !important;
                }
                .theme-light .bg-orange-900\/20 {
                    background-color: rgba(249, 115, 22, 0.05) !important;
                    border-color: rgba(249, 115, 22, 0.15) !important;
                }
                .theme-light .bg-emerald-900\/30 {
                    background-color: rgba(16, 185, 129, 0.05) !important;
                    border-color: rgba(16, 185, 129, 0.15) !important;
                }
                .theme-light .bg-purple-900\/30 {
                    background-color: rgba(139, 92, 246, 0.05) !important;
                    border-color: rgba(139, 92, 246, 0.15) !important;
                }

                /* Tooltip customizado do gráfico em modo claro */
                .theme-light .bg-gray-900\/80 {
                    background-color: rgba(255, 255, 255, 0.98) !important;
                    border: 1px solid rgba(15, 23, 42, 0.12) !important;
                    box-shadow: 0 10px 25px -5px rgba(15, 23, 42, 0.08) !important;
                }
                .theme-light .bg-gray-900\/80 p {
                    color: #0f172a !important;
                }
                .theme-light .bg-gray-900\/80 .border-t-gray-600 {
                    border-top-color: rgba(15, 23, 42, 0.1) !important;
                }

                /* Sidebar Links adicionais */
                .theme-light .bg-\[\#080b11\]\/95 button {
                    color: #64748b !important;
                }
                .theme-light .bg-\[\#080b11\]\/95 button:hover {
                    color: #2563eb !important;
                    background-color: #f1f5f9 !important;
                }
                .theme-light .bg-\[\#080b11\]\/95 button.bg-gradient-to-r {
                    color: #ffffff !important;
                    background-image: linear-gradient(to right, #2563eb, #4f46e5) !important;
                }

                /* Modal específico */
                .theme-light .bg-\[\#0c0f16\] { 
                    background-color: #ffffff !important; 
                    border: 1px solid rgba(15, 23, 42, 0.12) !important; 
                }
            `}</style>
        </div>
    );
};

export default TMAMonitoringScreen;