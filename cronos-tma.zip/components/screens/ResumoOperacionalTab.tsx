import React, { useState, useMemo, useEffect } from 'react';
import { TMALogEntry, TMAConfig } from '../../types';
import { calculateAverage, validateDuration, formatDurationHuman, secondsToTimeStr, secondsToTimeStrShort } from '../../tmaEngine';
import ClockIcon from '../icons/ClockIcon';
import MapPinIcon from '../icons/MapPinIcon';
import CalendarDaysIcon from '../icons/CalendarDaysIcon';
import CopyIcon from '../icons/CopyIcon';
import ActivityIcon from '../icons/ActivityIcon';
import AlertTriangleIcon from '../icons/AlertTriangleIcon';
import CheckCircleIcon from '../icons/CheckCircleIcon';
import ShieldCheckIcon from '../icons/ShieldCheckIcon';
import ChevronDownIcon from '../icons/ChevronDownIcon';
import ChevronUpIcon from '../icons/ChevronUpIcon';
import InfoIcon from '../icons/InfoIcon';
import { Filter } from 'lucide-react';

interface ResumoOperacionalTabProps {
    entries: TMALogEntry[];
    tmaConfig: TMAConfig;
    reportDate: string;
}

const formatDuration = (seconds: number): string => {
    return formatDurationHuman(seconds);
};

const formatSecondsToTimeStr = (totalSeconds: number): string => {
    return secondsToTimeStr(totalSeconds);
};

export const ResumoOperacionalTab: React.FC<ResumoOperacionalTabProps> = ({ entries, tmaConfig, reportDate }) => {
    // Check if we are using mock/fictive entries (no real stratification uploaded)
    const isUsingMock = useMemo(() => {
        return entries.length === 0 || entries.some(e => e.id?.startsWith('mock-'));
    }, [entries]);

    // Unique factories and dates in data
    const opUniqueFactories = useMemo(() => {
        if (isUsingMock) return [];
        const set = new Set<string>();
        entries.forEach(e => {
            const fact = e.bi_unidade_dimensionada || e.local;
            if (fact && fact !== '-' && fact.trim() !== '') {
                set.add(fact.trim());
            }
        });
        if (set.size === 0) {
            return ['Latas Minas'];
        }
        return Array.from(set).sort();
    }, [entries, isUsingMock]);

    const opUniqueDates = useMemo(() => {
        if (isUsingMock) return [];
        const set = new Set<string>();
        entries.forEach(e => {
            const datePart = (e.horaDoca || e.horaEntrada || '').split(' ')[0];
            if (datePart && datePart !== '-' && datePart !== '01/01/1970' && !datePart.includes('1970')) set.add(datePart);
        });
        const list = Array.from(set).filter(Boolean).sort();
        return list;
    }, [entries, isUsingMock]);

    // Active applied filters
    const [opDate, setOpDate] = useState<string>('ALL');
    const [opFactory, setOpFactory] = useState<string>('ALL');
    const [opStartHour, setOpStartHour] = useState<string>('00:00');
    const [opEndHour, setOpEndHour] = useState<string>('23:59');

    // Draft filter states (bound to UI fields)
    const [draftOpDate, setDraftOpDate] = useState<string>('ALL');
    const [draftOpFactory, setDraftOpFactory] = useState<string>('ALL');
    const [draftOpStartHour, setDraftOpStartHour] = useState<string>('00:00');
    const [draftOpEndHour, setDraftOpEndHour] = useState<string>('23:59');

    // Flag to check if there are unapplied filter changes
    const hasUnappliedFilters = useMemo(() => {
        return draftOpDate !== opDate ||
               draftOpFactory !== opFactory ||
               draftOpStartHour !== opStartHour ||
               draftOpEndHour !== opEndHour;
    }, [draftOpDate, opDate, draftOpFactory, opFactory, draftOpStartHour, opStartHour, draftOpEndHour, opEndHour]);

    const applyFilters = () => {
        setOpDate(draftOpDate);
        setOpFactory(draftOpFactory);
        setOpStartHour(draftOpStartHour);
        setOpEndHour(draftOpEndHour);
    };

    const discardFilters = () => {
        setDraftOpDate(opDate);
        setDraftOpFactory(opFactory);
        setDraftOpStartHour(opStartHour);
        setDraftOpEndHour(opEndHour);
    };

    // Overrides for simulation
    const [opOverrideTMFE, setOpOverrideTMFE] = useState<number | null>(null);
    const [opOverrideTMFI, setOpOverrideTMFI] = useState<number | null>(null);
    const [opOverrideTMC, setOpOverrideTMC] = useState<number | null>(null);
    const [opOverrideTMS, setOpOverrideTMS] = useState<number | null>(null);

    // Draft states for simulation inputs
    const [draftOverrideTMFE, setDraftOverrideTMFE] = useState<number | null>(null);
    const [draftOverrideTMFI, setDraftOverrideTMFI] = useState<number | null>(null);
    const [draftOverrideTMC, setDraftOverrideTMC] = useState<number | null>(null);
    const [draftOverrideTMS, setDraftOverrideTMS] = useState<number | null>(null);

    const handleApply = () => {
        setOpOverrideTMFE(draftOverrideTMFE);
        setOpOverrideTMFI(draftOverrideTMFI);
        setOpOverrideTMC(draftOverrideTMC);
        setOpOverrideTMS(draftOverrideTMS);
    };

    const handleDiscard = () => {
        setDraftOverrideTMFE(opOverrideTMFE);
        setDraftOverrideTMFI(opOverrideTMFI);
        setDraftOverrideTMC(opOverrideTMC);
        setDraftOverrideTMS(opOverrideTMS);
    };

    const hasUnappliedChanges = useMemo(() => {
        return draftOverrideTMFE !== opOverrideTMFE ||
               draftOverrideTMFI !== opOverrideTMFI ||
               draftOverrideTMC !== opOverrideTMC ||
               draftOverrideTMS !== opOverrideTMS;
    }, [draftOverrideTMFE, opOverrideTMFE, draftOverrideTMFI, opOverrideTMFI, draftOverrideTMC, opOverrideTMC, draftOverrideTMS, opOverrideTMS]);

    const [copySuccess, setCopySuccess] = useState<boolean>(false);
    const [isAdjustmentsOpen, setIsAdjustmentsOpen] = useState<boolean>(false);

    // Sync draft values when the adjustments block is opened
    useEffect(() => {
        if (isAdjustmentsOpen) {
            setDraftOverrideTMFE(opOverrideTMFE);
            setDraftOverrideTMFI(opOverrideTMFI);
            setDraftOverrideTMC(opOverrideTMC);
            setDraftOverrideTMS(opOverrideTMS);
        }
    }, [isAdjustmentsOpen]);

    // Auto-populate filters based on loaded data
    useEffect(() => {
        if (entries.length > 0) {
            const sorted = [...entries].sort((a, b) => {
                const refA = a.horaDoca && a.horaDoca !== '-' ? a.horaDoca : a.horaEntrada || '';
                const refB = b.horaDoca && b.horaDoca !== '-' ? b.horaDoca : b.horaEntrada || '';
                return refB.localeCompare(refA);
            });
            const latest = sorted[0];
            
            // Default to full 24h day to ensure no imported data is excluded by default
            const startVal = '00:00';
            const endVal = '23:59';
            setOpStartHour(startVal);
            setOpEndHour(endVal);
            setDraftOpStartHour(startVal);
            setDraftOpEndHour(endVal);
            
            if (reportDate && reportDate !== '--/--/----') {
                setOpDate(reportDate);
                setDraftOpDate(reportDate);
            } else {
                const latestDatePart = (latest.horaDoca || latest.horaEntrada || '').split(' ')[0];
                if (latestDatePart && latestDatePart !== '-') {
                    setOpDate(latestDatePart);
                    setDraftOpDate(latestDatePart);
                }
            }
            
            setOpFactory('ALL');
            setDraftOpFactory('ALL');
        }
    }, [entries, reportDate]);

    // Apply filters to data
    const opFilteredEntries = useMemo(() => {
        if (entries.length === 0 || isUsingMock) return [];
        return entries.filter(e => {
            if (opDate !== 'ALL') {
                const datePart = (e.horaDoca || e.horaEntrada || '').split(' ')[0];
                if (datePart !== opDate) return false;
            }
            
            if (opFactory !== 'ALL' && opFactory !== 'Latas Minas') {
                const factoryPart = e.bi_unidade_dimensionada || e.local || '';
                if (factoryPart !== opFactory) return false;
            }
            
            const refTime = e.horaDoca && e.horaDoca !== '-' ? e.horaDoca : e.horaEntrada;
            if (refTime && refTime.split(' ')[1]) {
                const timeStr = refTime.split(' ')[1];
                const [hStr, mStr] = timeStr.split(':');
                const minutes = (parseInt(hStr) || 0) * 60 + (parseInt(mStr) || 0);
                
                const [shStr, smStr] = opStartHour.split(':');
                const startMin = (parseInt(shStr) || 0) * 60 + (parseInt(smStr) || 0);
                
                const [ehStr, emStr] = opEndHour.split(':');
                const endMin = (parseInt(ehStr) || 0) * 60 + (parseInt(emStr) || 0);
                
                if (minutes < startMin || minutes > endMin) return false;
            }
            
            return true;
        });
    }, [entries, opDate, opFactory, opStartHour, opEndHour, isUsingMock]);

    // Calculate actual metrics or fall back to default
    const metrics = useMemo(() => {
        if (isUsingMock) {
            return {
                tmfe: 0,
                tmfi: 0,
                tmc: 0,
                tms: 0,
                total: 0,
                tmfeCount: 0,
                tmfiCount: 0,
                tmcCount: 0,
                tmsCount: 0,
                totalCount: 0,
                isUsingDefaults: true
            };
        }

        const tmfeAvg = calculateAverage(opFilteredEntries.map(e => e.tmfeValidation || validateDuration(e.tmfe_calculado)));
        const tmfiAvg = calculateAverage(opFilteredEntries.map(e => e.tmfiValidation || validateDuration(e.tmfi)));
        const tmcAvg = calculateAverage(opFilteredEntries.map(e => e.tmcValidation || validateDuration(e.tmc)));
        const tmsAvg = calculateAverage(opFilteredEntries.map(e => e.tmfsValidation || e.tmsValidation || validateDuration(e.tms)));
        const totalAvg = calculateAverage(opFilteredEntries.map(e => e.totalValidation || validateDuration(e.total)));

        const tmfeVal = opOverrideTMFE !== null ? opOverrideTMFE * 60 : (tmfeAvg.average ?? 0);
        const tmfiVal = opOverrideTMFI !== null ? opOverrideTMFI * 60 : (tmfiAvg.average ?? 0);
        const tmcVal = opOverrideTMC !== null ? opOverrideTMC * 60 : (tmcAvg.average ?? 0);
        const tmsVal = opOverrideTMS !== null ? opOverrideTMS * 60 : (tmsAvg.average ?? 0);
        
        // Total TMA can be calculated from valid totals or the sum of available valid averages
        const calculatedTotal = totalAvg.average !== null ? totalAvg.average : (tmfeVal + tmfiVal + tmcVal + tmsVal);

        return {
            tmfe: tmfeVal,
            tmfi: tmfiVal,
            tmc: tmcVal,
            tms: tmsVal,
            total: calculatedTotal,
            tmfeCount: tmfeAvg.count,
            tmfiCount: tmfiAvg.count,
            tmcCount: tmcAvg.count,
            tmsCount: tmsAvg.count,
            totalCount: totalAvg.count,
            isUsingDefaults: opFilteredEntries.length === 0 && opOverrideTMFE === null && opOverrideTMFI === null && opOverrideTMC === null && opOverrideTMS === null
        };
    }, [opFilteredEntries, opOverrideTMFE, opOverrideTMFI, opOverrideTMC, opOverrideTMS, isUsingMock]);

    // Active targets
    const targets = useMemo(() => {
        return {
            tmfe: tmaConfig.tmfeTarget || 1800, // SLA default 30 min (1800s)
            tmfi: tmaConfig.tmfiTarget || 1680, // SLA default 28 min (1680s)
            tmc: tmaConfig.tmcTarget || 2340,   // SLA default 39 min (2340s)
            tms: tmaConfig.tmsTarget || 540,    // SLA default 9 min (540s)
            total: tmaConfig.totalTarget || 4500 // SLA default 1h15m (4500s)
        };
    }, [tmaConfig]);

    const isBiOnlyData = useMemo(() => {
        return entries.length > 0 && entries.every(e => !e.horaEntrada || e.horaEntrada === '-');
    }, [entries]);

    // Get individual indicators statuses
    const indicatorsData = useMemo(() => {
        const getIndStatus = (actual: number, target: number) => {
            if (isUsingMock) {
                return { label: 'Aguardando dados', emoji: '⚪', color: 'text-gray-400', bg: 'bg-gray-500/5 border-gray-800', rawStatus: 'SEM_DADOS' };
            }
            if (actual < target) {
                return { label: 'Dentro do esperado', emoji: '🟢', color: 'text-emerald-400', bg: 'bg-emerald-500/10 border-emerald-500/20', rawStatus: 'DENTRO' };
            } else if (actual === target || (actual > target && actual <= target * 1.15)) {
                return { label: 'Atenção operacional', emoji: '🟡', color: 'text-yellow-400', bg: 'bg-yellow-500/10 border-yellow-500/20', rawStatus: 'ATENCAO' };
            } else {
                return { label: 'Acima do esperado', emoji: '🔴', color: 'text-red-400', bg: 'bg-red-500/10 border-red-500/20', rawStatus: 'ACIMA' };
            }
        };

        const result: Record<string, {
            id: string;
            name: string;
            actual: number;
            target: number;
            status: { label: string; emoji: string; color: string; bg: string; rawStatus: string; };
            icon: string;
            description: string;
        }> = {
            tmfe: {
                id: 'TMFE',
                name: 'TMFE | Fila Entrada',
                actual: metrics.tmfe,
                target: targets.tmfe,
                status: getIndStatus(metrics.tmfe, targets.tmfe),
                icon: '🚪',
                description: 'Representa o tempo do veículo aguardando entrada/liberação inicial.'
            },
            tmfi: {
                id: 'TMFI',
                name: 'TMFI | Fila Interna',
                actual: metrics.tmfi,
                target: targets.tmfi,
                status: getIndStatus(metrics.tmfi, targets.tmfi),
                icon: '🚚',
                description: 'Representa o tempo de espera interna até iniciar o carregamento.'
            },
            tmc: {
                id: 'TMC',
                name: 'TMC | Carregamento',
                actual: metrics.tmc,
                target: targets.tmc,
                status: getIndStatus(metrics.tmc, targets.tmc),
                icon: '📦',
                description: 'Representa o tempo total da operação de carregamento.'
            },
            tms: {
                id: 'TMS',
                name: 'TMS | Fila Saída',
                actual: metrics.tms,
                target: targets.tms,
                status: getIndStatus(metrics.tms, targets.tms),
                icon: '🚪',
                description: 'Representa o tempo após finalização do carregamento até liberação.'
            }
        };
        return result;
    }, [metrics, targets, isUsingMock]);

    // Calculate Deviation
    const deviationSeconds = metrics.total - targets.total;
    const isOverTarget = deviationSeconds > 0;
    const deviationStr = isUsingMock 
        ? 'Sem desvio calculado (Aguardando dados)'
        : (isOverTarget 
            ? `+${formatDuration(deviationSeconds)} acima da meta`
            : `-${formatDuration(Math.abs(deviationSeconds))} abaixo da meta`);

    // Sort and calculate worst offenders
    const offendersRanking = useMemo(() => {
        const list = [
            { id: 'TMFE', name: 'TMFE | Fila Entrada', diff: metrics.tmfe - targets.tmfe, actual: metrics.tmfe, target: targets.tmfe },
            { id: 'TMFI', name: 'TMFI | Fila Interna', diff: metrics.tmfi - targets.tmfi, actual: metrics.tmfi, target: targets.tmfi },
            { id: 'TMC', name: 'TMC | Carregamento', diff: metrics.tmc - targets.tmc, actual: metrics.tmc, target: targets.tmc },
            { id: 'TMS', name: 'TMS | Fila Saída', diff: metrics.tms - targets.tms, actual: metrics.tms, target: targets.tms }
        ];

        // Sort by overflow first, then by absolute value
        const sorted = [...list].sort((a, b) => b.diff - a.diff);
        
        // Define diagnoses / causes
        const diagnoses: Record<string, string> = {
            'TMFE': 'Aguardando liberação inicial na portaria externa, retenção por falta de agendamento ou triagem documental lenta.',
            'TMFI': 'Aguardando liberação para carregamento e concentração de veículos na área interna.',
            'TMC': 'Aguardando separação de SKU, indisponibilidade momentânea de empilhadeiras ou lentidão no processo físico de doca.',
            'TMS': 'Retenção após finalização do carregamento (demora em emissão de notas fiscais ou colocação de lacres).'
        };

        return sorted.map((item, index) => {
            const medal = index === 0 ? '🥇' : index === 1 ? '🥈' : index === 2 ? '🥉' : '🔍';
            return {
                ...item,
                medal,
                rank: index + 1,
                cause: diagnoses[item.id]
            };
        });
    }, [metrics, targets]);

    // Get Overall Operational Status
    const overallOperationalStatus = useMemo(() => {
        if (isUsingMock) {
            return { label: 'AGUARDANDO DADOS', color: 'text-gray-400 border-gray-800 bg-gray-900/5', icon: '⚪' };
        }
        const aboveCount = (Object.values(indicatorsData) as any[]).filter(ind => ind.status.rawStatus === 'ACIMA').length;
        const attentionCount = (Object.values(indicatorsData) as any[]).filter(ind => ind.status.rawStatus === 'ATENCAO').length;
        
        if (aboveCount >= 3 || metrics.total > targets.total * 1.15) {
            return { label: 'CRÍTICO', color: 'text-red-500 border-red-500/30 bg-red-500/5', icon: '🔴' };
        } else if (aboveCount > 0 || attentionCount > 0 || metrics.total > targets.total) {
            return { label: 'ATENÇÃO', color: 'text-yellow-500 border-yellow-500/30 bg-yellow-500/5', icon: '🟡' };
        }
        return { label: 'NORMAL', color: 'text-emerald-500 border-emerald-500/30 bg-emerald-500/5', icon: '🟢' };
    }, [indicatorsData, metrics, targets, isUsingMock]);

    // Dynamic executive conclusion wording generator
    const cronosConclusion = useMemo(() => {
        if (isUsingMock) {
            return 'Aguardando novos dados para compilar o diagnóstico do Cronos.';
        }
        const worst = offendersRanking[0];
        const second = offendersRanking[1];
        
        if (worst.diff > 0) {
            let conclusion = `Atenção ao ${worst.name} (+${formatDuration(worst.diff)} acima da meta). Recomenda-se agilizar essa etapa para reduzir filas.`;
            if (second.diff > 0) {
                conclusion += ` O ${second.name} também exige atenção (+${formatDuration(second.diff)} acima).`;
            }
            return conclusion;
        }
        return 'Operação excelente. Todos os tempos operacionais estão rigorosamente dentro do esperado. Parabéns à equipe!';
    }, [offendersRanking, isUsingMock]);

    // Generate Raw Text formatted for WhatsApp copy
    const formattedWhatsAppReport = useMemo(() => {
        if (isUsingMock) {
            return `🤖 *CRONOS | RESUMO OPERACIONAL*

🏭 *Unidade:*
Aguardando Dados

📅 *Data:*
${reportDate !== '--/--/----' ? reportDate : new Date().toLocaleDateString('pt-BR')}

⏰ *Período analisado:*
Aguardando Dados

━━━━━━━━━━━━━━━━

⏱️ *INDICADORES DE TEMPO*

🚪 *TMFE | Fila Entrada*
0 min
⚪ Aguardando dados

🚚 *TMFI | Fila Interna*
0 min
⚪ Aguardando dados

📦 *TMC | Carregamento*
0 min
⚪ Aguardando dados

🚪 *TMS | Fila Saída*
0 min
⚪ Aguardando dados

━━━━━━━━━━━━━━━━

⏳ *CRONOS ANÁLISE*

Aguardando novos dados para compilar o diagnóstico do Cronos.

📍 *STATUS OPERACIONAL:*
⚪ *AGUARDANDO DADOS*`;
        }

        const dateStr = opDate === 'ALL' ? (reportDate !== '--/--/----' ? reportDate : new Date().toLocaleDateString('pt-BR')) : opDate;
        const unitName = opFactory === 'ALL' ? (opUniqueFactories[0] || 'Fábrica Principal') : opFactory;
        const areaStr = 'Geral';
        
        const worst = offendersRanking[0];
        const second = offendersRanking[1];
        const third = offendersRanking[2];

        // Helper to get offender plates for a given indicator
        const getIndicatorPlates = (indicatorId: string) => {
            if (isUsingMock) return '';
            let offenderPlates: string[] = [];
            if (indicatorId === 'TMFE') {
                offenderPlates = opFilteredEntries
                    .filter(e => e.tmfe_calculado && e.tmfe_calculado > targets.tmfe)
                    .map(e => e.placa2 && e.placa2 !== '-' ? `${e.placa} (${e.placa2})` : e.placa);
            } else if (indicatorId === 'TMFI') {
                offenderPlates = opFilteredEntries
                    .filter(e => e.tmfi && e.tmfi > targets.tmfi)
                    .map(e => e.placa2 && e.placa2 !== '-' ? `${e.placa} (${e.placa2})` : e.placa);
            } else if (indicatorId === 'TMC') {
                offenderPlates = opFilteredEntries
                    .filter(e => e.tmc && e.tmc > targets.tmc)
                    .map(e => e.placa2 && e.placa2 !== '-' ? `${e.placa} (${e.placa2})` : e.placa);
            } else if (indicatorId === 'TMS') {
                offenderPlates = opFilteredEntries
                    .filter(e => e.tms && e.tms > targets.tms)
                    .map(e => e.placa2 && e.placa2 !== '-' ? `${e.placa} (${e.placa2})` : e.placa);
            }
            const unique = Array.from(new Set(offenderPlates)).filter(Boolean);
            return unique.length > 0 ? `\n*Placas:* ${unique.join(', ')}` : '';
        };

        const overallOffenders = opFilteredEntries.filter(e => {
            const totalVal = (e.tmfe_calculado || 0) + (e.tmfi || 0) + (e.tmc || 0) + (e.tms || 0);
            return totalVal > targets.total;
        }).map(e => e.placa2 && e.placa2 !== '-' ? `${e.placa} (${e.placa2})` : e.placa);
        const uniqueOverall = Array.from(new Set(overallOffenders)).filter(Boolean);
        const overallPlatesText = uniqueOverall.length > 0 
            ? `\n*Placas acima do TMA Geral:* ${uniqueOverall.join(', ')}` 
            : '\n*Placas acima do TMA Geral:* Nenhuma';

        const worstPlates = worst && worst.diff > 0 ? getIndicatorPlates(worst.id) : '';
        const secondPlates = second && second.diff > 0 ? getIndicatorPlates(second.id) : '';
        const thirdPlates = third && third.diff > 0 ? getIndicatorPlates(third.id) : '';

        return `🤖 *CRONOS | RESUMO OPERACIONAL*

🏭 *Unidade:*
${unitName} (${areaStr})

📅 *Data:*
${dateStr}

⏰ *Período analisado:*
${opStartHour} às ${opEndHour}

━━━━━━━━━━━━━━━━

⏱️ *INDICADORES DE TEMPO*

🚪 *TMFE | Fila Entrada*
${formatDuration(metrics.tmfe)}
${indicatorsData.tmfe.status.emoji} ${indicatorsData.tmfe.status.label}

🚚 *TMFI | Fila Interna*
${formatDuration(metrics.tmfi)}
${indicatorsData.tmfi.status.emoji} ${indicatorsData.tmfi.status.label}

📦 *TMC | Carregamento*
${formatDuration(metrics.tmc)}
${indicatorsData.tmc.status.emoji} ${indicatorsData.tmc.status.label}

🚪 *TMS | Fila Saída*
${formatDuration(metrics.tms)}
${indicatorsData.tms.status.emoji} ${indicatorsData.tms.status.label}

━━━━━━━━━━━━━━━━

⏳ *CRONOS ANÁLISE*

${cronosConclusion}

📍 *STATUS OPERACIONAL:*
${overallOperationalStatus.icon} *${overallOperationalStatus.label}*`;
    }, [opDate, opFactory, opStartHour, opEndHour, reportDate, opUniqueFactories, metrics, indicatorsData, targets, deviationStr, isOverTarget, offendersRanking, cronosConclusion, overallOperationalStatus, isUsingMock, opFilteredEntries]);

    const handleCopyReport = () => {
        navigator.clipboard.writeText(formattedWhatsAppReport).then(() => {
            setCopySuccess(true);
            setTimeout(() => setCopySuccess(false), 2000);
        });
    };

    return (
        <div className="space-y-8 animate-fade-in">
            {/* TOP BAR / FILTERS */}
            <div className="bg-[#0e1629]/90 p-6 rounded-[2rem] border border-gray-800 shadow-2xl relative overflow-hidden backdrop-blur-md">
                <div className="absolute inset-0 bg-gradient-to-r from-blue-500/5 to-emerald-500/5 pointer-events-none" />
                <div className="relative z-10 flex flex-wrap items-center justify-between gap-6">
                    <div className="flex items-center gap-4">
                        <div className="p-3 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-2xl shadow-lg shadow-indigo-950/40">
                            <ActivityIcon className="w-6 h-6 text-white" />
                        </div>
                        <div>
                            <span className="text-[10px] font-black text-blue-400 tracking-[0.2em] uppercase">Cronos Intelligence</span>
                            <h3 className="text-xl font-black text-white uppercase tracking-tighter">Filtros da Análise Operacional</h3>
                        </div>
                    </div>

                    <div className="flex flex-wrap gap-4 items-center flex-1 lg:flex-initial">
                        {/* Data Filter */}
                        <div className="flex flex-col gap-1.5 min-w-[140px] flex-1 sm:flex-initial">
                            <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                                <CalendarDaysIcon className="w-3.5 h-3.5 text-blue-500" /> Data
                            </label>
                            <select
                                value={draftOpDate}
                                onChange={(e) => setDraftOpDate(e.target.value)}
                                className="w-full px-4 py-2.5 bg-[#070b19] border border-gray-800 rounded-xl text-xs font-bold text-white outline-none cursor-pointer focus:border-blue-500"
                            >
                                <option value="ALL">Todas as datas</option>
                                {opUniqueDates.map(d => (
                                    <option key={d} value={d}>{d}</option>
                                ))}
                            </select>
                        </div>

                        {/* Factory Filter */}
                        <div className="flex flex-col gap-1.5 min-w-[160px] flex-1 sm:flex-initial">
                            <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                                <MapPinIcon className="w-3.5 h-3.5 text-emerald-500" /> Unidade
                            </label>
                            <select
                                value={draftOpFactory}
                                onChange={(e) => setDraftOpFactory(e.target.value)}
                                className="w-full px-4 py-2.5 bg-[#070b19] border border-gray-800 rounded-xl text-xs font-bold text-white outline-none cursor-pointer focus:border-emerald-500"
                            >
                                <option value="ALL">Todas Unidades</option>
                                {opUniqueFactories.map(f => (
                                    <option key={f} value={f}>{f}</option>
                                ))}
                            </select>
                        </div>



                        {/* Period Filter */}
                        <div className="flex flex-col gap-1.5 min-w-[180px] flex-1 sm:flex-initial">
                            <label className="text-[10px] font-black text-gray-500 uppercase tracking-widest flex items-center gap-1.5">
                                <ClockIcon className="w-3.5 h-3.5 text-indigo-500" /> Período
                            </label>
                            <div className="flex items-center gap-2">
                                <select
                                    value={draftOpStartHour}
                                    onChange={(e) => setDraftOpStartHour(e.target.value)}
                                    className="flex-1 px-3 py-2.5 bg-[#070b19] border border-gray-800 rounded-xl text-xs font-bold text-white outline-none focus:border-indigo-500"
                                >
                                    {Array.from({ length: 24 }).map((_, i) => {
                                        const h = `${String(i).padStart(2, '0')}:00`;
                                        return <option key={h} value={h}>{h}</option>;
                                    })}
                                    <option value="23:59">23:59</option>
                                </select>
                                <span className="text-gray-600 text-xs font-black">às</span>
                                <select
                                    value={draftOpEndHour}
                                    onChange={(e) => setDraftOpEndHour(e.target.value)}
                                    className="flex-1 px-3 py-2.5 bg-[#070b19] border border-gray-800 rounded-xl text-xs font-bold text-white outline-none focus:border-indigo-500"
                                >
                                    {Array.from({ length: 24 }).map((_, i) => {
                                        const h = `${String(i).padStart(2, '0')}:00`;
                                        return <option key={h} value={h}>{h}</option>;
                                    })}
                                    <option value="23:59">23:59</option>
                                </select>
                            </div>
                        </div>

                        {/* Apply Filters Action */}
                        <div className="flex flex-col gap-1.5 justify-end min-w-[170px] flex-1 sm:flex-initial">
                            <span className="hidden sm:block h-5" />
                            <div className="flex items-center gap-2">
                                {hasUnappliedFilters && (
                                    <button
                                        onClick={discardFilters}
                                        className="px-3 py-2.5 bg-transparent border border-gray-800 hover:bg-white/[0.02] text-gray-400 rounded-xl text-xs font-bold transition-all duration-200 cursor-pointer"
                                    >
                                        Descartar
                                    </button>
                                )}
                                <button
                                    onClick={applyFilters}
                                    disabled={!hasUnappliedFilters}
                                    className={`flex-1 px-4 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all duration-300 flex items-center justify-center gap-1.5 ${
                                        hasUnappliedFilters
                                            ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-black shadow-lg shadow-emerald-500/20 hover:scale-[1.02] cursor-pointer'
                                            : 'bg-[#070b19] border border-gray-800 text-gray-500 cursor-not-allowed'
                                    }`}
                                >
                                    <Filter className="w-3.5 h-3.5" />
                                    <span>Aplicar Filtros</span>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* MAIN LAYOUT: INDICATORS & SUMMARY */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {/* LEFT: 4 CARDS INDICADORES */}
                <div className="lg:col-span-2 space-y-6">
                    <div className="flex justify-between items-center">
                        <h4 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em]">⏱️ Monitoramento Operacional</h4>
                        {isUsingMock ? (
                            <span className="text-[9px] font-black bg-blue-500/10 border border-blue-500/20 text-blue-400 px-3 py-1 rounded-full uppercase tracking-wider flex items-center gap-1">
                                <InfoIcon className="w-3 h-3 animate-pulse" /> Painel Zerado: Aguardando Importação de TMA
                            </span>
                        ) : metrics.isUsingDefaults && (
                            <span className="text-[9px] font-black bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 px-3 py-1 rounded-full uppercase tracking-wider animate-pulse flex items-center gap-1">
                                <InfoIcon className="w-3 h-3" /> Exibindo dados de exemplo (Aguardando importação)
                            </span>
                        )}
                    </div>

                    {isBiOnlyData && (
                        <div className="bg-blue-950/40 border border-blue-500/20 rounded-2xl p-4 flex gap-3 text-xs text-blue-300 leading-relaxed">
                            <InfoIcon className="w-5 h-5 text-blue-400 shrink-0 mt-0.5" />
                            <div>
                                <span className="font-black text-blue-200 uppercase tracking-wider block mb-1">📢 Dados do Monitoramento BI Ativos</span>
                                Os tempos de <strong>TMFE (Fila Externa)</strong> estão sendo calculados automaticamente a partir do monitoramento do BI para a unidade <strong>Latas Minas</strong>. Os tempos internos estão utilizando os padrões operacionais; utilize o painel de <strong>Simulação de Valores / Ajustes Manuais</strong> no final da página para refiná-los se necessário antes de enviar o farol.
                            </div>
                        </div>
                    )}

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                        {(Object.values(indicatorsData) as any[]).map((ind) => {
                            const isExceeded = ind.actual > ind.target;
                            return (
                                <div 
                                    key={ind.id} 
                                    className="bg-[#0d121f] rounded-[2rem] border border-white/[0.04] p-6 hover:border-blue-500/20 transition-all duration-300 shadow-lg relative overflow-hidden group"
                                >
                                    <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/5 rounded-full blur-2xl group-hover:bg-blue-500/10 transition-all pointer-events-none" />
                                    
                                    <div className="flex justify-between items-start mb-4">
                                        <div className="flex items-center gap-3">
                                            <span className="text-2xl">{ind.icon}</span>
                                            <div>
                                                <h4 className="text-xs font-black text-gray-400 uppercase tracking-widest">{ind.id}</h4>
                                                <span className="text-[10px] text-gray-500 font-bold uppercase">{ind.id === 'TMFE' ? 'Fila Entrada' : ind.id === 'TMFI' ? 'Fila Interna' : ind.id === 'TMC' ? 'Carregamento' : 'Fila Saída'}</span>
                                            </div>
                                        </div>
                                        <span className={`text-[9px] font-black px-2.5 py-1 rounded-full border uppercase tracking-wider ${ind.status.bg} ${ind.status.color}`}>
                                            {ind.status.emoji} {ind.status.label.split(' ')[0]}
                                        </span>
                                    </div>

                                    <div className="my-6">
                                        <div className="text-4xl font-black text-white font-mono tracking-tighter flex items-baseline gap-1">
                                            {formatDuration(ind.actual)}
                                        </div>
                                        <div className="flex justify-between items-center text-[10px] font-bold text-gray-500 uppercase mt-2">
                                            <span>Meta SLA: {formatDuration(ind.target)}</span>
                                            {isExceeded && (
                                                <span className="text-red-400 font-black">
                                                    +{formatDuration(ind.actual - ind.target)}
                                                </span>
                                            )}
                                        </div>
                                    </div>

                                    <p className="text-[10px] text-gray-500 font-bold leading-relaxed border-t border-white/[0.04] pt-4 uppercase">
                                        {ind.description}
                                    </p>
                                </div>
                            );
                        })}
                    </div>

                    {/* OVERALL PERFORMANCE CARD */}
                    <div className="bg-gradient-to-br from-[#0e1629] to-[#0a0f1d] rounded-[2.5rem] border border-white/[0.05] p-8 shadow-2xl relative overflow-hidden">
                        <div className="absolute right-0 top-0 w-64 h-64 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                            <div className="space-y-2">
                                <span className="text-[10px] font-black text-emerald-400 uppercase tracking-[0.2em]">Desempenho Consolidado</span>
                                <h3 className="text-xl font-black text-white uppercase tracking-tight">Tempo Médio de Atendimento (TMA)</h3>
                                <p className="text-xs text-gray-500 uppercase font-bold">Consolidação automática de todas as etapas do pátio</p>
                            </div>

                            <div className="flex flex-wrap gap-4 sm:gap-8 items-center">
                                <div className="text-center">
                                    <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-1">Tempo Real</span>
                                    <span className="text-4xl font-black text-white font-mono tracking-tighter">
                                        {formatDuration(metrics.total)}
                                    </span>
                                </div>

                                <div className="h-10 w-px bg-gray-800" />

                                <div className="text-center">
                                    <span className="text-[10px] font-black text-gray-500 uppercase tracking-widest block mb-1">Meta SLA</span>
                                    <span className="text-2xl font-black text-gray-400 font-mono tracking-tighter block">
                                        {formatDuration(targets.total)}
                                    </span>
                                </div>
                            </div>
                        </div>

                        <div className="mt-8 pt-6 border-t border-white/[0.04] flex flex-wrap items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                                <div className={`px-4 py-2 rounded-2xl border text-xs font-black uppercase tracking-widest flex items-center gap-2 ${overallOperationalStatus.color}`}>
                                    <span>{overallOperationalStatus.icon} STATUS: {overallOperationalStatus.label}</span>
                                </div>
                            </div>

                            <div className={`text-sm font-black uppercase tracking-wider flex items-center gap-2 ${isOverTarget ? 'text-red-400' : 'text-emerald-400'}`}>
                                {isOverTarget ? (
                                    <>
                                        <AlertTriangleIcon className="w-5 h-5 text-red-400" />
                                        <span>Desvio: {deviationStr}</span>
                                    </>
                                ) : (
                                    <>
                                        <CheckCircleIcon className="w-5 h-5 text-emerald-400" />
                                        <span>Desvio: {deviationStr}</span>
                                    </>
                                )}
                            </div>
                        </div>
                    </div>
                </div>

                {/* RIGHT: CRONOS ANÁLISE GENERATED REPORT */}
                <div className="space-y-6">
                    <h4 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em]">🤖 Resumo Executivo Pronto</h4>

                    <div className="bg-[#0a0f1d] rounded-[2.5rem] border-2 border-indigo-500/20 shadow-2xl relative overflow-hidden flex flex-col h-full max-h-[750px]">
                        <div className="bg-[#0e1629] px-6 py-4 border-b border-gray-800 flex justify-between items-center">
                            <div className="flex items-center gap-2.5">
                                <div className="h-2 w-2 rounded-full bg-indigo-500 animate-pulse" />
                                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">CRONOS AI WHATSAPP COMPLIANT</span>
                            </div>
                            <span className="text-[9px] font-mono text-gray-500 font-bold">UTF-8 MONO</span>
                        </div>

                        {/* Monospace message area */}
                        <div className="p-6 bg-black/40 overflow-y-auto custom-scrollbar flex-1 font-mono text-xs text-slate-300 leading-relaxed whitespace-pre-wrap select-text h-[450px]">
                            {formattedWhatsAppReport}
                        </div>

                        {/* Action section */}
                        <div className="p-6 bg-[#0e1629] border-t border-gray-800">
                            <button
                                onClick={handleCopyReport}
                                className={`w-full py-4 rounded-2xl font-black text-xs uppercase tracking-widest transition-all duration-300 flex items-center justify-center gap-2 shadow-lg ${
                                    copySuccess 
                                        ? 'bg-emerald-500 text-black shadow-emerald-950/20' 
                                        : 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-indigo-950/40'
                                }`}
                            >
                                {copySuccess ? (
                                    <>
                                        <CheckCircleIcon className="w-4 h-4 text-black" />
                                        <span>Resumo Copiado!</span>
                                    </>
                                ) : (
                                    <>
                                        <CopyIcon className="w-4 h-4" />
                                        <span>Copiar Resumo Operacional</span>
                                    </>
                                )}
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* COLLAPSIBLE ADJUSTMENTS / OVERRIDES FOR SIMULATION */}
            <div className="bg-[#090f1e] rounded-[2rem] border border-white/[0.04] overflow-hidden shadow-xl transition-all duration-300">
                <button 
                    onClick={() => setIsAdjustmentsOpen(!isAdjustmentsOpen)}
                    className="w-full px-4 sm:px-8 py-5 flex items-center justify-between text-left hover:bg-white/[0.01] transition-colors"
                >
                    <div className="flex items-center gap-3">
                        <span className="p-2 bg-indigo-500/10 text-indigo-400 rounded-xl">
                            <CopyIcon className="w-5 h-5" />
                        </span>
                        <div>
                            <h4 className="text-sm font-black text-white uppercase tracking-tight">Simulação de Valores / Ajustes Manuais</h4>
                            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest">Ajuste os indicadores diretamente para simular cenários e gerar resumos customizados</p>
                        </div>
                    </div>
                    {isAdjustmentsOpen ? <ChevronUpIcon className="w-5 h-5 text-gray-500" /> : <ChevronDownIcon className="w-5 h-5 text-gray-500" />}
                </button>

                {isAdjustmentsOpen && (
                    <div className="px-4 sm:px-8 pb-8 pt-4 border-t border-white/[0.03] grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 bg-[#070b16]">
                        {/* TMFE Slider */}
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-xs font-black uppercase tracking-wider">
                                <span className="text-cyan-400">🚪 TMFE Override</span>
                                <span className="text-white font-mono">{draftOverrideTMFE !== null ? `${draftOverrideTMFE} min` : 'Automático'}</span>
                            </div>
                            <input 
                                type="range" 
                                min="1" 
                                max="120" 
                                value={draftOverrideTMFE !== null ? draftOverrideTMFE : 12}
                                onChange={(e) => setDraftOverrideTMFE(parseInt(e.target.value))}
                                className="w-full accent-cyan-400 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                            />
                            <div className="flex justify-between text-[9px] font-mono text-gray-600">
                                <button onClick={() => setDraftOverrideTMFE(null)} className="hover:text-cyan-400 font-black uppercase">Resetar para Auto</button>
                                <span>SLA: {targets.tmfe / 60} min</span>
                            </div>
                        </div>

                        {/* TMFI Slider */}
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-xs font-black uppercase tracking-wider">
                                <span className="text-blue-400">🚚 TMFI Override</span>
                                <span className="text-white font-mono">{draftOverrideTMFI !== null ? `${draftOverrideTMFI} min` : 'Automático'}</span>
                            </div>
                            <input 
                                type="range" 
                                min="1" 
                                max="120" 
                                value={draftOverrideTMFI !== null ? draftOverrideTMFI : 28}
                                onChange={(e) => setDraftOverrideTMFI(parseInt(e.target.value))}
                                className="w-full accent-blue-400 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                            />
                            <div className="flex justify-between text-[9px] font-mono text-gray-600">
                                <button onClick={() => setDraftOverrideTMFI(null)} className="hover:text-blue-400 font-black uppercase">Resetar para Auto</button>
                                <span>SLA: {targets.tmfi / 60} min</span>
                            </div>
                        </div>

                        {/* TMC Slider */}
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-xs font-black uppercase tracking-wider">
                                <span className="text-emerald-400">📦 TMC Override</span>
                                <span className="text-white font-mono">{draftOverrideTMC !== null ? `${draftOverrideTMC} min` : 'Automático'}</span>
                            </div>
                            <input 
                                type="range" 
                                min="1" 
                                max="120" 
                                value={draftOverrideTMC !== null ? draftOverrideTMC : 39}
                                onChange={(e) => setDraftOverrideTMC(parseInt(e.target.value))}
                                className="w-full accent-emerald-400 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                            />
                            <div className="flex justify-between text-[9px] font-mono text-gray-600">
                                <button onClick={() => setDraftOverrideTMC(null)} className="hover:text-emerald-400 font-black uppercase">Resetar para Auto</button>
                                <span>SLA: {targets.tmc / 60} min</span>
                            </div>
                        </div>

                        {/* TMS Slider */}
                        <div className="space-y-3">
                            <div className="flex justify-between items-center text-xs font-black uppercase tracking-wider">
                                <span className="text-yellow-400">🚪 TMS Override</span>
                                <span className="text-white font-mono">{draftOverrideTMS !== null ? `${draftOverrideTMS} min` : 'Automático'}</span>
                            </div>
                            <input 
                                type="range" 
                                min="1" 
                                max="120" 
                                value={draftOverrideTMS !== null ? draftOverrideTMS : 9}
                                onChange={(e) => setDraftOverrideTMS(parseInt(e.target.value))}
                                className="w-full accent-yellow-400 bg-gray-800 rounded-lg appearance-none h-1.5 cursor-pointer"
                            />
                            <div className="flex justify-between text-[9px] font-mono text-gray-600">
                                <button onClick={() => setDraftOverrideTMS(null)} className="hover:text-yellow-400 font-black uppercase">Resetar para Auto</button>
                                <span>SLA: {targets.tms / 60} min</span>
                            </div>
                        </div>

                        {/* Action buttons panel */}
                        <div className="col-span-1 md:col-span-2 lg:col-span-4 pt-6 border-t border-white/[0.03] flex flex-col sm:flex-row justify-end items-center gap-4">
                            {hasUnappliedChanges && (
                                <span className="text-[10px] text-amber-400 font-bold uppercase tracking-wider animate-pulse flex items-center gap-1.5 bg-amber-500/10 px-3 py-1.5 rounded-full border border-amber-500/20 mr-auto sm:mb-0 mb-2">
                                    ⚠️ Há alterações pendentes de aplicação!
                                </span>
                            )}
                            <button
                                onClick={handleDiscard}
                                disabled={!hasUnappliedChanges}
                                className={`px-6 py-2.5 rounded-xl font-bold text-xs uppercase tracking-wider transition-all duration-200 border ${
                                    hasUnappliedChanges
                                        ? 'bg-transparent border-gray-700 text-gray-400 hover:bg-white/[0.02] cursor-pointer'
                                        : 'bg-transparent border-gray-800/40 text-gray-700 cursor-not-allowed'
                                }`}
                            >
                                Descartar
                            </button>
                            <button
                                onClick={handleApply}
                                disabled={!hasUnappliedChanges}
                                className={`px-8 py-2.5 rounded-xl font-black text-xs uppercase tracking-wider transition-all duration-300 flex items-center gap-2 ${
                                    hasUnappliedChanges
                                        ? 'bg-gradient-to-r from-indigo-500 to-purple-600 hover:from-indigo-600 hover:to-purple-700 text-white shadow-lg shadow-indigo-500/20 scale-100 hover:scale-[1.02] cursor-pointer'
                                        : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                                }`}
                            >
                                <span>Aplicar Tempos</span>
                            </button>
                        </div>
                    </div>
                )}
            </div>

            {/* BOTTOM RANKING DETAILS OF OFFSENDERS */}
            <div className="bg-[#0b101d] rounded-[2.5rem] border border-white/[0.04] p-8 shadow-2xl">
                <div className="flex items-center gap-3 mb-6">
                    <span className="text-xl">🚨</span>
                    <div>
                        <h3 className="text-base font-black text-white uppercase tracking-tight">Estratificação e Detalhamento de Ofensores</h3>
                        <p className="text-xs text-gray-500 uppercase font-bold">Diagnóstico sistemático e classificação por impacto absoluto nas metas</p>
                    </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-4 border-t border-white/[0.04]">
                    {offendersRanking.slice(0, 3).map((off, idx) => {
                        const isExceeded = off.diff > 0;
                        return (
                            <div key={off.id} className="bg-white/[0.01] border border-white/[0.03] p-6 rounded-3xl relative overflow-hidden group hover:border-indigo-500/20 transition-all duration-300">
                                <span className="absolute top-4 right-4 text-3xl opacity-30 select-none">{off.medal}</span>
                                <div className="space-y-2">
                                    <span className="text-[10px] font-black text-indigo-400 uppercase tracking-widest">{idx + 1}° Ofensor</span>
                                    <h4 className="text-sm font-black text-white uppercase tracking-tight">{off.name}</h4>
                                    
                                    <div className="pt-3 pb-2">
                                        <div className="text-2xl font-black text-white font-mono">{formatDuration(off.actual)}</div>
                                        <div className="text-[10px] text-gray-500 font-bold uppercase mt-1">SLA: {formatDuration(off.target)}</div>
                                    </div>

                                    <div className={`text-xs font-black uppercase py-1 px-3 rounded-lg inline-block ${isExceeded ? 'bg-red-500/10 text-red-400' : 'bg-emerald-500/10 text-emerald-400'}`}>
                                        {isExceeded ? `Excesso: +${formatDuration(off.diff)}` : 'Em Conformidade'}
                                    </div>

                                    <div className="pt-4 border-t border-white/[0.03] mt-4">
                                        <span className="text-[9px] font-black text-gray-400 uppercase block mb-1">Causa Operacional Associada:</span>
                                        <p className="text-xs text-slate-400 leading-relaxed font-bold uppercase">
                                            {off.cause}
                                        </p>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>
        </div>
    );
};
