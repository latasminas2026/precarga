
import React from 'react';
import ChevronLeftIcon from './icons/ChevronLeftIcon';

interface ScreenWrapperProps {
  title: string;
  onBack: () => void;
  children: React.ReactNode;
}

const ScreenWrapper: React.FC<ScreenWrapperProps> = ({ title, onBack, children }) => {
  return (
    <div className="max-w-7xl mx-auto">
      <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="p-2 rounded-full text-gray-400 hover:bg-gray-700 hover:text-white transition-colors duration-200 mr-2 no-print"
          aria-label="Voltar"
        >
          <ChevronLeftIcon className="w-6 h-6" />
        </button>
        <h2 className="text-2xl font-semibold text-gray-300 print-text-black">{title}</h2>
      </div>
      <div>{children}</div>
    </div>
  );
};

export default ScreenWrapper;
