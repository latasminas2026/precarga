
import type React from 'react';

export interface MenuItem {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
}

export enum SheetStatus {
  PENDING = 'PENDENTE',
  OK = 'OK',
}

export enum ZIStatus {
  PENDING = 'PENDENTE',
  OK = 'OK',
  NOK = 'NOK',
}

export interface ZI {
  id: number;
  sigla: string;
  problem: string;
  startTag: number;
  endTag: number;
  status: ZIStatus;
  prePointingStatus?: 'PENDENTE' | 'OK';
}

export interface Rework {
  id: number;
  reworkReason: string;
  startTag: number;
  endTag: number;
  status: 'PENDENTE' | 'LIBERADO';
}

export interface FractionedItem {
  id: number;
  location: string;
  layers: number;
}

export interface SavedSheet {
  id: string;
  lineId: string;
  productionDate: string;
  productCode: string;
  productDescription: string;
  zis: ZI[];
  reworks: Rework[];
  fractionedItems: FractionedItem[];
  sheetStatus: SheetStatus;
  manualPrePointingPallets?: number;
}

export interface Reservation {
    id: string;
    number: string;
    status: 'PENDENTE' | 'OK';
}

export interface TagRange {
  id: number;
  start: number;
  end: number;
}

export interface ZITagRange {
  id: number;
  ziSigla: string;
  problem: string;
  start: number;
  end: number;
  pncStatus: 'PENDENTE' | 'ALOCADO';
}

export interface ReworkTagRange {
  id: number;
  reworkReason: string;
  start: number;
  end: number;
}

export interface ForkliftBlock {
  id: string; 
  sheetId: string;
  lineId: string;
  identifier: string;
  operatorName: string;
  totalPallets: number;
  status: 'ABERTO' | 'FECHADO';
  prePointingStatus?: 'PENDENTE' | 'OK';
  storedTags: TagRange[];
  ziTags: ZITagRange[];
  reworkTags: ReworkTagRange[];
  date: string;
  absorbedReworkIds?: number[];
}

export interface PreloadItem {
  id: string;
  material: string;
  description: string;
  location: string;
  pallets: number;
  freeUseQuantity: number;
  batch: string;
  quantityPerPallet: number;
  loadedPallets: number;
}

export interface DivergenceItem {
  id: string;
  material: string;
  description: string;
  depositoSAP: string;
  sapPallets: number;
  freeUseQuantity: string;
  depositoFisico: string;
  fisicoPallets: number;
  difference: number;
  analysis: string;
  status: 'ok' | 'warning' | 'error' | 'info';
}

export interface SkuAnalysisGroup {
  sku: string;
  description: string;
  items: DivergenceItem[];
  totalSapPallets: number;
  totalFisicoPallets: number;
  totalDifference: number;
  overallStatus: 'ok' | 'warning' | 'error' | 'info';
}

export interface BIEntry {
  placaCavalo: string;
  inicioParada: string;
  fimParada: string;
  duracao: number;
  status: string;
  ultimoSinalGPS: string;
  lat: number;
  lng: number;
  trackerLastDate: string;
  unidadeDimensionada: string;
  statusVeiculo: string;
  ultimoLocalParada: string;
  canal: string;
  dt: string;
  tp: string;
  transportadora: string;
}

export type DurationStatus = 'VALIDO' | 'VAZIO' | 'ERRO' | 'NEGATIVO' | 'OUTLIER';

export interface DurationValidationResult {
  rawValue?: any;
  value: number | null; // em segundos se valido ou outlier, null caso contrario
  seconds: number | null;
  formatted: string;
  formattedShort: string;
  status: DurationStatus;
  outlier: boolean;
  includeInTMA: boolean;
  isValid: boolean;
  reason?: string;
}

export interface MetricQualityStats {
  metric: string;
  label: string;
  total: number;
  valid: number;
  empty: number;
  error: number;
  negative: number;
  outlier: number;
  averageSeconds: number | null;
  averageFormatted: string;
  averageFormattedShort: string;
  targetSeconds?: number;
}

export interface TMALogEntry {
  id: string;
  data?: string;
  placa: string;
  placa2?: string;
  transportadora: string;
  local?: string;
  notaFiscal?: string;
  pedido?: string;
  origem?: string;
  checkin?: string;
  entrada?: string;
  saida?: string;
  tempoFilaExterna?: number; // em segundos
  tempoInterno?: number; // em segundos
  tmaTotal?: number; // em segundos
  tmaReal?: number; // em segundos (da fonte REAL)
  source?: 'LOGAN' | 'REAL' | 'TOTEM';
  turno: 'A' | 'B' | 'C' | 'N/A';
  status?: string;
  
  // Campos estruturados de validação individual (Conforme Diretriz TMA)
  tmfiValidation?: DurationValidationResult;
  tmcValidation?: DurationValidationResult;
  tmfsValidation?: DurationValidationResult;
  tmsValidation?: DurationValidationResult;
  totalValidation?: DurationValidationResult;
  tmfeValidation?: DurationValidationResult;
  tmpcValidation?: DurationValidationResult;
  motivoInvalidezGeral?: string;
  
  // Campos auxiliares para UI e filtros
  processo?: string;
  tipoLocal?: string;
  statusPlaca?: string;
  isOutlier?: boolean;
  isManobra?: boolean;
  isBackup?: boolean;
  description?: string;
  isInRadius?: boolean;
  bi_status?: string;
  bi_duracao?: number;
  bi_gps_last?: string;
  bi_lat?: number;
  bi_lng?: number;
  bi_status_veiculo?: string;
  bi_ultimo_local_parada?: string;
  bi_canal?: string;
  bi_inicio_parada?: string;
  bi_fim_parada?: string;
  horaSaidaDoca?: string;
  horaEntrada?: string;
  horaDoca?: string;
  horaSaidaFabrica?: string;
  tmfe_calculado?: number;
  tmpc_calculado?: number;
  tmfi?: number;
  tmc?: number;
  tms?: number;
  lacre?: string;
  total?: number;
  status_raio?: 'DENTRO' | 'FORA';
  status_sla_drop?: 'ALERTA' | 'NORMAL';
  operacao?: string;
  tmcStr?: string;
  tmfiStr?: string;
  tmsStr?: string;
  totalStr?: string;
  alerta_3h?: boolean;
  unidade_divergente?: boolean;
  flag_manobra?: boolean;
  bi_unidade_dimensionada?: string;
  dt?: string;
  tp?: string;
}

export interface LoganEntry {
  estrutura: string;
  unidade: string;
  codigoUnidade: string;
  placa: string;
  placaCarreta: string;
  motorista: string;
  cpf: string;
  transportadora: string;
  processoEntrada: string;
  dataCheckin: string;
  dataEntrada: string;
  dataSaida: string;
  notaFiscal: string;
  pedido: string;
  origem: string;
  lacre?: string;
  dataEntradaDoca?: string;
  dataSaidaDoca?: string;
}

export interface TmaRealEntry {
  date: string;
  placa: string;
  local: string;
  tipoLocal: string;
  inicio: string;
  fim: string;
  tempo: string; // HH:MM:SS
  tempoSegundos: number;
  metaTmdi: string;
  transportadora: string;
  unidDimensionada: string;
  canal: string;
  lat: number;
  lng: number;
  statusPlaca: string;
  dt?: string;
}

export interface TMDILogEntry {
  id: string;
  codigo: string;
  item: string;
  descricao: string;
  nf: string;
  observacao: string;
  vim: string;
  transportadora: string;
  dataCheg: string;
  horaCheg: string;
  status: 'DESCARREGANDO' | 'PÁTIO EXTERNO' | 'AGUARDANDO' | 'FINALIZADO';
  dataSaid: string;
  horaSaid: string;
  turno: 'A' | 'B' | 'C';
  observacao2: string;
}

export interface TMAConfig {
  tmfeTarget: number;
  tmfiTarget: number;
  tmcTarget: number;
  tmsTarget: number;
  tmpcTarget: number;
  totalTarget: number;
}

export interface LoadingScheduleItem {
  id: string;
  loadingDate: string;     // DATA CARREGAMENTO
  shift: 'A' | 'B' | 'C';   // TURNO
  order: string;           // PEDIDO
  shipment: string;        // REMESSA
  ofDt: string;            // OF/DT
  picking: 'Realizado' | 'Pendente'; // PICKING
  seal: string;            // LACRE
  cpf: string;             // CPF
  gridDate: string;        // DATA DO PEDIDO NA GRADE
  destination: string;     // DESTINO
  productCode: string;     // COD. PROD
  productDescription: string; // PRODUTO
  tp: string;              // TP
  pallets: number;         // PALETS
  driver: string;          // MOTORISTA
  truckPlate: string;      // PLACA CAVALO
  trailerPlate: string;    // PLACA CARRETA
  activated: boolean;      // SIM / NÃO
  observations: string;    // OBSERVAÇÕES
  status?: 'AGUARDANDO' | 'EM_DOCA' | 'CARREGADO';
  dock?: string;
  startTime?: string;
  endTime?: string;
  carrier?: string;
}

export interface AnalisePIRegistro {
  id: string;
  data: string;
  turno: 'A' | 'B' | 'C';
  placa: string;
  transportadora: string;
  motivo: string;
  descricao: string;
  responsavel: string;
  guia: string;
  unidade?: string;
}

export interface User {
  login: string;
  role: 'conferente' | 'auxiliar' | 'monitor_tma' | 'administrador';
  name: string;
  photoUrl?: string;
}

export interface ScannedLabel {
  id: string;
  fo: string;
  code: string;
  timestamp: string;
  user: string;
}

export interface LoadingLog {
  id: string;
  fo: string;
  action: 'INICIO' | 'FIM' | 'REVALIDACAO';
  user: string;
  timestamp: string;
}

export interface LoadingOperationState {
  fo: string;
  status: 'AGUARDANDO_INICIO' | 'EM_CARREGAMENTO' | 'FINALIZADO';
  startTime?: string;
  endTime?: string;
}

export interface PTLQualityEntry {
    id: string;
    data: string;
    turno: 'A' | 'B' | 'C';
    produto: string;
    bloco: string;
    itemInspecionado: string;
    status: 'OK' | 'NOK';
}

export interface LineClosureLiberado {
  id: string;
  horaInicial: string;
  horaFinal: string;
  totalHl: number;
  deposito: string;
  lote: string;
  status: 'LIBERADO';
  preApontamento: string;
  paletesFracionados: number;
}

export interface LineClosureFracionadoLiberado {
  id: string;
  horaInicial: string;
  horaFinal: string;
  totalHl: number;
  codigo: string;
  status: 'LIBERADO';
  numCamFr: string;
  paletes: number;
}

export interface LineClosureInteiroNaoConforme {
  id: string;
  totalHl: number;
  status: 'ANÁLISE';
  numZi: string;
}

export interface LineClosureFracionadoNaoConforme {
  id: string;
  totalHl: number;
  status: 'ANÁLISE';
  numZi: string;
  numCamFr: string;
}

export interface LineClosureSheet {
  id: string;
  lineId: string;
  sku: string;
  productName: string;
  liberados: LineClosureLiberado[];
  fracionadosLiberados: LineClosureFracionadoLiberado[];
  inteirosNaoConformes: LineClosureInteiroNaoConforme[];
  fracionadosNaoConformes: LineClosureFracionadoNaoConforme[];
  observations: string;
  conferente: string;
  responsavelLogistica: string;
  responsavelProducao: string;
  date: string;
}
