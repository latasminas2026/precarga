import { createClient } from '@supabase/supabase-js';

const supabaseUrlRaw = import.meta.env.VITE_SUPABASE_URL || '';
const supabaseAnonKeyRaw = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

// Clean the URL and keys of quotes, trailing slashes, and common accidental path suffixes
const supabaseUrl = supabaseUrlRaw
  .trim()
  .replace(/^["']|["']$/g, '') // Remove wrapping quotes
  .replace(/\/+$/, '')         // Remove trailing slashes
  .replace(/\/rest\/v1$/, ''); // Remove accidental rest path

const supabaseAnonKey = supabaseAnonKeyRaw
  .trim()
  .replace(/^["']|["']$/g, ''); // Remove wrapping quotes

// Validação segura para evitar travamentos caso as credenciais não estejam configuradas ou sejam inválidas
export const isSupabaseConfigured = 
  Boolean(supabaseUrl) && 
  Boolean(supabaseAnonKey) && 
  supabaseUrl !== 'undefined' &&
  supabaseUrl !== 'null' &&
  supabaseAnonKey !== 'undefined' &&
  supabaseAnonKey !== 'null' &&
  (supabaseUrl.startsWith('http://') || supabaseUrl.startsWith('https://')) &&
  supabaseUrl.split('.').length >= 3 && // Ensure it has a subdomain/domain structure (e.g. x.supabase.co or db.x.com)
  !supabaseUrl.includes('placeholder') &&
  !supabaseAnonKey.includes('placeholder') &&
  !supabaseUrl.includes('YOUR_') && 
  !supabaseAnonKey.includes('YOUR_') &&
  !supabaseUrl.includes('<project-id>') &&
  supabaseUrl.length > 15; // Standard supabase url is usually longer than 15 chars

export const supabase = createClient(
  isSupabaseConfigured ? supabaseUrl : 'https://placeholder-url.supabase.co',
  isSupabaseConfigured ? supabaseAnonKey : 'placeholder-anon-key'
);
