import React, { useState, useEffect } from 'react';
import { User, TMAConfig } from './types';
import { auth, isFirebaseConfigured } from './firebase';
import { signInAnonymously } from 'firebase/auth';
import TMAMonitoringScreen from './components/screens/TMAMonitoringScreen';
import LoginScreen from './components/screens/LoginScreen';

// Helper functions for localStorage
const loadFromLocalStorage = <T,>(key: string, defaultValue: T): T => {
  try {
    const serializedState = localStorage.getItem(key);
    if (serializedState === null) {
      return defaultValue;
    }
    return JSON.parse(serializedState);
  } catch (e) {
    console.warn("Could not load state from localStorage", e);
    return defaultValue;
  }
};

const saveToLocalStorage = <T,>(key: string, value: T) => {
  try {
    const serializedState = JSON.stringify(value);
    localStorage.setItem(key, serializedState);
  } catch (e) {
    console.warn("Could not save state to localStorage", e);
  }
};

const DEFAULT_TMA_CONFIG: TMAConfig = {
  tmfeTarget: 1800,  // 30 minutes
  tmfiTarget: 3600,  // 60 minutes
  tmcTarget: 4380,   // 73 minutes (01:13)
  tmsTarget: 600,    // 10 minutes
  tmpcTarget: 3600,  // 60 minutes
  totalTarget: 8580, // 143 minutes
};

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [tmaConfig, setTmaConfig] = useState<TMAConfig>(() => {
    return loadFromLocalStorage<TMAConfig>('tmaConfig', DEFAULT_TMA_CONFIG);
  });

  // Synchronize localStorage currentUser with Firebase Auth session
  useEffect(() => {
    if (!isFirebaseConfigured) return;

    const syncAuth = async () => {
      if (currentUser) {
        const { signInWithEmailAndPassword, createUserWithEmailAndPassword } = await import('firebase/auth');
        let email = '';
        let pass = '';
        
        if (currentUser.login === 'ambev') {
          email = 'ambev@cronos.com';
          pass = 'tmalatas';
        } else if (currentUser.login === '99847923') {
          email = 'admin99847923@cronos.com';
          pass = 'latinha@2002';
        }

        if (email && pass) {
          // Apenas fazer sign-in se o usuário atual do Firebase Auth não for o mesmo
          if (auth.currentUser?.email !== email) {
            try {
              await signInWithEmailAndPassword(auth, email, pass);
              console.log(`Reautenticado na nuvem como: ${email}`);
            } catch (err: any) {
              if (err.code === 'auth/user-not-found' || err.code === 'auth/invalid-credential' || err.code === 'auth/wrong-password') {
                try {
                  await createUserWithEmailAndPassword(auth, email, pass);
                  console.log(`Nova conta de nuvem autocriada no background para: ${email}`);
                } catch (createErr) {
                  console.error("Erro ao autocriar conta no background sync:", createErr);
                }
              } else {
                console.error("Erro de background sync:", err);
              }
            }
          }
        }
      } else {
        // Se não houver usuário logado, usamos login anônimo como convidado/segurança
        if (!auth.currentUser) {
          try {
            await signInAnonymously(auth);
            console.log("Autenticado anonimamente no Firebase.");
          } catch (error) {
            console.error("Erro ao autenticar anonimamente no Firebase:", error);
          }
        }
      }
    };

    syncAuth();
  }, [currentUser]);

  useEffect(() => {
    saveToLocalStorage('currentUser', currentUser);
  }, [currentUser]);

  useEffect(() => {
    saveToLocalStorage('tmaConfig', tmaConfig);
  }, [tmaConfig]);

  const handleLogout = async () => {
    try {
      localStorage.removeItem('tma_current_view');
      if (isFirebaseConfigured) {
        const { signOut } = await import('firebase/auth');
        await signOut(auth);
        console.log("Deslogado da sessão em nuvem com sucesso.");
      }
    } catch (e) {
      console.warn("Could not sign out of cloud session", e);
    }
    setCurrentUser(null);
  };

  const handleLogin = (user: User) => {
    try {
      localStorage.setItem('tma_current_view', 'dashboard');
    } catch (e) {
      console.warn("Could not save tma_current_view on login", e);
    }
    setCurrentUser(user);
  };

  const handleTmaConfigUpdate = (updatedConfig: TMAConfig) => {
    setTmaConfig(updatedConfig);
  };

  return (
    <div className="min-h-screen bg-[#050505] text-gray-100 font-sans relative overflow-hidden">
      {/* Scanline effect */}
      <div className="absolute inset-0 pointer-events-none z-50 opacity-[0.02] bg-[linear-gradient(rgba(18,16,16,0)_50%,rgba(0,0,0,0.25)_50%),linear-gradient(90deg,rgba(255,0,0,0.06),rgba(0,255,0,0.02),rgba(0,0,255,0.06))] bg-[length:100%_2px,3px_100%]" />
      
      {!currentUser ? (
        <LoginScreen onLogin={handleLogin} />
      ) : (
        <TMAMonitoringScreen 
          onBack={handleLogout} 
          tmaConfig={tmaConfig} 
          onSaveTmaConfig={handleTmaConfigUpdate}
          user={currentUser}
        />
      )}
    </div>
  );
};

export default App;
