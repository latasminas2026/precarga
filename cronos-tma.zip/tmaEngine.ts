import { DurationStatus, DurationValidationResult, MetricQualityStats, TMALogEntry } from './types';

export const OUTLIER_THRESHOLD_SECONDS = 82800; // 23 horas (23 * 3600 = 82800)

/**
 * Converte segundos para string formatada HH:MM:SS
 */
export function secondsToTimeStr(totalSeconds: number | null | undefined): string {
    if (totalSeconds === null || totalSeconds === undefined || isNaN(totalSeconds)) {
        return 'Sem dados';
    }
    const absSeconds = Math.abs(Math.round(totalSeconds));
    const h = Math.floor(absSeconds / 3600);
    const m = Math.floor((absSeconds % 3600) / 60);
    const s = absSeconds % 60;
    const prefix = totalSeconds < 0 ? '-' : '';
    return `${prefix}${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

/**
 * Converte segundos para string formatada curta HH:MM ou MM min
 */
export function secondsToTimeStrShort(totalSeconds: number | null | undefined): string {
    if (totalSeconds === null || totalSeconds === undefined || isNaN(totalSeconds)) {
        return '--:--';
    }
    const absSeconds = Math.abs(Math.round(totalSeconds));
    const h = Math.floor(absSeconds / 3600);
    const m = Math.floor((absSeconds % 3600) / 60);
    const prefix = totalSeconds < 0 ? '-' : '';
    return `${prefix}${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`;
}

/**
 * Converte segundos para texto legível (ex: "25 min", "02h15min")
 */
export function formatDurationHuman(seconds: number | null | undefined): string {
    if (seconds === null || seconds === undefined || isNaN(seconds) || seconds <= 0) {
        return '0 min';
    }
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    if (hrs > 0) {
        return `${String(hrs).padStart(2, '0')}h${String(mins).padStart(2, '0')}min`;
    }
    return `${mins} min`;
}

/**
 * Converte string de tempo (HH:MM:SS ou HH:MM) ou número para segundos
 * Retorna { seconds: number | null, isNegative: boolean, isError: boolean, isEmpty: boolean }
 */
export function parseRawDurationToSeconds(input: any): {
    seconds: number | null;
    isNegative: boolean;
    isError: boolean;
    isEmpty: boolean;
    rawValue: any;
} {
    if (input === null || input === undefined) {
        return { seconds: null, isNegative: false, isError: false, isEmpty: true, rawValue: input };
    }

    if (typeof input === 'number') {
        if (isNaN(input)) {
            return { seconds: null, isNegative: false, isError: true, isEmpty: false, rawValue: input };
        }
        if (input < 0) {
            return { seconds: input, isNegative: true, isError: false, isEmpty: false, rawValue: input };
        }
        // Se for um decimal pequeno entre 0 e 1 (fração de dia do Excel, ex: 0.0416666 = 1h)
        if (input > 0 && input < 1) {
            const sec = Math.round(input * 86400);
            return { seconds: sec, isNegative: false, isError: false, isEmpty: false, rawValue: input };
        }
        return { seconds: Math.round(input), isNegative: false, isError: false, isEmpty: false, rawValue: input };
    }

    const str = String(input).trim();
    if (!str || str === '-' || str === '----' || str.toLowerCase() === 'vazio' || str === '01/01/1970 00:00:00') {
        return { seconds: null, isNegative: false, isError: false, isEmpty: true, rawValue: input };
    }

    const lower = str.toLowerCase();
    if (
        lower === 'erro' ||
        lower === 'error' ||
        lower === 'null' ||
        lower === 'undefined' ||
        lower === 'n/a' ||
        lower === 'na' ||
        lower.startsWith('#')
    ) {
        return { seconds: null, isNegative: false, isError: true, isEmpty: false, rawValue: input };
    }

    // Checagem de formato negativo explícito (ex: -00:10:00, -01:20:00, -31:25:43)
    if (str.startsWith('-') || str.includes(':-')) {
        return { seconds: null, isNegative: true, isError: false, isEmpty: false, rawValue: input };
    }

    // Se contém partes com ':'
    const timePart = str.includes(' ') ? str.split(' ')[1] : str;
    if (timePart.includes(':')) {
        const parts = timePart.split(':');
        // Checar se alguma parte tem sinal de menos
        if (parts.some(p => p.trim().startsWith('-') || parseInt(p, 10) < 0)) {
            return { seconds: null, isNegative: true, isError: false, isEmpty: false, rawValue: input };
        }

        if (parts.length === 3) {
            const h = parseInt(parts[0], 10);
            const m = parseInt(parts[1], 10);
            const s = parseInt(parts[2], 10);
            if (isNaN(h) || isNaN(m) || isNaN(s)) {
                return { seconds: null, isNegative: false, isError: true, isEmpty: false, rawValue: input };
            }
            const total = h * 3600 + m * 60 + s;
            return { seconds: total, isNegative: total < 0, isError: false, isEmpty: false, rawValue: input };
        } else if (parts.length === 2) {
            const h = parseInt(parts[0], 10);
            const m = parseInt(parts[1], 10);
            if (isNaN(h) || isNaN(m)) {
                return { seconds: null, isNegative: false, isError: true, isEmpty: false, rawValue: input };
            }
            // Em formato HH:MM
            const total = h * 3600 + m * 60;
            return { seconds: total, isNegative: total < 0, isError: false, isEmpty: false, rawValue: input };
        }
    }

    // Tenta número direto como string
    const num = parseFloat(str.replace(',', '.'));
    if (!isNaN(num)) {
        if (num < 0) {
            return { seconds: num, isNegative: true, isError: false, isEmpty: false, rawValue: input };
        }
        if (num > 0 && num < 1) {
            return { seconds: Math.round(num * 86400), isNegative: false, isError: false, isEmpty: false, rawValue: input };
        }
        return { seconds: Math.round(num), isNegative: false, isError: false, isEmpty: false, rawValue: input };
    }

    return { seconds: null, isNegative: false, isError: true, isEmpty: false, rawValue: input };
}

/**
 * FUNÇÃO CENTRAL DE VALIDAÇÃO (Regra 15)
 * Recebe uma duração (string, number, Date diff, etc) e retorna:
 * { value, seconds, formatted, formattedShort, status, outlier, includeInTMA, reason }
 */
export function validateDuration(input: any): DurationValidationResult {
    // Se já é um resultado de validação, reutiliza
    if (input && typeof input === 'object' && 'status' in input && 'includeInTMA' in input) {
        return input as DurationValidationResult;
    }

    const parsed = parseRawDurationToSeconds(input);

    // 1. SE vazio
    if (parsed.isEmpty) {
        return {
            rawValue: input,
            value: null,
            seconds: null,
            formatted: 'Vazio',
            formattedShort: '--:--',
            status: 'VAZIO',
            outlier: false,
            includeInTMA: false,
            isValid: false,
            reason: 'Tempo não registrado (campo vazio)'
        };
    }

    // 2. SE erro
    if (parsed.isError) {
        return {
            rawValue: input,
            value: null,
            seconds: null,
            formatted: 'Erro',
            formattedShort: 'ERRO',
            status: 'ERRO',
            outlier: false,
            includeInTMA: false,
            isValid: false,
            reason: 'Formato de tempo inválido ou erro de sistema'
        };
    }

    // 3. SE negativo
    if (parsed.isNegative || (parsed.seconds !== null && parsed.seconds < 0)) {
        return {
            rawValue: input,
            value: null,
            seconds: parsed.seconds,
            formatted: secondsToTimeStr(parsed.seconds),
            formattedShort: secondsToTimeStrShort(parsed.seconds),
            status: 'NEGATIVO',
            outlier: false,
            includeInTMA: false,
            isValid: false,
            reason: 'Duração negativa (inconsistência cronológica de apontamento)'
        };
    }

    const sec = parsed.seconds ?? 0;

    // 4. SE duração >= 23 horas (82800 segundos): OUTLIER
    if (sec >= OUTLIER_THRESHOLD_SECONDS) {
        return {
            rawValue: input,
            value: sec,
            seconds: sec,
            formatted: secondsToTimeStr(sec),
            formattedShort: secondsToTimeStrShort(sec),
            status: 'OUTLIER',
            outlier: true,
            includeInTMA: false,
            isValid: false,
            reason: `Duração excessiva >= 23h (${secondsToTimeStr(sec)}) - Expurgo estatístico`
        };
    }

    // 5. SE duração >= 0 E duração < 23 horas: VÁLIDO
    return {
        rawValue: input,
        value: sec,
        seconds: sec,
        formatted: secondsToTimeStr(sec),
        formattedShort: secondsToTimeStrShort(sec),
        status: 'VALIDO',
        outlier: false,
        includeInTMA: true,
        isValid: true,
        reason: 'Tempo válido e dentro dos limites operacionais'
    };
}

/**
 * FUNÇÃO CENTRAL DE MÉDIA (Regra 16)
 * Recebe uma lista de durações e utiliza SOMENTE itens com includeInTMA = true
 * Nunca retorna 00:00:00 para ausência de dados.
 */
export function calculateAverage(
    items: (number | DurationValidationResult | null | undefined)[]
): {
    average: number | null;
    count: number;
    formatted: string;
    formattedShort: string;
} {
    if (!items || items.length === 0) {
        return { average: null, count: 0, formatted: 'Sem dados', formattedShort: '--:--' };
    }

    let sum = 0;
    let count = 0;

    for (const item of items) {
        if (item === null || item === undefined) continue;

        let validated: DurationValidationResult;
        if (typeof item === 'object' && 'includeInTMA' in item) {
            validated = item as DurationValidationResult;
        } else {
            validated = validateDuration(item);
        }

        if (validated.includeInTMA && validated.seconds !== null && !isNaN(validated.seconds)) {
            sum += validated.seconds;
            count++;
        }
    }

    if (count === 0) {
        return { average: null, count: 0, formatted: 'Sem dados', formattedShort: '--:--' };
    }

    const avg = Math.round(sum / count);
    return {
        average: avg,
        count: count,
        formatted: secondsToTimeStr(avg),
        formattedShort: secondsToTimeStrShort(avg)
    };
}

/**
 * Converte DateTime do Excel (ex: 46231.69455) ou string em Date
 */
export function parseExcelOrStringDate(strOrNum: any, baseDateStr?: string): Date | null {
    if (!strOrNum || strOrNum === '-' || strOrNum === '----' || strOrNum === '01/01/1970 00:00:00') {
        return null;
    }

    // Se for número serial do Excel (ex: 46231.69455)
    if (typeof strOrNum === 'number' || (!isNaN(Number(strOrNum)) && Number(strOrNum) > 1000 && Number(strOrNum) < 100000)) {
        const serial = typeof strOrNum === 'number' ? strOrNum : Number(strOrNum);
        // Excel base date: 1899-12-30 (due to leap year 1900 bug in Excel)
        const msSince1899 = (serial - 25569) * 86400 * 1000;
        const d = new Date(msSince1899);
        if (!isNaN(d.getTime())) {
            return d;
        }
    }

    let fullStr = String(strOrNum).trim();
    fullStr = fullStr.replace(/[-.]/g, '/');

    if (!fullStr.includes('/') && baseDateStr) {
        const normalizedBaseDate = baseDateStr.replace(/[-.]/g, '/');
        fullStr = `${normalizedBaseDate} ${fullStr}`;
    }

    const parts = fullStr.split(/\s+/);
    if (parts.length < 2) {
        if (fullStr.includes('/') && fullStr.split('/').length === 3) {
            const dp = fullStr.split('/');
            let d: number, m: number, y: number;
            if (dp[0].length === 4) {
                y = parseInt(dp[0], 10);
                m = parseInt(dp[1], 10) - 1;
                d = parseInt(dp[2], 10);
            } else {
                d = parseInt(dp[0], 10);
                m = parseInt(dp[1], 10) - 1;
                y = parseInt(dp[2], 10);
            }
            if (y < 100) y += 2000;
            return new Date(y, m, d);
        }
        return null;
    }

    const dateParts = parts[0].split('/');
    const timeParts = parts[1].split(':');

    let day: number, month: number, year: number;
    if (dateParts[0].length === 4) {
        year = parseInt(dateParts[0], 10);
        month = parseInt(dateParts[1], 10) - 1;
        day = parseInt(dateParts[2], 10);
    } else {
        day = parseInt(dateParts[0], 10);
        month = parseInt(dateParts[1], 10) - 1;
        year = parseInt(dateParts[2], 10);
    }

    if (year < 100) year += 2000;

    let hours = parseInt(timeParts[0], 10);
    const minutes = parseInt(timeParts[1], 10);
    const seconds = timeParts[2] ? parseInt(timeParts[2], 10) : 0;

    const ampm = parts[2] ? parts[2].toUpperCase() : null;
    if (ampm === 'PM' && hours < 12) hours += 12;
    if (ampm === 'AM' && hours === 12) hours = 0;

    const date = new Date(year, month, day, hours, minutes, seconds);
    if (isNaN(date.getTime())) {
        return null;
    }
    return date;
}

/**
 * Calcula diferença em segundos entre dois timestamps
 */
export function calculateTimestampDiffInSeconds(
    start: Date | string | null | undefined,
    end: Date | string | null | undefined,
    baseDateStr?: string
): number | null {
    if (!start || !end) return null;

    const startDate = start instanceof Date ? start : parseExcelOrStringDate(start, baseDateStr);
    const endDate = end instanceof Date ? end : parseExcelOrStringDate(end, baseDateStr);

    if (!startDate || !endDate) return null;

    const diffMs = endDate.getTime() - startDate.getTime();
    return Math.round(diffMs / 1000);
}

/**
 * Calcula estatísticas de qualidade para um indicador específico (Regra 13)
 */
export function calculateMetricQualityStats(
    entries: TMALogEntry[],
    metricKey: 'tmfi' | 'tmc' | 'tms' | 'tmfs' | 'total' | 'tmfe' | 'tmpc',
    label: string,
    targetSeconds?: number
): MetricQualityStats {
    let valid = 0;
    let empty = 0;
    let error = 0;
    let negative = 0;
    let outlier = 0;
    const validValues: number[] = [];

    const getValidation = (e: TMALogEntry): DurationValidationResult => {
        if (metricKey === 'tmfi') return e.tmfiValidation || validateDuration(e.tmfi);
        if (metricKey === 'tmc') return e.tmcValidation || validateDuration(e.tmc);
        if (metricKey === 'tms' || metricKey === 'tmfs') return e.tmfsValidation || e.tmsValidation || validateDuration(e.tms);
        if (metricKey === 'total') return e.totalValidation || validateDuration(e.total);
        if (metricKey === 'tmfe') return e.tmfeValidation || validateDuration(e.tmfe_calculado);
        if (metricKey === 'tmpc') return e.tmpcValidation || validateDuration(e.tmpc_calculado);
        return validateDuration(null);
    };

    entries.forEach(e => {
        const val = getValidation(e);
        switch (val.status) {
            case 'VALIDO':
                valid++;
                if (val.seconds !== null) validValues.push(val.seconds);
                break;
            case 'VAZIO':
                empty++;
                break;
            case 'ERRO':
                error++;
                break;
            case 'NEGATIVO':
                negative++;
                break;
            case 'OUTLIER':
                outlier++;
                break;
        }
    });

    const avgResult = calculateAverage(validValues);

    return {
        metric: metricKey,
        label,
        total: entries.length,
        valid,
        empty,
        error,
        negative,
        outlier,
        averageSeconds: avgResult.average,
        averageFormatted: avgResult.formatted,
        averageFormattedShort: avgResult.formattedShort,
        targetSeconds
    };
}
